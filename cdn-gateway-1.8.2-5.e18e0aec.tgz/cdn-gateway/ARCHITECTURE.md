# CDN Gateway Kubernetes Architecture

## Egress Patterns

### Modern Approach: K8s Native Egress (Recommended)

**Configuration:** `useK8sEgress: true`

```text
┌─────────────────────────────────────────────────────────┐
│ Gateway Pod                                              │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Init Container: wait-for-gateway-registration    │  │
│  │ - Waits for gateway.crt to exist                │  │
│  │ - Verifies cert is not empty                     │  │
│  │ - Exits when cert is ready                       │  │
│  └──────────────────────────────────────────────────┘  │
│                       ↓                                  │
│  ┌──────────────────────────────────────────────────┐  │
│  │ blockcastd                                        │  │
│  │ - Connects directly with mTLS                    │  │
│  │ - Uses gateway.crt/key from volume               │  │
│  │ - Resolves via ExternalName services             │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
              ↓ mTLS (gateway.crt)
┌─────────────────────────────────────────────────────────┐
│ ExternalName Services                                    │
│ - bootstrap-egress → controller.magma.test:8444         │
│ - cloud-egress → api.magma.test:8443                    │
└─────────────────────────────────────────────────────────┘
              ↓
        Cloud Controller
```

**Benefits:**

- ✅ **Simple**: No extra proxy deployment
- ✅ **Efficient**: Direct connections, no proxy overhead
- ✅ **Robust**: Init container ensures certs exist before startup
- ✅ **K8s-native**: Uses standard ExternalName services
- ✅ **Automatic**: Cert waiting logic built into deployment

**How It Works:**

1. Init container waits for `gateway.crt` to exist
2. Main container starts only when cert is ready
3. Services connect directly using mTLS
4. ExternalName services resolve cloud endpoints

---

### Legacy Approach: Control Proxy (Deprecated)

**Configuration:** `useK8sEgress: false`

```text
┌─────────────────────────────────────────────────────────┐
│ Gateway Pod (blockcastd)                                 │
│ - Connects to local control-proxy:8443/8444            │
└─────────────────────────────────────────────────────────┘
              ↓ HTTP
┌─────────────────────────────────────────────────────────┐
│ Control Proxy Pod                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ control_proxy.sh                                  │  │
│  │ - Waits: while [ ! -f gateway.crt ]              │  │
│  │ - Starts proxy when cert exists                  │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
              ↓ mTLS (gateway.crt)
        Cloud Controller
```

**Drawbacks:**

- ❌ Extra deployment (resource overhead)
- ❌ Additional network hop (latency)
- ❌ More complex troubleshooting
- ❌ Requires separate cert mounting

**Why Deprecated:**
The K8s-native approach achieves the same cert-waiting functionality via init containers while maintaining cleaner architecture.

---

## Certificate Management

### Bootstrap Flow

```text
1. Pod starts → Init container runs
   ├─ Checks: /var/opt/magma/certs/gateway.crt exists?
   ├─ No → Sleep 15s, retry
   └─ Yes → Verify non-empty, exit

2. Main container starts → blockcastd runs
   ├─ Bootstraps if no cert (registers gateway)
   ├─ Uses existing cert if present
   └─ Connects to cloud with mTLS

3. Cert renewal (future)
   ├─ Use cert-manager for automatic rotation
   ├─ Pod restarts on cert update (via checksum annotation)
   └─ Init container re-validates new cert
```

### Certificate Sources

**Development:**

```yaml
certsVolume:
  type: hostPath
  hostPath: ~/.blockcast
```

- Mounts host directory with certs
- Shared with docker-compose for consistency
- Init container waits for bootstrap to create cert

**Production:**

```yaml
certsVolume:
  type: secret
  # Populated by cert-manager or external-secrets
```

- Kubernetes Secret with TLS data
- Automatic rotation via cert-manager
- Pod restart on secret update

---

## Migration Guide

### From Legacy (useK8sEgress: false) to Modern (useK8sEgress: true)

**Step 1:** Verify current setup

```bash
helm get values cdn-gateway -n magma
```

**Step 2:** Update values

```yaml
gateway:
  useK8sEgress: true  # Switch to modern approach
```

**Step 3:** Upgrade

```bash
helm upgrade cdn-gateway ./cdn-gateway -n magma \
  --set gateway.useK8sEgress=true \
  --reuse-values
```

**Step 4:** Verify

```bash
# Should NOT see control-proxy deployment
kubectl get deploy -n magma | grep control-proxy

# Init container should show completed
kubectl describe pod cdn-gateway-0 -n magma | grep -A5 "Init Containers"

# Logs should show cert found
kubectl logs cdn-gateway-0 -n magma -c wait-for-gateway-registration
```

---

## Troubleshooting

### Init Container Stuck Waiting

**Symptom:** Pod stuck in `Init:0/1`, logs show "Certificate not found"

**Causes:**

1. Gateway not yet registered/bootstrapped
2. Cert volume not mounted correctly
3. Bootstrap failed

**Fix:**

```bash
# Check cert volume
kubectl exec cdn-gateway-0 -c wait-for-gateway-registration -- ls -la /var/opt/magma/certs/

# Check if bootstrap completed
kubectl logs cdn-gateway-0 -c cdn-gateway --previous

# Force bootstrap (if needed)
kubectl exec cdn-gateway-0 -c cdn-gateway -- rm -f /etc/snowflake/snowflake
kubectl delete pod cdn-gateway-0
```

### Connection Failures with K8s Egress

**Symptom:** Services can't connect to cloud

**Check:**

```bash
# Verify ExternalName services exist
kubectl get svc -n magma | grep egress

# Test DNS resolution
kubectl exec cdn-gateway-0 -- nslookup cdn-gateway-cloud-egress

# Verify cert is valid
kubectl exec cdn-gateway-0 -- openssl x509 -in /var/opt/magma/certs/gateway.crt -text -noout
```

---

## Design Rationale

### Why ExternalName + Init Container?

#### Alternative 1: Control Proxy

- ❌ Extra deployment overhead
- ❌ Additional network hop
- ✅ Built-in cert waiting

#### Alternative 2: K8s Egress without init container

- ✅ K8s-native
- ❌ No cert waiting → pod crashes if cert missing

#### Our Approach: K8s Egress + Init Container

- ✅ K8s-native architecture
- ✅ Built-in cert waiting (from control-proxy pattern)
- ✅ No extra deployments
- ✅ Best of both worlds

### Future Enhancements

1. **Cert-Manager Integration**

   ```yaml
   apiVersion: cert-manager.io/v1
   kind: Certificate
   metadata:
     name: gateway-tls
   spec:
     secretName: gateway-tls-secret
     issuerRef:
       name: magma-ca
     renewBefore: 720h  # 30 days
   ```

2. **Automatic Pod Restart on Cert Rotation**

   ```yaml
   annotations:
     checksum/certs: {{ include "cert-hash" . }}
   ```

3. **Cert Validation Sidecar**
   - Monitor cert expiry
   - Alert before expiration
   - Trigger renewal workflow
