{{/*
Common service template for gateway services
Usage: include "cdn-gateway.service" (dict "serviceName" "blockcastd" "ports" (list ...) "context" $)
Optional: "serviceType" - force type (e.g. "ClusterIP" for internal-only services like blockcastd)
*/}}
{{- define "cdn-gateway.service" -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ .serviceName }}
  labels:
    app.kubernetes.io/name: {{ .serviceName }}
    app.kubernetes.io/instance: {{ .context.Release.Name }}
  {{- with .context.Values.service.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  type: {{ .serviceType | default .context.Values.service.type }}
  {{- if .context.Values.service.loadBalancerIP }}
  loadBalancerIP: {{ .context.Values.service.loadBalancerIP }}
  {{- end }}
  {{- if .context.Values.service.externalTrafficPolicy }}
  externalTrafficPolicy: {{ .context.Values.service.externalTrafficPolicy }}
  {{- end }}
  {{- if .context.Values.service.ipFamilyPolicy }}
  ipFamilyPolicy: {{ .context.Values.service.ipFamilyPolicy }}
  {{- end }}
  {{- if .context.Values.service.ipFamilies }}
  ipFamilies:
    {{- toYaml .context.Values.service.ipFamilies | nindent 4 }}
  {{- end }}
  ports:
  {{- range .ports }}
  - name: {{ .name }}
    port: {{ .port }}
    targetPort: {{ .targetPort | default .port }}
    protocol: {{ .protocol | default "TCP" }}
  {{- end }}
  selector:
    app.kubernetes.io/name: {{ .serviceName }}
    app.kubernetes.io/instance: {{ .context.Release.Name }}
{{- end }}

