#!/usr/bin/env bash
# PEN-4707 regression guard.
#
# Every object this chart renders must carry `helm.sh/chart` and
# `app.kubernetes.io/version`, because they are the ONLY in-cluster record of
# which prereqs version is installed.
#
# WHY IT IS THE ONLY RECORD. The Helm release Secret also holds the version,
# but `secrets` is forbidden on the read-only monitoring tier -- measured
# 2026-10-25 for both `system:serviceaccount:paperclip:penstock-devops-agent`
# and `system:serviceaccount:paperclip:paperclip-k8s-mcp-readonly`. The main
# cdn-gateway chart has always emitted `helm.sh/chart` on its workloads, which
# is how blockcastd-chart-pin-guard can compare production-blockcastd against
# the stable channel; this chart emitted nothing, so prereqs drift was
# structurally invisible. PEN-3947's 11-day undelivered security fix and the
# two namespaces that sat ~36 versions behind their siblings were both found by
# a human reading things by hand.
#
# So this guard is not cosmetic. A template added later that forgets
# `cdn-gateway-prereqs.versionLabels` does not break any deploy -- it silently
# removes an object from a detector's view, which is the same class of silent
# hole the detector exists to close. That is why the assertion is "EVERY
# rendered object", counted, and not "the label appears somewhere".
#
# Both render paths are checked. relay.enabled=false drops the dssync and relay
# templates, so the default render alone would leave the helm-manager pair as
# the only thing proven under that path.
#
# NOT covered: whether the label is actually PRESENT in a cluster. It appears
# only once a release is upgraded to a chart carrying it, and
# cdn-gateway-orc8r-prereqs has no automated deliverer (PEN-4555). A detector
# must therefore treat a missing label as UNREADABLE, never as "no drift".
#
# Note on herestrings: every assertion below reads a rendered manifest with
# `<<<`, never a pipe. A large render piped into a short-circuiting reader
# (`grep -q`, `awk ... {exit}`) gives the writer EPIPE, which `pipefail`
# promotes to the pipeline's status and INVERTS the verdict. See the repo
# CLAUDE.md entry on this.
set -euo pipefail

PREREQS="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHART_NAME="cdn-gateway-orc8r-prereqs"
RELEASE="blockcastd-prereqs"
NS="staging-blockcastd-receiver"

PASS=0; FAIL=0
ok()  { echo "  ok: $*";   PASS=$((PASS+1)); }
bad() { echo "  FAIL: $*" >&2; FAIL=$((FAIL+1)); }

render() { # render <description> [extra helm args...]
  local desc="$1"; shift
  local err out
  err=$(mktemp)
  if ! out=$(helm template "$RELEASE" "$PREREQS" --namespace "$NS" "$@" 2>"$err"); then
    echo "FAIL: helm template failed ($desc)" >&2
    sed 's/^/    /' "$err" >&2; rm -f "$err"; exit 1
  fi
  rm -f "$err"
  printf '%s\n' "$out"
}

# Top-level `kind:` only. `kind` also appears indented under roleRef and
# subjects[]; anchoring at column 0 counts documents, not references.
count_objects()  { grep -c '^kind: '                      <<<"$1" || true; }
count_chart()    { grep -c '^    helm\.sh/chart: '          <<<"$1" || true; }
count_version()  { grep -c '^    app\.kubernetes\.io/version: ' <<<"$1" || true; }

echo "== every rendered object carries both version labels =="
for path in "relay.enabled=true:--set relay.enabled=true" "relay.enabled=false:--set relay.enabled=false"; do
  desc="${path%%:*}"; arg="${path#*:}"
  DOC="$(render "$desc" $arg)"
  objs=$(count_objects "$DOC"); chart=$(count_chart "$DOC"); vers=$(count_version "$DOC")
  if [ "$objs" -eq 0 ]; then
    bad "$desc rendered no objects at all -- the assertion below would be vacuous"
    continue
  fi
  if [ "$objs" -eq "$chart" ]; then
    ok "$desc: all $objs object(s) carry helm.sh/chart"
  else
    bad "$desc: $chart of $objs object(s) carry helm.sh/chart -- $((objs-chart)) missing the versionLabels helper"
  fi
  if [ "$objs" -eq "$vers" ]; then
    ok "$desc: all $objs object(s) carry app.kubernetes.io/version"
  else
    bad "$desc: $vers of $objs object(s) carry app.kubernetes.io/version"
  fi
done

echo
echo "== the label value is the packaged chart version, exactly =="
# `helm template --version` is ignored for a local directory, so a source-tree
# render proves only the Chart.yaml value. The version operators actually run
# is stamped by `helm package --version` in release-publish.yml, so package it
# the same way and assert on THAT -- otherwise this test passes while the
# published artifact carries something else.
STAMP="9.9.99-99999.deadbeef"
TMPDIR_PKG=$(mktemp -d); trap 'rm -rf "$TMPDIR_PKG"' EXIT
helm package "$PREREQS" --version "$STAMP" --app-version "$STAMP" --destination "$TMPDIR_PKG" >/dev/null
PKG_DOC="$(helm template "$RELEASE" "$TMPDIR_PKG/$CHART_NAME-$STAMP.tgz" --namespace "$NS")"

# awk, not grep: a no-match grep exits 1 and `set -e` would kill the script
# before the assertion below could report WHICH value was wrong.
got_chart=$(awk '/^    helm\.sh\/chart: /{sub(/^ *helm\.sh\/chart: /,""); print}' <<<"$PKG_DOC" | sort -u)
got_vers=$(awk '/^    app\.kubernetes\.io\/version: /{sub(/^ *app\.kubernetes\.io\/version: /,""); gsub(/"/,""); print}' <<<"$PKG_DOC" | sort -u)
[ "$got_chart" = "$CHART_NAME-$STAMP" ] \
  && ok "packaged helm.sh/chart == $CHART_NAME-$STAMP (single distinct value)" \
  || bad "packaged helm.sh/chart is '$got_chart', want '$CHART_NAME-$STAMP'"
[ "$got_vers" = "$STAMP" ] \
  && ok "packaged app.kubernetes.io/version == $STAMP (single distinct value)" \
  || bad "packaged app.kubernetes.io/version is '$got_vers', want '$STAMP'"

echo
echo "== the label must be parsed by EXACT chart name, not by prefix =="
# This chart's name is a prefix-superset of the main chart's: stripping
# "cdn-gateway-" off "cdn-gateway-orc8r-prereqs-<v>" yields
# "orc8r-prereqs-<v>", not a version. That is the same prefix-vs-exact
# confusion BLO-30312 fixed in chartVersion()'s release sweep. Asserted here so
# a consumer that gets it wrong has a named test to point at.
if [ "${got_chart#cdn-gateway-}" = "$STAMP" ]; then
  bad "prefix-stripping 'cdn-gateway-' yielded a bare version -- this test's premise is stale, re-check consumers"
else
  ok "prefix-stripping 'cdn-gateway-' does NOT yield a version (got '${got_chart#cdn-gateway-}') -- consumers must strip '$CHART_NAME-'"
fi
[ "${got_chart#$CHART_NAME-}" = "$STAMP" ] \
  && ok "stripping the exact chart name yields the version" \
  || bad "stripping '$CHART_NAME-' did not yield '$STAMP'"

echo
echo "passed: $PASS, failed: $FAIL"
[ "$FAIL" -eq 0 ]
