{{/*
PEN-4707: make the INSTALLED prereqs chart version readable off a live object.

WHY THIS EXISTS. Until this helper, nothing in the cluster stated which version
of cdn-gateway-orc8r-prereqs was installed. The main cdn-gateway chart has
emitted `helm.sh/chart` on its workloads for a long time (see
cdn-gateway-orc8r/templates/_helpers.tpl), which is how
blockcastd-chart-pin-guard can compare production-blockcastd against the stable
channel. This chart emitted no such label, and the only other record of the
version -- the Helm release Secret -- is unreadable from the read-only
monitoring tier (`secrets is forbidden` for both
`system:serviceaccount:paperclip:penstock-devops-agent` and
`system:serviceaccount:paperclip:paperclip-k8s-mcp-readonly`, measured
2026-10-25).

So a drift detector had two options: grant Secret read in the five gateway
namespaces, or make the version legible from an object that is already
readable. This is the second.

This chart renders cluster-scoped RBAC (ClusterRole/ClusterRoleBinding in
dssync-rbac.yaml, helm-manager-rbac.yaml and relay-rbac.yaml), a GatewayClass,
AND one namespaced Role/RoleBinding pair for `events` in relay-rbac.yaml -- it
is not all cluster-scoped. The existing read-only tier can already list both
scopes, so no new grant is needed either way: `list roles` was confirmed
against production-blockcastd on 2026-10-25, which returned the chart's own
`blockcastd-prereqs-production-blockcastd-relay-ingress` Role. The version therefore
becomes legible to anything that looks, not just to one privileged collector.

The 11-day undelivered security fix in PEN-3947 and the two namespaces that sat
~36 versions behind their siblings were both found by a human reading things by
hand. This label is what lets a machine read them instead.

NOTE ON PARSING. The chart NAME is a prefix-superset of the main chart's name:
`cdn-gateway-orc8r-prereqs-1.8.189` vs `cdn-gateway-1.8.189`. A consumer must
strip the exact chart name plus "-", never match on the `cdn-gateway-` prefix.
That prefix-vs-exact distinction is the same one BLO-30312 fixed in
chartVersion()'s release sweep; do not reintroduce it here.
*/}}

{{/*
Chart name and version, in the standard Helm `helm.sh/chart` spelling.
`+` is not legal in a label value, so the conventional `_` substitution applies
even though the release pipeline does not currently emit build metadata.
*/}}
{{- define "cdn-gateway-prereqs.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
The two version-bearing labels, emitted on EVERY object this chart renders.

`app.kubernetes.io/version` is deliberately .Chart.Version and NOT
.Chart.AppVersion. The main chart uses AppVersion, and on objects left behind by
a conditional that is no longer rendered that reads as a stale `1.8.1` while
`helm.sh/chart` still carries a real version -- observed live on
production-blockcastd's blockcastd-yt-auth-bot (`app.kubernetes.io/version=1.8.1,
helm.sh/chart=cdn-gateway-1.8.16`). Chart.Version is always the packaged
version, so the two labels here cannot disagree.

tests/test-prereqs-emits-chart-version-label.sh asserts every rendered object
carries these, so a new template that forgets the helper fails CI rather than
creating a silent hole in the detector's coverage.
*/}}
{{- define "cdn-gateway-prereqs.versionLabels" -}}
helm.sh/chart: {{ include "cdn-gateway-prereqs.chart" . }}
app.kubernetes.io/version: {{ .Chart.Version | quote }}
{{- end -}}
