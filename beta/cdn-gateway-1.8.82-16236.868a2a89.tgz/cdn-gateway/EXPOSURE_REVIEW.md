# Public Exposure Review

This chart is published through the public Blockcast Helm chart repository.

## Checklist

| Surface | Status | Evidence |
| --- | --- | --- |
| Secret values | Pass | Packaged chart scan found no literal staging password defaults; public placeholders remain non-empty so fresh Postgres initialization succeeds while still requiring real environment overrides. |
| Internal ticket IDs | Pass | Packaged chart scan found no internal ticket identifiers, including compound references. |
| Private IP examples | Pass | Packaged chart scan found no private-address examples covered by the release gate. |
| Helm validity | Pass | `helm lint cdn-gateway-orc8r` and `helm package cdn-gateway-orc8r` pass. |

Operators must provide environment-specific secrets and private addresses via
their own values overlays or external secret managers.
