{{/*
Expand the name of the chart.
*/}}
{{- define "cdn-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cdn-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cdn-gateway.labels" -}}
helm.sh/chart: {{ include "cdn-gateway.chart" . }}
{{ include "cdn-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cdn-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cdn-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cdn-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Gateway certificate path - all services use /var/opt/magma/certs
Contains gateway.crt and gateway.key from bootstrapper
*/}}
{{- define "cdn-gateway.certPath" -}}
/var/opt/magma/certs
{{- end }}

{{/*
Gateway certificate volume mounts for edge services (traffic-monitor, traffic-router, trafficserver)
Single mount point at /var/opt/magma/certs
*/}}
{{- define "cdn-gateway.certVolumeMounts" -}}
- name: certs
  mountPath: /var/opt/magma/certs
  readOnly: true
{{- end }}

{{/*
Gateway certificate volume definition
*/}}
{{- define "cdn-gateway.certVolume" -}}
- name: certs
  {{- if eq .Values.gateway.certsVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.certsVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.certsVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.certsVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.certsVolume.claimName | default "gateway-certs-pvc" }}
  {{- else if eq .Values.gateway.certsVolume.type "secret" }}
  secret:
    secretName: {{ .Values.gateway.certsVolume.secretName | default "gateway-certs" }}
  {{- else }}
  secret:
    secretName: {{ .Release.Name }}-certs
  {{- end }}
{{- end }}

{{/*
Snowflake volume definition — used by blockcastd (cdn-gateway.volumes) and
the relay/cache-init init container to derive the per-gateway
device-name prefix from /etc/snowflake/snowflake.
*/}}
{{- define "cdn-gateway.snowflakeVolume" -}}
- name: snowflake
  {{- if eq .Values.gateway.snowflakeVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.snowflakeVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.snowflakeVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.snowflakeVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.snowflakeVolume.claimName | default "gateway-snowflake-pvc" }}
  {{- else if eq .Values.gateway.snowflakeVolume.type "configMap" }}
  configMap:
    name: {{ .Values.gateway.snowflakeVolume.name | default "gateway-snowflake" }}
    items:
      - key: {{ .Values.gateway.snowflakeVolume.key | default "snowflake" }}
        path: snowflake
  {{- end }}
{{- end }}

{{/*
Common volume mounts for gateway services
*/}}
{{- define "cdn-gateway.volumeMounts" -}}
- name: certs
  mountPath: /var/opt/magma/certs
{{- /* Snowflake is opt-out per-service via mountSnowflake:false (default on).
       beacond derives its identity from gateway.crt (the certs mount) and never
       reads /etc/snowflake, so it skips this RWO PVC to avoid a Multi-Attach
       fight with blockcastd when the two land on different nodes. */}}
{{- if not (and (hasKey . "mountSnowflake") (not .mountSnowflake)) }}
- name: snowflake
  mountPath: /etc/snowflake
{{- end }}
- name: blockcastd-data
  mountPath: /var/opt/magma/wal
  subPath: wal
{{- /* When gateway.configsPath is set, the configs-cdn hostPath below
       overrides /var/opt/magma/configs entirely. Mounting both targets
       the same path and helm install fails with "must be unique". */}}
{{- if not .Values.gateway.configsPath }}
- name: blockcastd-data
  mountPath: /var/opt/magma/configs
  subPath: configs
{{- end }}
{{- if .Values.gateway.rootCAPath }}
- name: rootca
  mountPath: /etc/magma/certs
  readOnly: true
{{- end }}
{{- if .Values.gateway.configsPath }}
- name: configs-cdn
  mountPath: /var/opt/magma/configs
{{- end }}
{{- if .Values.gateway.bandwidthConfigsPath }}
- name: configs-bandwidth
  mountPath: /var/opt/magma/configs/bandwidth
{{- end }}
{{- if .Values.gateway.helmAutoupdatePath }}
- name: helm-autoupdate
  mountPath: /var/opt/magma/helm
  readOnly: true
{{- end }}
{{- if .Values.maxmind.enabled }}
- name: maxmind-data
  mountPath: {{ .Values.maxmind.mountPath | default "/var/opt/magma/maxmind" }}
  readOnly: true
{{- end }}
{{- end }}

{{/*
Common volumes for gateway services
*/}}
{{- define "cdn-gateway.volumes" -}}
- name: certs
  {{- if eq .Values.gateway.certsVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.certsVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.certsVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.certsVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.certsVolume.claimName | default "gateway-certs-pvc" }}
  {{- else if eq .Values.gateway.certsVolume.type "secret" }}
  secret:
    secretName: {{ .Values.gateway.certsVolume.secretName | default "gateway-certs" }}
  {{- end }}
{{- if not (and (hasKey . "mountSnowflake") (not .mountSnowflake)) }}
{{ include "cdn-gateway.snowflakeVolume" . }}
{{- end }}
- name: blockcastd-data
  {{- if .Values.gateway.blockcastdDataPath }}
  hostPath:
    path: {{ .Values.gateway.blockcastdDataPath }}
    type: DirectoryOrCreate
  {{- else }}
  persistentVolumeClaim:
    claimName: {{ include "cdn-gateway.fullname" . }}-blockcastd-data
  {{- end }}
{{- if .Values.gateway.rootCAPath }}
- name: rootca
  hostPath:
    path: {{ .Values.gateway.rootCAPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.configsPath }}
- name: configs-cdn
  hostPath:
    path: {{ .Values.gateway.configsPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.bandwidthConfigsPath }}
- name: configs-bandwidth
  hostPath:
    path: {{ .Values.gateway.bandwidthConfigsPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.helmAutoupdatePath }}
- name: helm-autoupdate
  hostPath:
    path: {{ .Values.gateway.helmAutoupdatePath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.maxmind.enabled }}
- name: maxmind-data
  {{- if eq (.Values.maxmind.volume.type | default "persistentVolumeClaim") "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.maxmind.volume.claimName | default (printf "%s-maxmind-data" (include "cdn-gateway.fullname" .)) }}
  {{- else if eq .Values.maxmind.volume.type "hostPath" }}
  hostPath:
    path: {{ .Values.maxmind.volume.hostPath | default "/var/opt/magma/maxmind" }}
    type: DirectoryOrCreate
  {{- else }}
  emptyDir: {}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Check if PostgreSQL should be enabled.
Auto-enable when ATS ingress or Caddy/multicast dynamic services are enabled.
*/}}
{{- define "cdn-gateway.postgresqlEnabled" -}}
{{- if .Values.postgresql.enabled -}}
true
{{- else if .Values.ingress.enabled -}}
true
{{- else if .Values.multicast.enabled -}}
true
{{- else if .Values.caddy.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Gateway nodeSelector - ensures all CDN pods run on nodes with shared cert volume access
Used for: hostPath volumes or ReadWriteOnce PVCs that require single-node deployment
*/}}
{{- define "cdn-gateway.nodeSelector" -}}
{{- if .Values.gateway.nodeSelector }}
nodeSelector:
  {{- toYaml .Values.gateway.nodeSelector | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Common pod spec for gateway services
*/}}
{{- define "cdn-gateway.podSpec" -}}
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if or .nodeSelector .Values.gateway.nodeSelector .Values.nodeSelector }}
nodeSelector:
  {{- if .nodeSelector }}
  {{- toYaml .nodeSelector | nindent 2 }}
  {{- else if .Values.gateway.nodeSelector }}
  {{- toYaml .Values.gateway.nodeSelector | nindent 2 }}
  {{- else }}
  {{- toYaml .Values.nodeSelector | nindent 2 }}
  {{- end }}
{{- end }}
{{- $tolerations := .tolerations | default .Values.gateway.tolerations | default .Values.tolerations }}
{{- if $tolerations }}
tolerations:
  {{- toYaml $tolerations | nindent 2 }}
{{- end }}
containers:
- name: {{ .serviceName }}
  image: "{{ .Values.gateway.image.repository }}:{{ .Values.gateway.image.tag }}"
  imagePullPolicy: {{ .Values.gateway.image.pullPolicy }}
  {{- if .command }}
  command:
    {{- toYaml .command | nindent 4 }}
  {{- end }}
  {{- if .args }}
  args:
    {{- toYaml .args | nindent 4 }}
  {{- end }}
  {{- if .ports }}
  ports:
    {{- toYaml .ports | nindent 4 }}
  {{- end }}
  {{- if .env }}
  env:
    {{- toYaml .env | nindent 4 }}
  {{- end }}
  {{- if .resources }}
  resources:
    {{- toYaml .resources | nindent 4 }}
  {{- end }}
  # PSA baseline/restricted defaults: drop ALL caps, no priv-escalation, runtime-default seccomp.
  # netAdmin=true keeps NET_ADMIN explicitly added back (still baseline-compliant; restricted
  # disallows non-default caps so callers with netAdmin can't reach restricted).
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
      {{- if .Values.gateway.netAdmin }}
      add:
        - NET_ADMIN
      {{- end }}
    seccompProfile:
      type: RuntimeDefault
  volumeMounts:
    {{- include "cdn-gateway.volumeMounts" . | nindent 4 }}
    {{- if .extraVolumeMounts }}
    {{- toYaml .extraVolumeMounts | nindent 4 }}
    {{- end }}
{{- if .securityContext }}
securityContext:
  {{- toYaml .securityContext | nindent 2 }}
{{- end }}
volumes:
  {{- include "cdn-gateway.volumes" . | nindent 2 }}
  {{- if .extraVolumes }}
  {{- toYaml .extraVolumes | nindent 2 }}
  {{- end }}
{{- end }}

{{/*
In-cluster host:port for moq-relay's internal QUIC backend.
Caller must gate `.Values.moqRelay.internalQuicPort`; non-numeric typos
render verbatim and fail at the consumer rather than being coerced to 0.
*/}}
{{- define "cdn-gateway.moqRelayInternalAddr" -}}
{{- printf "%s-moq-relay.%s.svc.cluster.local:%s" .Release.Name .Release.Namespace (toString .Values.moqRelay.internalQuicPort) -}}
{{- end }}

{{/*
SSM multicast GROUP the moq-pub-mmtp bridge joins to receive shreds.

`shreds.ssmGroup` is the group the in-cluster shred-forwarder EMITS to, and the
bridge historically reused it for its own JOIN — so the chart could not express
"the bridge receives a channel this cluster does not produce". `shreds.bridge`
already scopes the source half of the (S,G) (`shreds.bridge.ssmSource`); this
scopes the group half the same way, so the pair can point at an off-cluster
producer while the forwarder keeps emitting its own group.

Unset (the default) resolves to `shreds.ssmGroup`, so every environment that
does not set the override renders the same manifest as before this helper
existed (verified across all six values files; the only rendered-text deltas are
these comments and the chart-version label).

Both the bridge args and the published catalog resolve the join through THIS
helper — advertising a (S,G) the bridge does not actually join is the drift that
made the catalog misinform downstream consumers.
*/}}
{{- define "cdn-gateway.shredBridgeJoinGroup" -}}
{{- .Values.shreds.bridge.ssmGroup | default .Values.shreds.ssmGroup -}}
{{- end }}

{{/*
Validate the mroute IGMP-forcing inputs before they are interpolated into the
privileged `configure-igmp-max-msf` init container's shell.

Both values reach that container as bare shell text — an sysctl node path, a
`sysctl -w` argument, and a readback comparison — in a container that runs
`privileged: true, runAsUser: 0`. So an unvalidated `inputIface` is command
injection into a root shell (`net1;cmd` renders
`FIV=/proc/sys/net/ipv4/conf/net1;cmd/force_igmp_version`, and `cmd` runs), and
the far likelier real-world case — a typo or a trailing space — silently
produces a broken privileged script instead of a render-time error. Reject both
at render, where the operator sees it.

Bounds:
  - iface: kernel IFNAMSIZ is 16 including NUL, so 15 chars max, and an ifname
    cannot contain '/' or whitespace. Leading alnum keeps '-'-prefixed names
    from being read as flags by the tools that consume it.
  - version: force_igmp_version is 0..3 (0=adaptive, 1/2/3=pinned IGMPvN).
    Anything else is refused by the kernel at write time, so failing here
    converts a fail-closed pod crash into a clear chart error.

Callers pass the values path prefix so the message names the key they set.
*/}}
{{- define "cdn-gateway.validateMrouteIgmp" -}}
{{- $iface := .iface | toString -}}
{{- if not (regexMatch "^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$" $iface) -}}
{{- fail (printf "%s.mroute.inputIface must be a valid network interface name (max 15 chars, alphanumeric start, then alphanumerics . _ -), got %q. It is interpolated into a privileged init container's shell." .prefix $iface) -}}
{{- end -}}
{{- $version := .version | toString -}}
{{- if not (regexMatch "^[0-3]$" $version) -}}
{{- fail (printf "%s.mroute.forceIgmpVersion must be 0, 1, 2 or 3 (0=kernel-adaptive, 3=pin IGMPv3 for SSM), got %q. The kernel refuses any other value." .prefix $version) -}}
{{- end -}}
{{- end }}

{{/*
The IPv6/MLD sibling of validateMrouteIgmp, for `mroute.inputIface6` and
`mroute.forceMldVersion`. Same injection surface, same reasoning — both land as
bare shell text in the `privileged: true, runAsUser: 0` init container.

Deliberately a separate helper rather than a parameterized one, because the two
families do NOT share a version range:
  - force_igmp_version is 0..3 (0=adaptive, 1/2/3=pinned IGMPvN).
  - force_mld_version is 0..2 ONLY. MLD has just two versions — MLDv1 (RFC 2710)
    and MLDv2 (RFC 3810) — so the kernel refuses 3. Reusing the IGMP validator
    would accept `forceMldVersion: 3` at render and hand the pod a write the
    kernel rejects, converting a clear chart error into a fail-closed crashloop.
*/}}
{{- define "cdn-gateway.validateMrouteMld" -}}
{{- $iface := .iface | toString -}}
{{- if not (regexMatch "^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$" $iface) -}}
{{- fail (printf "%s.mroute.inputIface6 must be a valid network interface name (max 15 chars, alphanumeric start, then alphanumerics . _ -), got %q. It is interpolated into a privileged init container's shell." .prefix $iface) -}}
{{- end -}}
{{- $version := .version | toString -}}
{{- if not (regexMatch "^[0-2]$" $version) -}}
{{- fail (printf "%s.mroute.forceMldVersion must be 0, 1 or 2 (0=kernel-adaptive, 2=pin MLDv2 for SSM), got %q. MLD has only two versions, so the kernel refuses anything above 2." .prefix $version) -}}
{{- end -}}
{{- end }}
Validate an optional image digest pin. Renders nothing; fails the render when set
to anything other than a full sha256 digest, so a typo is caught at `helm template`
rather than surfacing as an ImagePullBackOff.

Caller passes its own values path so the message names the key the operator set, plus its
component tag and (optionally) the chart-global tag, so the two pinning conventions cannot
be combined by accident:
  {{- include "cdn-gateway.validateDigest" (dict
        "digest" .Values.x.image.digest "path" "x.image.digest"
        "tag" .Values.x.image.tag "tagPath" "x.image.tag"
        "globalTag" .Values.global.imageTag) }}

Pass `globalTag` RAW -- do not pre-resolve `global.imageTag | default x.image.tag` at the
call site. The helper applies that precedence itself so it also knows WHICH key won, and
can attribute the failure to the key the operator actually set. Resolving at the call site
loses that: `global.imageTag` wins the value but the message still blames `x.image.tag`,
sending the operator to edit a key they never touched. Keeping the rule in one place is
also the point of this helper -- a per-call-site copy of the precedence expression is the
same drift the extraction removed.

Call it INSIDE the same guard as the workload it belongs to — validating a disabled
component's values would fail renders that never use them.

Why `tag` matters: onprem-k8s/production-values.yaml pins this chart's shred path by
embedding the digest IN the tag string (tag: "pinned-21006781@sha256:653eef77..."), which
renders a valid pinned reference on its own. Setting `digest` as well appends a SECOND
@sha256: -- repo:tag@sha256:A@sha256:B -- which no per-value check can catch, because both
values are individually well-formed. The check is for any `@`, not `@sha256:` specifically:
`@` is not legal in a Docker tag, so its presence already means the tag is a tag@digest
composite -- which also catches a non-sha256 algorithm. `tag`/`tagPath`/`globalTag` are
optional; omit them all and only the digest shape is checked.
*/}}
{{- define "cdn-gateway.validateDigest" -}}
{{- $path := .path -}}
{{- with .digest -}}
{{- if not (regexMatch "^sha256:[[:xdigit:]]{64}$" .) -}}
{{- fail (printf "%s must be a sha256 digest with 64 hexadecimal characters, got %q" $path .) -}}
{{- end -}}
{{- end -}}
{{/* Same precedence as every image ref in this chart unless the caller marks
   a digest-bearing component pin as authoritative. */}}
{{- $globalTag := printf "%v" (.globalTag | default "") -}}
{{- $componentTag := printf "%v" (.tag | default "") -}}
{{- $tag := $globalTag | default $componentTag -}}
{{- $tagPath := ternary "global.imageTag" (.tagPath | default "the image tag") (ne $globalTag "") -}}
{{- if and (.digestTagWins | default false) (ne $componentTag "") -}}
{{- $tag = $componentTag -}}
{{- $tagPath = .tagPath | default "the image tag" -}}
{{- end }}
{{- if and .digest (ne $tag "") -}}
{{- if contains "@" $tag -}}
{{- fail (printf "%s already carries a digest (%q), so setting %s renders a double-digest reference; pin in exactly one place" $tagPath $tag $path) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
cdn-gateway.relayCachePath -- the node directory backing the relay's LUKS cache:
the operator override or a namespace-scoped default so co-tenant relays on one
node never share a directory. The relay Deployment (sidecar mode) and the DRA
driver DaemonSet (backing-file store) MUST resolve this identically, so both
call here rather than repeating the expression.
*/}}
{{- define "cdn-gateway.relayCachePath" -}}
{{- (.Values.relay.luks).hostPath | default (printf "/var/lib/blockcast/%s/relaycache" .Release.Namespace) -}}
{{- end -}}

{{/*
cdn-gateway.mconfigVolumeSource -- where blockcastd writes gateway.mconfig, as
the body of a pod volume (the caller emits `- name: mconfig` and nindents by 8).
The relay Deployment and the DRA driver DaemonSet MUST read the same file: a
DaemonSet naming a PVC the chart does not create sits in FailedMount forever.
In PVC mode the file lives under the `configs` subPath; mounts must add
`subPath: configs` when cdn-gateway.mconfigUsesSubPath renders "true".
*/}}
{{- define "cdn-gateway.mconfigVolumeSource" -}}
{{- if .Values.gateway.configsPath -}}
hostPath:
  path: {{ .Values.gateway.configsPath }}
  type: DirectoryOrCreate
{{- else if .Values.gateway.blockcastdDataPath -}}
hostPath:
  path: {{ .Values.gateway.blockcastdDataPath }}/configs
  type: DirectoryOrCreate
{{- else -}}
persistentVolumeClaim:
  claimName: {{ include "cdn-gateway.fullname" . }}-blockcastd-data
  readOnly: true
{{- end -}}
{{- end -}}

{{- define "cdn-gateway.mconfigUsesSubPath" -}}
{{- if and (not .Values.gateway.configsPath) (not .Values.gateway.blockcastdDataPath) -}}true{{- end -}}
{{- end -}}

{{/*
cdn-gateway.draDriverName -- the DRA driver identity for THIS release:
<release>.<namespace>.luks.blockcast.io. Kubelet plugin registration is
node-scoped (/var/lib/kubelet/plugins/<name>/dra.sock), so two gateway releases
on one node need distinct names or one of their drivers never registers; the
DeviceClass selects device.driver == this and the claim's CEL indexes
device.attributes["<this>"], so the DaemonSet env, DeviceClass and claim all
render from this one helper. The driver validates the value at startup
(trafficcontrol cmd/dra-luks-plugin/main.go validateDriverName): a DNS-1123
subdomain of at most 63 bytes, the API server's ResourceSlice.spec.driver rule.
*/}}
{{- define "cdn-gateway.draDriverName" -}}
{{- $name := printf "%s.%s.luks.blockcast.io" .Release.Name .Release.Namespace -}}
{{- if gt (len $name) 63 -}}
{{- fail (printf "DRA driver name %q is %d bytes; ResourceSlice.spec.driver allows at most 63. Shorten the release name or namespace (relay.luks.dra)." $name (len $name)) -}}
{{- end -}}
{{- $name -}}
{{- end -}}
