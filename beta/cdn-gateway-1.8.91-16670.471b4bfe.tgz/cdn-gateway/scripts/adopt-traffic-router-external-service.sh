#!/usr/bin/env bash
# Adopt the existing staging TR DNS NodePort into the blockcastd Helm release.
set -euo pipefail

NAMESPACE="${NAMESPACE:-staging-blockcastd}"
RELEASE="${RELEASE:-blockcastd}"
SERVICE="${SERVICE:-${RELEASE}-traffic-router-external}"
MODE="${1:---check}"

if [[ "$MODE" != "--check" && "$MODE" != "--apply" ]]; then
  echo "usage: $0 [--check|--apply]" >&2
  exit 2
fi

require_equal() {
  local label="$1" actual="$2" expected="$3"
  if [[ "$actual" != "$expected" ]]; then
    echo "ERROR: $label is '$actual'; expected '$expected'" >&2
    exit 1
  fi
}

require_unset_or_equal() {
  local label="$1" actual="$2" expected="$3"
  if [[ -n "$actual" && "$actual" != "$expected" ]]; then
    echo "ERROR: $label is owned by '$actual'; refusing to overwrite it" >&2
    exit 1
  fi
}

command -v jq >/dev/null || {
  echo "ERROR: jq is required to validate the complete Service spec" >&2
  exit 1
}

service_json="$(kubectl get service "$SERVICE" -n "$NAMESPACE" -o json)"
resource_version="$(jq -er '.metadata.resourceVersion' <<<"$service_json")"
release_name="$(jq -r '.metadata.annotations["meta.helm.sh/release-name"] // ""' <<<"$service_json")"
release_namespace="$(jq -r '.metadata.annotations["meta.helm.sh/release-namespace"] // ""' <<<"$service_json")"
managed_by="$(jq -r '.metadata.labels["app.kubernetes.io/managed-by"] // ""' <<<"$service_json")"

normalized_spec="$(jq -cS '
  {
    type: .spec.type,
    ports: (.spec.ports | sort_by(.name) | map({name, protocol, port, targetPort, nodePort})),
    selector: .spec.selector,
    externalIPs: (.spec.externalIPs // []),
    loadBalancerIP: (.spec.loadBalancerIP // ""),
    loadBalancerSourceRanges: (.spec.loadBalancerSourceRanges // []),
    externalName: (.spec.externalName // ""),
    publishNotReadyAddresses: (.spec.publishNotReadyAddresses // false),
    sessionAffinity: (.spec.sessionAffinity // "None"),
    externalTrafficPolicy: (.spec.externalTrafficPolicy // "Cluster"),
    internalTrafficPolicy: (.spec.internalTrafficPolicy // "Cluster"),
    ipFamilyPolicy: (.spec.ipFamilyPolicy // "SingleStack"),
    ipFamilies: (.spec.ipFamilies // []),
    clusterIP: (.spec.clusterIP // ""),
    clusterIPs: (.spec.clusterIPs // []),
    healthCheckNodePort: (.spec.healthCheckNodePort // null)
  }
' <<<"$service_json")"
cluster_ip="$(jq -er '.spec.clusterIP | select(test("^([0-9]{1,3}\\.){3}[0-9]{1,3}$"))' <<<"$service_json")"
expected_old_spec="$(jq -cnS --arg release "$RELEASE" --arg clusterIP "$cluster_ip" '
  {
    type: "NodePort",
    ports: [
      {name: "dns-tcp", protocol: "TCP", port: 53, targetPort: 53, nodePort: 30053},
      {name: "dns-udp", protocol: "UDP", port: 53, targetPort: 53, nodePort: 30053}
    ],
    selector: {"app.kubernetes.io/instance": $release, "app.kubernetes.io/name": "traffic-router"},
    externalIPs: [], loadBalancerIP: "", loadBalancerSourceRanges: [], externalName: "",
    publishNotReadyAddresses: false, sessionAffinity: "None", externalTrafficPolicy: "Cluster",
    internalTrafficPolicy: "Cluster", ipFamilyPolicy: "SingleStack", ipFamilies: ["IPv4"],
    clusterIP: $clusterIP, clusterIPs: [$clusterIP], healthCheckNodePort: null
  }
')"
expected_new_spec="$(jq -cnS --arg release "$RELEASE" --arg clusterIP "$cluster_ip" '
  {
    type: "NodePort",
    ports: [
      {name: "dns-tcp", protocol: "TCP", port: 53, targetPort: 5353, nodePort: 30053},
      {name: "dns-udp", protocol: "UDP", port: 53, targetPort: 5354, nodePort: 30053}
    ],
    selector: {"app.kubernetes.io/instance": $release, "app.kubernetes.io/name": "traffic-router"},
    externalIPs: [], loadBalancerIP: "", loadBalancerSourceRanges: [], externalName: "",
    publishNotReadyAddresses: false, sessionAffinity: "None", externalTrafficPolicy: "Cluster",
    internalTrafficPolicy: "Cluster", ipFamilyPolicy: "SingleStack", ipFamilies: ["IPv4"],
    clusterIP: $clusterIP, clusterIPs: [$clusterIP], healthCheckNodePort: null
  }
')"

if [[ "$normalized_spec" != "$expected_old_spec" && "$normalized_spec" != "$expected_new_spec" ]]; then
  echo "ERROR: Service spec differs from the exact chart-managed old/new shapes; refusing adoption" >&2
  echo "actual: $normalized_spec" >&2
  exit 1
fi
require_unset_or_equal "Helm release name" "$release_name" "$RELEASE"
require_unset_or_equal "Helm release namespace" "$release_namespace" "$NAMESPACE"
require_unset_or_equal "managed-by label" "$managed_by" "Helm"

echo "ADOPTION_CHECK_OK service=$NAMESPACE/$SERVICE resourceVersion=$resource_version spec=$normalized_spec release=${release_name:-unset} releaseNamespace=${release_namespace:-unset} managedBy=${managed_by:-unset}"

if [[ "$MODE" == "--check" ]]; then
  exit 0
fi

expected_confirmation="$NAMESPACE/$SERVICE"
if [[ "${CONFIRM_HELM_ADOPTION:-}" != "$expected_confirmation" ]]; then
  echo "ERROR: set CONFIRM_HELM_ADOPTION=$expected_confirmation to apply ownership metadata" >&2
  exit 1
fi

patch="$(jq -cn \
  --argjson service "$service_json" \
  --arg resourceVersion "$resource_version" \
  --arg release "$RELEASE" \
  --arg namespace "$NAMESPACE" \
  '[{op: "test", path: "/metadata/resourceVersion", value: $resourceVersion}] +
  (if ($service.metadata.annotations | type) == "object" then [
    {op: "add", path: "/metadata/annotations/meta.helm.sh~1release-name", value: $release},
    {op: "add", path: "/metadata/annotations/meta.helm.sh~1release-namespace", value: $namespace},
    {op: "add", path: "/metadata/annotations/helm.sh~1resource-policy", value: "keep"}
  ] else [{op: "add", path: "/metadata/annotations", value: {
    "meta.helm.sh/release-name": $release,
    "meta.helm.sh/release-namespace": $namespace,
    "helm.sh/resource-policy": "keep"
  }}] end) +
  (if ($service.metadata.labels | type) == "object" then [
    {op: "add", path: "/metadata/labels/app.kubernetes.io~1managed-by", value: "Helm"}
  ] else [{op: "add", path: "/metadata/labels", value: {"app.kubernetes.io/managed-by": "Helm"}}] end)')"
if ! patch_output="$(kubectl patch service "$SERVICE" -n "$NAMESPACE" --type=json --patch "$patch" 2>&1)"; then
  echo "ERROR: atomic adoption patch failed; re-run --check before retrying" >&2
  echo "$patch_output" >&2
  exit 1
fi

adopted_json="$(kubectl get service "$SERVICE" -n "$NAMESPACE" -o json)"
require_equal "Helm release name" "$(jq -r '.metadata.annotations["meta.helm.sh/release-name"] // ""' <<<"$adopted_json")" "$RELEASE"
require_equal "Helm release namespace" "$(jq -r '.metadata.annotations["meta.helm.sh/release-namespace"] // ""' <<<"$adopted_json")" "$NAMESPACE"
require_equal "Helm resource policy" "$(jq -r '.metadata.annotations["helm.sh/resource-policy"] // ""' <<<"$adopted_json")" "keep"
require_equal "managed-by label" "$(jq -r '.metadata.labels["app.kubernetes.io/managed-by"] // ""' <<<"$adopted_json")" "Helm"
echo "ADOPTION_APPLY_OK service=$NAMESPACE/$SERVICE resourceVersion=$(jq -r '.metadata.resourceVersion' <<<"$adopted_json") release=$RELEASE releaseNamespace=$NAMESPACE managedBy=Helm resourcePolicy=keep"
