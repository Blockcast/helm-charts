#!/usr/bin/env bash
set -euo pipefail

chart_dir="$(cd "$(dirname "$0")/.." && pwd)"
rendered="$(helm template blockcastd-prereqs "$chart_dir" \
  --namespace production-blockcastd \
  --set relay.gatewayAPI.routeNamespaces[0]=production-blockcastd-sender \
  --set relay.gatewayAPI.routeNamespaces[1]=staging-blockcastd-sender)"

for namespace in production-blockcastd-sender staging-blockcastd-sender; do
  block="$(awk -v ns="$namespace" '
    /^---$/ {
      if (seen && role) { print block; exit }
      block=""; seen=0; role=0
    }
    { block=block $0 "\n" }
    /^kind: Role$/ { role=1 }
    /^  namespace: / && $0 == "  namespace: " ns { seen=1 }
    END { if (seen && role) print block }
  ' <<<"$rendered")"
  grep -Fq "namespace: $namespace" <<<"$block"
  grep -Fq 'resources: ["httproutes", "tcproutes", "udproutes", "gateways"]' <<<"$block"
  grep -Fq 'resources: ["services"]' <<<"$block"
  grep -Fq 'verbs: ["get", "list", "watch"]' <<<"$block"
done

echo "route namespace RBAC rendered with read-only access"
