{{/*
Expand the name of the chart.
*/}}
{{- define "cdn-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cdn-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cdn-gateway.labels" -}}
helm.sh/chart: {{ include "cdn-gateway.chart" . }}
{{ include "cdn-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cdn-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cdn-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cdn-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Gateway certificate path - all services use /var/opt/magma/certs
Contains gateway.crt and gateway.key from bootstrapper
*/}}
{{- define "cdn-gateway.certPath" -}}
/var/opt/magma/certs
{{- end }}

{{- /* BLO-44264: projected token an AMT relay presents to blockcastd's CDNi
       billing ingest. Each helper renders nothing unless
       gateway.cdniProducerAuth.enabled. */}}
{{- /* BLO-44264: the ServiceAccount the AMT relays run as, and therefore the
       only subject blockcastd accepts as a CDNi billing producer. A dedicated
       account while producer auth is on, so a token from any other pod on the
       shared <release>-gateway account (Traffic Router, moq-relay, ...) is not
       a producer credential. Same multiDeployment gate as the account itself
       (templates/blockcastd-rbac.yaml); off, the relays stay where they were. */}}
{{- define "cdn-gateway.amtRelayServiceAccount" -}}
{{- if and .Values.gateway.multiDeployment ((.Values.gateway).cdniProducerAuth).enabled -}}
{{ .Release.Name }}-amt-relay
{{- else -}}
{{ .Release.Name }}-gateway
{{- end -}}
{{- end }}
{{- /*
The Juniper collector's own account (BLO-44264). Its relay_id is its
Deployment name, which TokenReview cannot attest, so blockcastd pins this
subject to that one relay_id (CDNI_LOG_PRODUCER_SUBJECT_RELAY_IDS). It must
differ from the Linux relays' account, or the pin would apply to them too.
*/ -}}
{{- define "cdn-gateway.amtRelayJuniperServiceAccount" -}}
{{- if and .Values.gateway.multiDeployment ((.Values.gateway).cdniProducerAuth).enabled -}}
{{ .Release.Name }}-amt-relay-juniper
{{- else -}}
{{ .Release.Name }}-gateway
{{- end -}}
{{- end }}
{{- define "cdn-gateway.cdniProducerTokenEnv" -}}
{{- if ((.Values.gateway).cdniProducerAuth).enabled }}
- name: CDNI_PRODUCER_TOKEN_FILE
  value: /var/run/secrets/blockcast/cdni-producer/token
{{- end }}
{{- end }}
{{- define "cdn-gateway.cdniProducerTokenMount" -}}
{{- if ((.Values.gateway).cdniProducerAuth).enabled }}
- name: cdni-producer-token
  mountPath: /var/run/secrets/blockcast/cdni-producer
  readOnly: true
{{- end }}
{{- end }}
{{- define "cdn-gateway.cdniProducerTokenVolume" -}}
{{- with ((.Values.gateway).cdniProducerAuth) }}
{{- if .enabled }}
{{- if not .audience }}
{{- /* upgrade-safe: guard ships with the feature (1.8.152); no installed release can hold enabled=true with an empty audience. */}}
{{- fail "gateway.cdniProducerAuth.enabled requires gateway.cdniProducerAuth.audience" }}
{{- end }}
- name: cdni-producer-token
  projected:
    sources:
    - serviceAccountToken:
        audience: {{ .audience | quote }}
        expirationSeconds: 3600
        path: token
{{- end }}
{{- end }}
{{/*
Gateway certificate volume mounts for edge services (traffic-monitor, traffic-router, trafficserver)
Single mount point at /var/opt/magma/certs
*/}}
{{- end }}
{{- define "cdn-gateway.certVolumeMounts" -}}
- name: certs
  mountPath: /var/opt/magma/certs
  readOnly: true
{{- end }}

{{/*
Gateway certificate volume definition
*/}}
{{- define "cdn-gateway.certVolume" -}}
- name: certs
  {{- if eq .Values.gateway.certsVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.certsVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.certsVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.certsVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.certsVolume.claimName | default "gateway-certs-pvc" }}
  {{- else if eq .Values.gateway.certsVolume.type "secret" }}
  secret:
    secretName: {{ .Values.gateway.certsVolume.secretName | default "gateway-certs" }}
  {{- else }}
  secret:
    secretName: {{ .Release.Name }}-certs
  {{- end }}
{{- end }}

{{/*
Snowflake volume definition — used by blockcastd (cdn-gateway.volumes) and
the relay/cache-init init container to derive the per-gateway
device-name prefix from /etc/snowflake/snowflake.
*/}}
{{- define "cdn-gateway.snowflakeVolume" -}}
- name: snowflake
  {{- if eq .Values.gateway.snowflakeVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.snowflakeVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.snowflakeVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.snowflakeVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.snowflakeVolume.claimName | default "gateway-snowflake-pvc" }}
  {{- else if eq .Values.gateway.snowflakeVolume.type "configMap" }}
  configMap:
    name: {{ .Values.gateway.snowflakeVolume.name | default "gateway-snowflake" }}
    items:
      - key: {{ .Values.gateway.snowflakeVolume.key | default "snowflake" }}
        path: snowflake
  {{- end }}
{{- end }}

{{/*
Common volume mounts for gateway services
*/}}
{{- define "cdn-gateway.volumeMounts" -}}
- name: certs
  mountPath: /var/opt/magma/certs
{{- /* Snowflake is opt-out per-service via mountSnowflake:false (default on).
       beacond derives its identity from gateway.crt (the certs mount) and never
       reads /etc/snowflake, so it skips this RWO PVC to avoid a Multi-Attach
       fight with blockcastd when the two land on different nodes. */}}
{{- if not (and (hasKey . "mountSnowflake") (not .mountSnowflake)) }}
- name: snowflake
  mountPath: /etc/snowflake
{{- end }}
- name: blockcastd-data
  mountPath: /var/opt/magma/wal
  subPath: wal
{{- /* Certbot state (BLO-31744). Without this the ACME account key, the issued
       cert and the persisted renewal deadline all live in the container's
       ephemeral layer and are destroyed on every restart -- which voids the
       scheduler's persisted-deadline property, and makes each restart take the
       full ISSUANCE path against Let's Encrypt rather than renewing. Covers
       both CERTBOT_CONFIG_DIR (/var/opt/magma/letsencrypt) and
       CERTBOT_STATE_DIR (/var/opt/magma/certbot). Gated so the default render
       is byte-identical for every service that does not enable certbot. */}}
{{- if ((.Values.gateway).certbot).enabled }}
- name: blockcastd-data
  mountPath: /var/opt/magma/letsencrypt
  subPath: letsencrypt
- name: blockcastd-data
  mountPath: /var/opt/magma/certbot
  subPath: certbot
{{- end }}
{{- /* When gateway.configsPath is set, the configs-cdn hostPath below
       overrides /var/opt/magma/configs entirely. Mounting both targets
       the same path and helm install fails with "must be unique". */}}
{{- if not .Values.gateway.configsPath }}
- name: blockcastd-data
  mountPath: /var/opt/magma/configs
  subPath: configs
{{- end }}
{{- if .Values.gateway.rootCAPath }}
- name: rootca
  mountPath: /etc/magma/certs
  readOnly: true
{{- end }}
{{- if .Values.gateway.configsPath }}
- name: configs-cdn
  mountPath: /var/opt/magma/configs
{{- end }}
{{- if .Values.gateway.bandwidthConfigsPath }}
- name: configs-bandwidth
  mountPath: /var/opt/magma/configs/bandwidth
{{- end }}
{{- if .Values.gateway.helmAutoupdatePath }}
- name: helm-autoupdate
  mountPath: /var/opt/magma/helm
  readOnly: true
{{- end }}
{{- if .Values.maxmind.enabled }}
- name: maxmind-data
  mountPath: {{ .Values.maxmind.mountPath | default "/var/opt/magma/maxmind" }}
  readOnly: true
{{- end }}
{{- end }}

{{/*
Common volumes for gateway services
*/}}
{{- define "cdn-gateway.volumes" -}}
- name: certs
  {{- if eq .Values.gateway.certsVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.certsVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.certsVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.certsVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.certsVolume.claimName | default "gateway-certs-pvc" }}
  {{- else if eq .Values.gateway.certsVolume.type "secret" }}
  secret:
    secretName: {{ .Values.gateway.certsVolume.secretName | default "gateway-certs" }}
  {{- end }}
{{- if not (and (hasKey . "mountSnowflake") (not .mountSnowflake)) }}
{{ include "cdn-gateway.snowflakeVolume" . }}
{{- end }}
- name: blockcastd-data
  {{- if .Values.gateway.blockcastdDataPath }}
  hostPath:
    path: {{ .Values.gateway.blockcastdDataPath }}
    type: DirectoryOrCreate
  {{- else }}
  persistentVolumeClaim:
    claimName: {{ include "cdn-gateway.fullname" . }}-blockcastd-data
  {{- end }}
{{- if .Values.gateway.rootCAPath }}
- name: rootca
  hostPath:
    path: {{ .Values.gateway.rootCAPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.configsPath }}
- name: configs-cdn
  hostPath:
    path: {{ .Values.gateway.configsPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.bandwidthConfigsPath }}
- name: configs-bandwidth
  hostPath:
    path: {{ .Values.gateway.bandwidthConfigsPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.helmAutoupdatePath }}
- name: helm-autoupdate
  hostPath:
    path: {{ .Values.gateway.helmAutoupdatePath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.maxmind.enabled }}
- name: maxmind-data
  {{- if eq (.Values.maxmind.volume.type | default "persistentVolumeClaim") "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.maxmind.volume.claimName | default (printf "%s-maxmind-data" (include "cdn-gateway.fullname" .)) }}
  {{- else if eq .Values.maxmind.volume.type "hostPath" }}
  hostPath:
    path: {{ .Values.maxmind.volume.hostPath | default "/var/opt/magma/maxmind" }}
    type: DirectoryOrCreate
  {{- else }}
  emptyDir: {}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Check if PostgreSQL should be enabled.
Auto-enable when ATS ingress or Caddy/multicast dynamic services are enabled.
*/}}
{{- define "cdn-gateway.postgresqlEnabled" -}}
{{- if .Values.postgresql.enabled -}}
true
{{- else if .Values.ingress.enabled -}}
true
{{- else if .Values.multicast.enabled -}}
true
{{- else if .Values.caddy.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Gateway nodeSelector - ensures all CDN pods run on nodes with shared cert volume access
Used for: hostPath volumes or ReadWriteOnce PVCs that require single-node deployment
*/}}
{{- define "cdn-gateway.nodeSelector" -}}
{{- if .Values.gateway.nodeSelector }}
nodeSelector:
  {{- toYaml .Values.gateway.nodeSelector | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Common pod spec for gateway services
*/}}
{{- define "cdn-gateway.podSpec" -}}
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if or .nodeSelector .Values.gateway.nodeSelector .Values.nodeSelector }}
nodeSelector:
  {{- if .nodeSelector }}
  {{- toYaml .nodeSelector | nindent 2 }}
  {{- else if .Values.gateway.nodeSelector }}
  {{- toYaml .Values.gateway.nodeSelector | nindent 2 }}
  {{- else }}
  {{- toYaml .Values.nodeSelector | nindent 2 }}
  {{- end }}
{{- end }}
{{- $tolerations := .tolerations | default .Values.gateway.tolerations | default .Values.tolerations }}
{{- if $tolerations }}
tolerations:
  {{- toYaml $tolerations | nindent 2 }}
{{- end }}
containers:
- name: {{ .serviceName }}
  image: "{{ .Values.gateway.image.repository }}:{{ .Values.gateway.image.tag }}"
  imagePullPolicy: {{ .Values.gateway.image.pullPolicy }}
  {{- if .command }}
  command:
    {{- toYaml .command | nindent 4 }}
  {{- end }}
  {{- if .args }}
  args:
    {{- toYaml .args | nindent 4 }}
  {{- end }}
  {{- if .ports }}
  ports:
    {{- toYaml .ports | nindent 4 }}
  {{- end }}
  {{- if .env }}
  env:
    {{- toYaml .env | nindent 4 }}
  {{- end }}
  {{- if .resources }}
  resources:
    {{- toYaml .resources | nindent 4 }}
  {{- end }}
  # PSA baseline/restricted defaults: drop ALL caps, no priv-escalation, runtime-default seccomp.
  # netAdmin=true keeps NET_ADMIN explicitly added back (still baseline-compliant; restricted
  # disallows non-default caps so callers with netAdmin can't reach restricted).
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
      {{- if .Values.gateway.netAdmin }}
      add:
        - NET_ADMIN
      {{- end }}
    seccompProfile:
      type: RuntimeDefault
  volumeMounts:
    {{- include "cdn-gateway.volumeMounts" . | nindent 4 }}
    {{- if .extraVolumeMounts }}
    {{- toYaml .extraVolumeMounts | nindent 4 }}
    {{- end }}
{{- if .securityContext }}
securityContext:
  {{- toYaml .securityContext | nindent 2 }}
{{- end }}
volumes:
  {{- include "cdn-gateway.volumes" . | nindent 2 }}
  {{- if .extraVolumes }}
  {{- toYaml .extraVolumes | nindent 2 }}
  {{- end }}
{{- end }}

{{/*
In-cluster host:port for moq-relay's internal QUIC backend.
Caller must gate `.Values.moqRelay.internalQuicPort`; non-numeric typos
render verbatim and fail at the consumer rather than being coerced to 0.
*/}}
{{- define "cdn-gateway.moqRelayInternalAddr" -}}
{{- printf "%s-moq-relay.%s.svc.cluster.local:%s" .Release.Name .Release.Namespace (toString .Values.moqRelay.internalQuicPort) -}}
{{- end }}

{{/*
SSM multicast GROUP the moq-pub-mmtp bridge joins to receive shreds.

`shreds.ssmGroup` is the group the in-cluster shred-forwarder EMITS to, and the
bridge historically reused it for its own JOIN — so the chart could not express
"the bridge receives a channel this cluster does not produce". `shreds.bridge`
already scopes the source half of the (S,G) (`shreds.bridge.ssmSource`); this
scopes the group half the same way, so the pair can point at an off-cluster
producer while the forwarder keeps emitting its own group.

Unset (the default) resolves to `shreds.ssmGroup`, so every environment that
does not set the override renders the same manifest as before this helper
existed (verified across all six values files; the only rendered-text deltas are
these comments and the chart-version label).

Both the bridge args and the published catalog resolve the join through THIS
helper — advertising a (S,G) the bridge does not actually join is the drift that
made the catalog misinform downstream consumers.
*/}}
{{- define "cdn-gateway.shredBridgeJoinGroup" -}}
{{- .Values.shreds.bridge.ssmGroup | default .Values.shreds.ssmGroup -}}
{{- end }}

{{/*
Validate the mroute IGMP-forcing inputs before they are interpolated into the
privileged `configure-igmp-max-msf` init container's shell.

Both values reach that container as bare shell text — an sysctl node path, a
`sysctl -w` argument, and a readback comparison — in a container that runs
`privileged: true, runAsUser: 0`. So an unvalidated `inputIface` is command
injection into a root shell (`net1;cmd` renders
`FIV=/proc/sys/net/ipv4/conf/net1;cmd/force_igmp_version`, and `cmd` runs), and
the far likelier real-world case — a typo or a trailing space — silently
produces a broken privileged script instead of a render-time error. Reject both
at render, where the operator sees it.

Bounds:
  - iface: kernel IFNAMSIZ is 16 including NUL, so 15 chars max, and an ifname
    cannot contain '/' or whitespace. Leading alnum keeps '-'-prefixed names
    from being read as flags by the tools that consume it.
  - version: force_igmp_version is 0..3 (0=adaptive, 1/2/3=pinned IGMPvN).
    Anything else is refused by the kernel at write time, so failing here
    converts a fail-closed pod crash into a clear chart error.

Callers pass the values path prefix so the message names the key they set.
*/}}
{{- define "cdn-gateway.validateMrouteIgmp" -}}
{{- $iface := .iface | toString -}}
{{- if not (regexMatch "^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$" $iface) -}}
{{- /* upgrade-safe: the pod is already broken -- this name reaches `ip link` in a privileged init container and the kernel refuses it. On upgrade this is where an operator typo is caught. */}}
{{- fail (printf "%s.mroute.inputIface must be a valid network interface name (max 15 chars, alphanumeric start, then alphanumerics . _ -), got %q. It is interpolated into a privileged init container's shell." .prefix $iface) -}}
{{- end -}}
{{- $version := .version | toString -}}
{{- if not (regexMatch "^[0-3]$" $version) -}}
{{- /* upgrade-safe: the kernel refuses any other value at write time, so the pod is already fail-closed; keep catching a new typo on upgrade. */}}
{{- fail (printf "%s.mroute.forceIgmpVersion must be 0, 1, 2 or 3 (0=kernel-adaptive, 3=pin IGMPv3 for SSM), got %q. The kernel refuses any other value." .prefix $version) -}}
{{- end -}}
{{- end }}

{{/*
The IPv6/MLD sibling of validateMrouteIgmp, for `mroute.inputIface6` and
`mroute.forceMldVersion`. Same injection surface, same reasoning — both land as
bare shell text in the `privileged: true, runAsUser: 0` init container.

Deliberately a separate helper rather than a parameterized one, because the two
families do NOT share a version range:
  - force_igmp_version is 0..3 (0=adaptive, 1/2/3=pinned IGMPvN).
  - force_mld_version is 0..2 ONLY. MLD has just two versions — MLDv1 (RFC 2710)
    and MLDv2 (RFC 3810) — so the kernel refuses 3. Reusing the IGMP validator
    would accept `forceMldVersion: 3` at render and hand the pod a write the
    kernel rejects, converting a clear chart error into a fail-closed crashloop.
*/}}
{{- define "cdn-gateway.validateMrouteMld" -}}
{{- $iface := .iface | toString -}}
{{- if not (regexMatch "^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$" $iface) -}}
{{- /* upgrade-safe: same as the IPv4 sibling: the kernel already refuses this ifname, so no healthy release holds it. */}}
{{- fail (printf "%s.mroute.inputIface6 must be a valid network interface name (max 15 chars, alphanumeric start, then alphanumerics . _ -), got %q. It is interpolated into a privileged init container's shell." .prefix $iface) -}}
{{- end -}}
{{- $version := .version | toString -}}
{{- if not (regexMatch "^[0-2]$" $version) -}}
{{- /* upgrade-safe: MLD has two versions; the kernel already refuses anything above 2, so no healthy release holds it. */}}
{{- fail (printf "%s.mroute.forceMldVersion must be 0, 1 or 2 (0=kernel-adaptive, 2=pin MLDv2 for SSM), got %q. MLD has only two versions, so the kernel refuses anything above 2." .prefix $version) -}}
{{- end -}}
{{- end }}

{{/*
Validate an optional image digest pin. Renders nothing; fails the render when set
to anything other than a full sha256 digest, so a typo is caught at `helm template`
rather than surfacing as an ImagePullBackOff.

Caller passes its own values path so the message names the key the operator set, plus its
component tag and (optionally) the chart-global tag, so the two pinning conventions cannot
be combined by accident:
  {{- include "cdn-gateway.validateDigest" (dict
        "digest" .Values.x.image.digest "path" "x.image.digest"
        "tag" .Values.x.image.tag "tagPath" "x.image.tag"
        "globalTag" .Values.global.imageTag) }}

Pass `globalTag` RAW -- do not pre-resolve `global.imageTag | default x.image.tag` at the
call site. The helper applies that precedence itself so it also knows WHICH key won, and
can attribute the failure to the key the operator actually set. Resolving at the call site
loses that: `global.imageTag` wins the value but the message still blames `x.image.tag`,
sending the operator to edit a key they never touched. Keeping the rule in one place is
also the point of this helper -- a per-call-site copy of the precedence expression is the
same drift the extraction removed.

Call it INSIDE the same guard as the workload it belongs to — validating a disabled
component's values would fail renders that never use them.

Why `tag` matters: onprem-k8s/production-values.yaml pins this chart's shred path by
embedding the digest IN the tag string (tag: "pinned-21006781@sha256:653eef77..."), which
renders a valid pinned reference on its own. Setting `digest` as well appends a SECOND
@sha256: -- repo:tag@sha256:A@sha256:B -- which no per-value check can catch, because both
values are individually well-formed. The check is for any `@`, not `@sha256:` specifically:
`@` is not legal in a Docker tag, so its presence already means the tag is a tag@digest
composite -- which also catches a non-sha256 algorithm. `tag`/`tagPath`/`globalTag` are
optional; omit them all and only the digest shape is checked.
*/}}
{{- define "cdn-gateway.validateDigest" -}}
{{- $path := .path -}}
{{- with .digest -}}
{{- if not (regexMatch "^sha256:[[:xdigit:]]{64}$" .) -}}
{{- /* upgrade-safe: a malformed digest is an unpullable image ref -- the release is already broken, and an upgrade is where a new bad pin is caught. */}}
{{- fail (printf "%s must be a sha256 digest with 64 hexadecimal characters, got %q" $path .) -}}
{{- end -}}
{{- end -}}
{{/* Same precedence as every image ref in this chart unless the caller marks
   a digest-bearing component pin as authoritative. */}}
{{- $globalTag := printf "%v" (.globalTag | default "") -}}
{{- $componentTag := printf "%v" (.tag | default "") -}}
{{- $tag := $globalTag | default $componentTag -}}
{{- $tagPath := ternary "global.imageTag" (.tagPath | default "the image tag") (ne $globalTag "") -}}
{{- if and (.digestTagWins | default false) (ne $componentTag "") -}}
{{- $tag = $componentTag -}}
{{- $tagPath = .tagPath | default "the image tag" -}}
{{- end }}
{{- if and .digest (ne $tag "") -}}
{{- if contains "@" $tag -}}
{{- /* upgrade-safe: a double-digest ref is unpullable, so no healthy release holds it; catching the second pin on upgrade is the point. */}}
{{- fail (printf "%s already carries a digest (%q), so setting %s renders a double-digest reference; pin in exactly one place" $tagPath $tag $path) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
cdn-gateway.relayCachePath -- the node directory backing the relay's LUKS cache:
the operator override or a namespace-scoped default so co-tenant relays on one
node never share a directory. The relay Deployment (sidecar mode) and the DRA
driver DaemonSet (backing-file store) MUST resolve this identically, so both
call here rather than repeating the expression.
*/}}
{{- define "cdn-gateway.relayCachePath" -}}
{{- (.Values.relay.luks).hostPath | default (printf "/var/lib/blockcast/%s/relaycache" .Release.Namespace) -}}
{{- end -}}

{{/*
cdn-gateway.mconfigVolumeSource -- where blockcastd writes gateway.mconfig, as
the body of a pod volume (the caller emits `- name: mconfig` and nindents by 8).
The relay Deployment and the DRA driver DaemonSet MUST read the same file: a
DaemonSet naming a PVC the chart does not create sits in FailedMount forever.
In PVC mode the file lives under the `configs` subPath; mounts must add
`subPath: configs` when cdn-gateway.mconfigUsesSubPath renders "true".
*/}}
{{- define "cdn-gateway.mconfigVolumeSource" -}}
{{- if .Values.gateway.configsPath -}}
hostPath:
  path: {{ .Values.gateway.configsPath }}
  type: DirectoryOrCreate
{{- else if .Values.gateway.blockcastdDataPath -}}
hostPath:
  path: {{ .Values.gateway.blockcastdDataPath }}/configs
  type: DirectoryOrCreate
{{- else -}}
persistentVolumeClaim:
  claimName: {{ include "cdn-gateway.fullname" . }}-blockcastd-data
  readOnly: true
{{- end -}}
{{- end -}}

{{- define "cdn-gateway.mconfigUsesSubPath" -}}
{{- if and (not .Values.gateway.configsPath) (not .Values.gateway.blockcastdDataPath) -}}true{{- end -}}
{{- end -}}

{{/*
cdn-gateway.draDriverName -- the DRA driver identity for THIS release:
<release>.<namespace>.luks.blockcast.io. Kubelet plugin registration is
node-scoped (/var/lib/kubelet/plugins/<name>/dra.sock), so two gateway releases
on one node need distinct names or one of their drivers never registers; the
DeviceClass selects device.driver == this and the claim's CEL indexes
device.attributes["<this>"], so the DaemonSet env, DeviceClass and claim all
render from this one helper. The driver validates the value at startup
(trafficcontrol cmd/dra-luks-plugin/main.go validateDriverName): a DNS-1123
subdomain of at most 63 bytes, the API server's ResourceSlice.spec.driver rule.
*/}}
{{- define "cdn-gateway.draDriverName" -}}
{{- $name := printf "%s.%s.luks.blockcast.io" .Release.Name .Release.Namespace -}}
{{- if gt (len $name) 63 -}}
{{- /* upgrade-safe: derived from release name + namespace, not from operator values -- it cannot change under a release, and an over-long name never registered with kubelet. */}}
{{- fail (printf "DRA driver name %q is %d bytes; ResourceSlice.spec.driver allows at most 63. Shorten the release name or namespace (relay.luks.dra)." $name (len $name)) -}}
{{- end -}}
{{- $name -}}
{{- end -}}

{{/*
Render a label map as YAML, dropping any key whose value is nil or empty.

BLO-34399. An overlay that "removes" an inherited extraSelectorLabels key by
setting it to null leaves the KEY behind: helm only strips nulls for keys the
chart itself declares, and the chart declares `extraSelectorLabels: {}` with no
sub-keys. `toYaml` then emits `key: null`, which Kubernetes decodes into an
empty-string label. In spec.selector — which is IMMUTABLE — that silently turns
a 2-key selector into a 4-key one, and every subsequent `helm upgrade` fails
with `field is immutable`, forever.

Emits nothing at all when every value is empty, so call sites can guard with
`with` and keep the surrounding block from rendering a bare `{}`.

Values are stringified (`printf "%v"`), so `key: true` renders as `key: "true"`
and `key: 123` as `key: "123"`. That is deliberate: label maps are
map[string]string and Kubernetes rejects a bare YAML bool or int there. Note
the emptiness test is `ne $s ""`, not truthiness -- `0` and `false` are
legitimate label values and are kept.
*/}}
{{- define "cdn-gateway.cleanLabels" -}}
{{- $out := dict -}}
{{- range $k, $v := . -}}
{{- if not (kindIs "invalid" $v) -}}
{{- $s := printf "%v" $v -}}
{{- if ne $s "" -}}
{{- $_ := set $out $k $s -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if $out -}}
{{- toYaml $out -}}
{{- end -}}
{{- end }}

{{/*
cdn-gateway.failOnInstall -- a hard `fail` scoped to `helm install`.

Use this for any guard that can fire on values an ALREADY-INSTALLED release
holds. magmad's in-pod helm loop upgrades each tenant with that release's
*stored* values (BLO-34691), so such a guard has no delivery path for its own
remedy: the upgrade that would carry the satisfying key is the upgrade the
guard rejects, and the namespace's chart loop then freezes on every attempt,
forever, with no backoff. Measured four times on three distinct guards --
BLO-30575 and BLO-34827 (amtRelay.mirrorVlan), BLO-35573
(relay.gatewayAPI.httpsCertificateRefs), BLO-39758 (multicast.ha). Generalised
in BLO-39762; the shape is #2090's, which fixed the third of those.

An install is different: it gets whatever values it is invoked with, so the
remedy IS deliverable there and failing closed is right. Scope the fail to
install and let the upgrade path render the pre-guard behaviour -- which is
what the frozen release is already running. Freezing does not repair that
shape; it only also blocks every unrelated fix queued behind it.

Do NOT use this for a guard that can only fire on a value an operator
affirmatively set to something already broken at runtime: a >15-char netdev
name, a double-digest image ref, an out-of-range IGMP version, a stateDir the
collector refuses. Those must keep failing on upgrade -- an upgrade is exactly
where they catch a new typo on its way in, and no previously-healthy release
can be holding the shape they reject. Same test for a guard that shipped in
the same commit as the feature it guards: no pre-existing release can have
that feature enabled, so it cannot fire on stored values.

Usage: {{- include "cdn-gateway.failOnInstall" (dict "r" $ "msg" "...") }}

tests/test-upgrade-safe-guards.sh enforces the choice: every `fail` AND every
`required` in templates/ must either route through here or carry a single-line
`upgrade-safe:` marker comment directly above it, saying why freezing an
existing release is the correct outcome. `required` is covered because it
aborts the render identically and so carries the identical hazard -- do not
read "every fail" as leaving the other spelling a way around the contract. It
has no install-scoped form, so a `required` that CAN fire on stored values must
be restructured into an explicit `if` + this helper rather than labeled.
*/}}
{{- define "cdn-gateway.failOnInstall" -}}
{{- if .r.Release.IsInstall }}{{- fail .msg }}{{- end -}}
{{- end -}}
