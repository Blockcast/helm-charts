# `amtRelayLinux.*` — Linux AMT relay coexistence (BLO-8758)

Opt-in second AMT relay Deployment that renders **alongside** the existing
juniper relay (`amtRelay.*`) in the same chart. Off by default; turning it on
adds a `<release>-amt-relay-linux` Deployment + Service + WAL PVC without
touching the juniper render.

## Why this exists

Production today runs only a juniper MX204 relay (`amtRelay.relayType: juniper`,
anycast `69.25.95.1`). The v6 multicast byte-billing path proven on staging is
**linux-relay-specific** and doesn't map onto the juniper path:

- `linux-amt#76` — v6 mroute-input iface (merged + staging-deployed + live-validated).
- `magma#1073` — cast v6 multicast egress route + relay `enable-v6-mcast-forwarding` init.
- Live staging proof: `amt-verify --family v6 → byte_count > 0`.

To bring v6 byte-billing to prod we need a linux relay in `production-blockcastd`.
This chart toggle is the receive-path infrastructure. PR2 (a follow-up overlay)
flips it on; this PR ships the chart shape only.

## Topology when enabled

```text
production-blockcastd
├── blockcastd-amt-relay           (juniper, anycast 69.25.95.1, untouched)
└── blockcastd-amt-relay-linux     (NEW — opt-in via amtRelayLinux.enabled=true)
    ├── advertisedIP=69.25.95.128  (separate LB-IPAM)
    ├── managed kernel module      (amt-kmod-installer init, uname -r-matched)
    ├── eBPF tunnel tracker        (CAP_BPF + CAP_PERFMON, USE_EBPF=true)
    └── WAL PVC                    (separate from juniper relay's WAL)
```

The two relays do not share VIPs, WAL volumes, or label selectors. The juniper
relay's `Service` selects `app.kubernetes.io/name=amt-relay`; the linux relay
selects `app.kubernetes.io/name=amt-relay-linux`.

## Defaults (chart-level)

The full `amtRelayLinux:` block lives in `values.yaml` (~99 lines, all commented).
Defaults at chart level are:

| Key                                       | Default  | Purpose                                                        |
|-------------------------------------------|----------|----------------------------------------------------------------|
| `amtRelayLinux.enabled`                   | `false`  | Master switch. Off → renders zero new docs.                    |
| `amtRelayLinux.replicas`                  | `0`      | Dormant even if enabled, until PR2 overlay flips to 1.         |
| `amtRelayLinux.kmod.enabled`              | `true`   | Install the host AMT kernel module from `amt-kmod` init image. |
| `amtRelayLinux.kmod.kernelVersion`        | required | Must match `uname -r` on the target node. Fails render loud.   |
| `amtRelayLinux.useEbpf`                   | `"true"` | Enable eBPF tunnel-tracker stats. See [useEbpf gotcha](#useebpf-is-a-string-not-a-bool) below. |
| `amtRelayLinux.enableEbpfBilling`         | `"true"` | Per-(gw × S,G) FlowEvents for the BLO-3686 jflow billing path. |
| `amtRelayLinux.amtAstats.primarySource`   | `"ebpf"` | Shaper PrimarySource filter; required to accept eBPF events.   |
| `amtRelayLinux.walPersistence.enabled`    | `true`   | Persistent WAL volume on `ceph-rbd`; matches juniper default.  |

## Key behaviors

### nodeSelector fallback chain

Mirrors the juniper template exactly: `amtRelayLinux.nodeSelector` →
`gateway.nodeSelector` → `.Values.nodeSelector`. Without this chain, an
operator who turns the toggle on without an explicit
`amtRelayLinux.nodeSelector` would get the privileged hostPath pod
(mounts `/lib/modules` + `/sys`, installs a kernel module via the
`amt-kmod-installer` init) scheduling on any node. The kmod-installer
crashloops on vermagic mismatch (fail-loud), but that's a backstop, not the
right primary defense.

PR2's `values_prod.yaml` overlay sets `amtRelayLinux.nodeSelector` directly
(usually `blockcast.net/amt-relay-active: "true"`), so the fallback is
defensive — not load-bearing in production.

### `useEbpf` is a string, not a bool

`amtRelayLinux.useEbpf` is a quoted string (`"true"` / `"false"`) to match the
shape of `USE_EBPF` env var output. Two footguns the template guards against:

1. **`if .Values.amtRelayLinux.useEbpf`** (Go-template-truthy) treats any
   non-empty string as true — so a literal `useEbpf: "false"` would still
   add `BPF`/`PERFMON` caps while `USE_EBPF=false` in env. Confusing and
   inconsistent.
2. **`default "true"`** (Sprig) treats bool `false` as the empty value and
   substitutes `"true"`, inverting an operator's `useEbpf: false`.

The template normalizes once via `hasKey + toString` at the top:

```gotemplate
{{- $useEbpfStr := "true" -}}
{{- if and (.Values.amtRelayLinux) (hasKey .Values.amtRelayLinux "useEbpf") -}}
{{- $useEbpfStr = .Values.amtRelayLinux.useEbpf | toString -}}
{{- end -}}
```

Both the env var (`value: {{ $useEbpfStr | quote }}`) and the cap gate
(`{{- if eq $useEbpfStr "true" }}`) read the same normalized variable, so
they can't drift. Works for both string `"true"`/`"false"` AND bool
`true`/`false` operator inputs.

### `MROUTE_INPUT_IFACE` must be `net1` in prod (not `net2`)

The retired canary (`blockcastd-amt-relay-ebpf-v4-canary`) used
`MROUTE_INPUT_IFACE=net2` — that was the `production-ebpf-v4-external`
macvlan on `eth0`, which has no IPAM and no upstream multicast. The chart
default is `net1` (the `vpp-mcast` Multus NAD on `ens20` carrying VLAN 40
multicast). Validated against live prod source `(232.99.0.10, 69.25.95.101)`
during the BLO-8758 spike (see `next-session-2026-06-02g-*.md`).

### Always-rendered `replicas` and `managed: "true"` label

The linux template always renders `replicas: {{ … | default 0 }}` and carries
the pod label `managed: "true"`. This is intentional and consistent with all
13 peer gateway-component templates (`ingress-cache`, `multicast`, `beacond`,
`pob`, `cast`, `moq-relay`, `traffic-router`, …). No `cdn_operator`/k8s_manager
runs in the cluster that would compete for replica ownership (verified via
`kubectl get deploy -A` 2026-06-02), so helm cleanly owns this field.

Worth re-verifying when PR2 flips `replicas > 0` in case operator-side
ownership ever lands.

## Tests

`tests/test-amt-relay-linux.sh` (wired into `cdn-integ-test.yml` helm-template-tests)
covers 46 assertions across 8 test sections:

| #  | Coverage                                                                            |
|----|-------------------------------------------------------------------------------------|
| 1  | Defaults render zero new docs (off-by-default invariant).                           |
| 2  | Enabled with prod overlay renders the spike-validated config (MROUTE iface, eBPF). |
| 3  | Service with LB-IPAM annotations.                                                   |
| 4  | WAL PVC compound gating (`enabled` AND `walPersistence.enabled`).                   |
| 5  | `kmod.kernelVersion` is required when enabled (fails render loud).                  |
| 6  | Juniper render is **byte-identical** with toggle on vs off.                         |
| 7  | nodeSelector fallback chain (5 precedence assertions).                              |
| 8  | useEbpf gate suppresses caps for both string and bool `false`; env+cap consistent.  |

Local run:

```bash
cd cdn/gateway/helm/cdn-gateway-orc8r
bash tests/test-amt-relay-linux.sh
# PASS=46  FAIL=0
```

## PR1 / PR2 split

This PR (PR1) ships the chart infrastructure **only**. Defaults are off; no
environment behavior changes at merge. The next step (PR2) is a small
`values_prod.yaml` / `production-values.yaml` overlay that turns the toggle on:

```yaml
amtRelayLinux:
  enabled: true
  replicas: 1
  image:
    tag: "<sha-pinned>"
  advertisedIP: "69.25.95.128"
  kmod:
    kernelVersion: "6.8.0-117-generic"
    image: harbor.blockcast.net/amt-kmod/amt-kmod
    tag: "6.8.0-117-generic-mldv2-setsockopt-9c2b1c3"
  podAnnotations:
    k8s.v1.cni.cncf.io/networks: "vpp-mcast"
    config.cilium.io/disable-source-ip-verification: "true"
  nodeSelector:
    blockcast.net/amt-relay-active: "true"
    blockcast.net/amt-kmod-netlinkfix: "6.8.0-117"
  service:
    annotations:
      io.cilium/lb-ipam-ips: "69.25.95.128"
      lbipam.cilium.io/sharing-key: "blockcastd-relay"
```

PR2 should land only after Phase 0.5b (AMT response-path validation from an
internal gateway, not devbox-via-MX204) completes. See the BLO-8758 handoff
notes for the spike status.

## Future cleanup (Phase 4)

Once the linux relay is stable in prod:

- Delete `blockcastd-amt-relay-ebpf-v4-canary` Deployment.
- Delete the `.146` LB Service (canary's VIP).
- Delete the `production-ebpf-v4-external` NetworkAttachmentDefinition (unreferenced).
- DRY the linux template + juniper template into a shared `_amt-relay.tpl`
  helper. Deferred from PR1 because refactoring `amt-relay-deployment.yaml`
  while it serves live CDNi billing carries unnecessary risk.

## References

- BLO-8758 — *Stand up a production linux AMT relay alongside the juniper MX204 relay* (parent issue).
- `magma#1079` — this PR (chart toggle).
- `linux-amt#76` — v6 mroute-input iface (the kernel side this depends on).
- `magma#1073` — cast v6 multicast egress + v6-fwd init.
- Adjacent docs in this chart: [`ARCHITECTURE.md`](./ARCHITECTURE.md) (egress patterns), [`SECURITY.md`](./SECURITY.md) (PSA / capability story).
- Adjacent docs in `linux-amt`: `docs/architecture/BLOCKCAST.md`, `docs/KERNEL_MODULE.md`.
