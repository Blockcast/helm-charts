#!/usr/bin/env bash
# Helm template tests for QUIC catch-all routing.
#
# Contract: when moqRelay is enabled (with or without internalQuicPort/quicSNI),
# the `-quic` UDPRoute must be a plain-UDP catch-all (no annotations), so
# caddy_watcher's pushQUICServer resolves the default backend via the
# annotation-driven UDPRoute path documented in
# trafficcontrol/blockcast/ingress/caddy_watcher.go:781 (BLO-2470 fix C):
#
#   defaultBackend := w.QUICDefaultBackend          // L4_QUIC_DEFAULT_BACKEND env
#   if defaultBackend == "" {
#       // fall through to highest-priority plain-UDP UDPRoute (no SNI/ALPN)
#       ...
#   }
#
# Failure mode this test pins down:
#   - When `-quic` carries `blockcast.net/quic-alpn`, browser WebTransport
#     (which negotiates with ALPN=h3, NOT in the list) does not match any
#     ALPN rule, falls to the catch-all, and reaches L4_QUIC_DEFAULT_BACKEND.
#   - Chart used to set L4_QUIC_DEFAULT_BACKEND to the *internal* mTLS port
#     (4453, ED25519 gateway cert), causing Chrome's WT handshake to fail
#     with `NoSignatureSchemesInCommon`. The RKS-served LE cert sat on the
#     *external* port (4443) unreachable by browsers.
#
# Run from the chart root:
#   bash tests/test-quic-routing.sh
#
# Requires: helm (any v3), awk

set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

run_helm() {
  helm template "$RELEASE" "$CHART_DIR" "$@" 2>&1
}

# Render with moqRelay enabled + Gateway API enabled (UDPRoutes only render
# under that gate) + the staging-shaped values that triggered the original
# bug (internalQuicPort + quicSNI both set).
OUTPUT=$(run_helm \
  --set moqRelay.enabled=true \
  --set moqRelay.internalQuicPort=4453 \
  --set moqRelay.quicSNI="moq-relay.*.bcast.id" \
  --set relay.gatewayAPI.enabled=true)

# --- Assertion 1: `-quic` UDPRoute must have NO annotations.
# It is the catch-all default; the converter at
# blockcast/ingress/caddy_watcher.go:781 only treats UDPRoutes without
# QuicSNI AND without QuicALPN as the plain-UDP catch-all.
assert_quic_udproute_has_no_annotations() {
  local quic_block
  quic_block=$(echo "$OUTPUT" | awk -v want="${RELEASE}-quic" '
    /^---/                       { in_block=0; matched=0; saw_meta=0 }
    /^kind: UDPRoute/            { in_block=1 }
    in_block && /^  name: /      {
      n=$0; sub(/^  name: /, "", n)
      if (n == want) { matched=1; print "kind: UDPRoute"; print $0 }
      else           { in_block=0 }
    }
    matched && /^  [a-z]/        { print $0 }
    matched && /^---/            { matched=0 }
  ')
  if [[ -z "$quic_block" ]]; then
    echo "  FAIL: ${RELEASE}-quic UDPRoute not rendered"
    FAIL=$((FAIL + 1)); return
  fi
  if echo "$quic_block" | grep -qE '^\s+annotations:'; then
    echo "  FAIL: ${RELEASE}-quic UDPRoute has annotations (must be plain-UDP catch-all)"
    echo "$quic_block" | sed 's/^/    /'
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: ${RELEASE}-quic UDPRoute is plain-UDP (no annotations)"
  PASS=$((PASS + 1))
}

# --- Assertion 2: `-quic-internal` UDPRoute must keep its SNI annotation +
# priority 200. (Regression guard — this is the route that splits cast→relay
# mTLS traffic off the catch-all.)
assert_quic_internal_keeps_sni_routing() {
  local internal_block
  internal_block=$(echo "$OUTPUT" | awk -v want="${RELEASE}-quic-internal" '
    /^---/                       { in_block=0; matched=0 }
    /^kind: UDPRoute/            { in_block=1 }
    in_block && /^  name: /      {
      n=$0; sub(/^  name: /, "", n)
      if (n == want) { matched=1; print "kind: UDPRoute"; print $0 }
      else           { in_block=0 }
    }
    matched && /^  [a-z]/        { print $0 }
    matched && /^---/            { matched=0 }
    matched && /^    /           { print $0 }
  ')
  if [[ -z "$internal_block" ]]; then
    echo "  FAIL: ${RELEASE}-quic-internal UDPRoute not rendered"
    FAIL=$((FAIL + 1)); return
  fi
  if ! echo "$internal_block" | grep -qE 'blockcast\.net/quic-sni:'; then
    echo "  FAIL: ${RELEASE}-quic-internal missing blockcast.net/quic-sni annotation"
    FAIL=$((FAIL + 1)); return
  fi
  if ! echo "$internal_block" | grep -qE 'blockcast\.net/priority:[[:space:]]*"?200"?'; then
    echo "  FAIL: ${RELEASE}-quic-internal missing blockcast.net/priority: 200"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: ${RELEASE}-quic-internal keeps SNI + priority annotations"
  PASS=$((PASS + 1))
}

# --- Assertion 3: caddy-frontend container must NOT carry L4_QUIC_DEFAULT_BACKEND.
# This env was the BLO-2470 stopgap that has been superseded by the annotation
# pipeline (templates/relay/gateway-api.yaml UDPRoutes). Re-introducing it
# forces a single default for ALL unmatched QUIC traffic — which on the
# pre-fix chart pointed at the mTLS-required internal port and broke
# browser WebTransport.
assert_no_l4_quic_default_backend_env() {
  if echo "$OUTPUT" | grep -qE '^\s+(- )?name:\s*L4_QUIC_DEFAULT_BACKEND\b'; then
    echo "  FAIL: caddy-frontend container has L4_QUIC_DEFAULT_BACKEND env (must use annotation pipeline)"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: L4_QUIC_DEFAULT_BACKEND env tombstoned"
  PASS=$((PASS + 1))
}

# --- Assertion 4: dead annotation `blockcast.net/quic-internal-backend`
# must not be emitted. The converter at
# blockcast/ingress/gateway/annotations.go has no constant for it; it is
# silently dropped. Emitting it gives the false impression that it drives
# routing — keep the chart honest about what is consumed.
assert_no_quic_internal_backend_annotation() {
  if echo "$OUTPUT" | grep -qE 'blockcast\.net/quic-internal-backend:'; then
    echo "  FAIL: blockcast.net/quic-internal-backend annotation present (dead annotation, converter does not consume)"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: dead annotation blockcast.net/quic-internal-backend removed"
  PASS=$((PASS + 1))
}

echo "=== test-quic-routing.sh ==="
assert_quic_udproute_has_no_annotations
assert_quic_internal_keeps_sni_routing
assert_no_l4_quic_default_backend_env
assert_no_quic_internal_backend_annotation
echo
echo "PASS=$PASS FAIL=$FAIL"
[[ $FAIL -eq 0 ]]
