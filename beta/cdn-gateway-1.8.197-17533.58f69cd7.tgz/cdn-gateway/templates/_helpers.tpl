{{/*
Expand the name of the chart.
*/}}
{{- define "cdn-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cdn-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cdn-gateway.labels" -}}
helm.sh/chart: {{ include "cdn-gateway.chart" . }}
{{ include "cdn-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cdn-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cdn-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cdn-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Gateway certificate path - all services use /var/opt/magma/certs
Contains gateway.crt and gateway.key from bootstrapper
*/}}
{{- define "cdn-gateway.certPath" -}}
/var/opt/magma/certs
{{- end }}

{{- /* BLO-44264: projected token an AMT relay presents to blockcastd's CDNi
       billing ingest. Each helper renders nothing unless
       gateway.cdniProducerAuth.enabled. */}}
{{- /* BLO-44264: the ServiceAccount the AMT relays run as, and therefore the
       only subject blockcastd accepts as a CDNi billing producer. A dedicated
       account while producer auth is on, so a token from any other pod on the
       shared <release>-gateway account (Traffic Router, moq-relay, ...) is not
       a producer credential. Same multiDeployment gate as the account itself
       (templates/blockcastd-rbac.yaml); off, the relays stay where they were. */}}
{{- define "cdn-gateway.amtRelayServiceAccount" -}}
{{- if and .Values.gateway.multiDeployment ((.Values.gateway).cdniProducerAuth).enabled -}}
{{ .Release.Name }}-amt-relay
{{- else -}}
{{ .Release.Name }}-gateway
{{- end -}}
{{- end }}
{{- /*
The Juniper collector's own account (BLO-44264). Its relay_id is its
Deployment name, which TokenReview cannot attest, so blockcastd pins this
subject to that one relay_id (CDNI_LOG_PRODUCER_SUBJECT_RELAY_IDS). It must
differ from the Linux relays' account, or the pin would apply to them too.
*/ -}}
{{- define "cdn-gateway.amtRelayJuniperServiceAccount" -}}
{{- if and .Values.gateway.multiDeployment ((.Values.gateway).cdniProducerAuth).enabled -}}
{{ .Release.Name }}-amt-relay-juniper
{{- else -}}
{{ .Release.Name }}-gateway
{{- end -}}
{{- end }}
{{- define "cdn-gateway.cdniProducerTokenEnv" -}}
{{- if ((.Values.gateway).cdniProducerAuth).enabled }}
- name: CDNI_PRODUCER_TOKEN_FILE
  value: /var/run/secrets/blockcast/cdni-producer/token
{{- end }}
{{- end }}
{{- define "cdn-gateway.cdniProducerTokenMount" -}}
{{- if ((.Values.gateway).cdniProducerAuth).enabled }}
- name: cdni-producer-token
  mountPath: /var/run/secrets/blockcast/cdni-producer
  readOnly: true
{{- end }}
{{- end }}
{{- define "cdn-gateway.cdniProducerTokenVolume" -}}
{{- with ((.Values.gateway).cdniProducerAuth) }}
{{- if .enabled }}
{{- if not .audience }}
{{- /* upgrade-safe: guard ships with the feature (1.8.152); no installed release can hold enabled=true with an empty audience. */}}
{{- fail "gateway.cdniProducerAuth.enabled requires gateway.cdniProducerAuth.audience" }}
{{- end }}
- name: cdni-producer-token
  projected:
    sources:
    - serviceAccountToken:
        audience: {{ .audience | quote }}
        expirationSeconds: 3600
        path: token
{{- end }}
{{- end }}
{{/*
Gateway certificate volume mounts for edge services (traffic-monitor, traffic-router, trafficserver)
Single mount point at /var/opt/magma/certs
*/}}
{{- end }}
{{- define "cdn-gateway.certVolumeMounts" -}}
- name: certs
  mountPath: /var/opt/magma/certs
  readOnly: true
{{- end }}

{{/*
Gateway certificate volume definition
*/}}
{{- define "cdn-gateway.certVolume" -}}
- name: certs
  {{- if eq .Values.gateway.certsVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.certsVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.certsVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.certsVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.certsVolume.claimName | default "gateway-certs-pvc" }}
  {{- else if eq .Values.gateway.certsVolume.type "secret" }}
  secret:
    secretName: {{ .Values.gateway.certsVolume.secretName | default "gateway-certs" }}
  {{- else }}
  secret:
    secretName: {{ .Release.Name }}-certs
  {{- end }}
{{- end }}

{{/*
Snowflake volume definition — used by blockcastd (cdn-gateway.volumes) and
the relay/cache-init init container to derive the per-gateway
device-name prefix from /etc/snowflake/snowflake.
*/}}
{{- define "cdn-gateway.snowflakeVolume" -}}
- name: snowflake
  {{- if eq .Values.gateway.snowflakeVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.snowflakeVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.snowflakeVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.snowflakeVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.snowflakeVolume.claimName | default "gateway-snowflake-pvc" }}
  {{- else if eq .Values.gateway.snowflakeVolume.type "configMap" }}
  configMap:
    name: {{ .Values.gateway.snowflakeVolume.name | default "gateway-snowflake" }}
    items:
      - key: {{ .Values.gateway.snowflakeVolume.key | default "snowflake" }}
        path: snowflake
  {{- end }}
{{- end }}

{{/*
Common volume mounts for gateway services
*/}}
{{- define "cdn-gateway.volumeMounts" -}}
- name: certs
  mountPath: /var/opt/magma/certs
{{- /* Snowflake is opt-out per-service via mountSnowflake:false (default on).
       beacond derives its identity from gateway.crt (the certs mount) and never
       reads /etc/snowflake, so it skips this RWO PVC to avoid a Multi-Attach
       fight with blockcastd when the two land on different nodes. */}}
{{- if not (and (hasKey . "mountSnowflake") (not .mountSnowflake)) }}
- name: snowflake
  mountPath: /etc/snowflake
{{- end }}
- name: blockcastd-data
  mountPath: /var/opt/magma/wal
  subPath: wal
{{- /* Certbot state (BLO-31744). Without this the ACME account key, the issued
       cert and the persisted renewal deadline all live in the container's
       ephemeral layer and are destroyed on every restart -- which voids the
       scheduler's persisted-deadline property, and makes each restart take the
       full ISSUANCE path against Let's Encrypt rather than renewing. Covers
       both CERTBOT_CONFIG_DIR (/var/opt/magma/letsencrypt) and
       CERTBOT_STATE_DIR (/var/opt/magma/certbot). Gated so the default render
       is byte-identical for every service that does not enable certbot. */}}
{{- if ((.Values.gateway).certbot).enabled }}
- name: blockcastd-data
  mountPath: /var/opt/magma/letsencrypt
  subPath: letsencrypt
- name: blockcastd-data
  mountPath: /var/opt/magma/certbot
  subPath: certbot
{{- end }}
{{- /* When gateway.configsPath is set, the configs-cdn hostPath below
       overrides /var/opt/magma/configs entirely. Mounting both targets
       the same path and helm install fails with "must be unique". */}}
{{- if not .Values.gateway.configsPath }}
- name: blockcastd-data
  mountPath: /var/opt/magma/configs
  subPath: configs
{{- end }}
{{- if .Values.gateway.rootCAPath }}
- name: rootca
  mountPath: /etc/magma/certs
  readOnly: true
{{- end }}
{{- if .Values.gateway.configsPath }}
- name: configs-cdn
  mountPath: /var/opt/magma/configs
{{- end }}
{{- if .Values.gateway.bandwidthConfigsPath }}
- name: configs-bandwidth
  mountPath: /var/opt/magma/configs/bandwidth
{{- end }}
{{- if .Values.gateway.helmAutoupdatePath }}
- name: helm-autoupdate
  mountPath: /var/opt/magma/helm
  readOnly: true
{{- end }}
{{- if .Values.maxmind.enabled }}
- name: maxmind-data
  mountPath: {{ .Values.maxmind.mountPath | default "/var/opt/magma/maxmind" }}
  readOnly: true
{{- end }}
{{- end }}

{{/*
Common volumes for gateway services
*/}}
{{- define "cdn-gateway.volumes" -}}
- name: certs
  {{- if eq .Values.gateway.certsVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.certsVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.certsVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.certsVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.certsVolume.claimName | default "gateway-certs-pvc" }}
  {{- else if eq .Values.gateway.certsVolume.type "secret" }}
  secret:
    secretName: {{ .Values.gateway.certsVolume.secretName | default "gateway-certs" }}
  {{- end }}
{{- if not (and (hasKey . "mountSnowflake") (not .mountSnowflake)) }}
{{ include "cdn-gateway.snowflakeVolume" . }}
{{- end }}
- name: blockcastd-data
  {{- if .Values.gateway.blockcastdDataPath }}
  hostPath:
    path: {{ .Values.gateway.blockcastdDataPath }}
    type: DirectoryOrCreate
  {{- else }}
  persistentVolumeClaim:
    claimName: {{ include "cdn-gateway.fullname" . }}-blockcastd-data
  {{- end }}
{{- if .Values.gateway.rootCAPath }}
- name: rootca
  hostPath:
    path: {{ .Values.gateway.rootCAPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.configsPath }}
- name: configs-cdn
  hostPath:
    path: {{ .Values.gateway.configsPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.bandwidthConfigsPath }}
- name: configs-bandwidth
  hostPath:
    path: {{ .Values.gateway.bandwidthConfigsPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.helmAutoupdatePath }}
- name: helm-autoupdate
  hostPath:
    path: {{ .Values.gateway.helmAutoupdatePath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.maxmind.enabled }}
- name: maxmind-data
  {{- if eq (.Values.maxmind.volume.type | default "persistentVolumeClaim") "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.maxmind.volume.claimName | default (printf "%s-maxmind-data" (include "cdn-gateway.fullname" .)) }}
  {{- else if eq .Values.maxmind.volume.type "hostPath" }}
  hostPath:
    path: {{ .Values.maxmind.volume.hostPath | default "/var/opt/magma/maxmind" }}
    type: DirectoryOrCreate
  {{- else }}
  emptyDir: {}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Check if PostgreSQL should be enabled.
Auto-enable when ATS ingress or Caddy/multicast dynamic services are enabled.
*/}}
{{- define "cdn-gateway.postgresqlEnabled" -}}
{{- if .Values.postgresql.enabled -}}
true
{{- else if .Values.ingress.enabled -}}
true
{{- else if .Values.multicast.enabled -}}
true
{{- else if .Values.caddy.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Gateway nodeSelector - ensures all CDN pods run on nodes with shared cert volume access
Used for: hostPath volumes or ReadWriteOnce PVCs that require single-node deployment
*/}}
{{- define "cdn-gateway.nodeSelector" -}}
{{- if .Values.gateway.nodeSelector }}
nodeSelector:
  {{- toYaml .Values.gateway.nodeSelector | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Common pod spec for gateway services
*/}}
{{- define "cdn-gateway.podSpec" -}}
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if or .nodeSelector .Values.gateway.nodeSelector .Values.nodeSelector }}
nodeSelector:
  {{- if .nodeSelector }}
  {{- toYaml .nodeSelector | nindent 2 }}
  {{- else if .Values.gateway.nodeSelector }}
  {{- toYaml .Values.gateway.nodeSelector | nindent 2 }}
  {{- else }}
  {{- toYaml .Values.nodeSelector | nindent 2 }}
  {{- end }}
{{- end }}
{{- $tolerations := .tolerations | default .Values.gateway.tolerations | default .Values.tolerations }}
{{- if $tolerations }}
tolerations:
  {{- toYaml $tolerations | nindent 2 }}
{{- end }}
containers:
- name: {{ .serviceName }}
  image: "{{ .Values.gateway.image.repository }}:{{ .Values.gateway.image.tag }}{{- with .Values.gateway.image.digest }}@{{ . }}{{- end }}"
  imagePullPolicy: {{ .Values.gateway.image.pullPolicy }}
  {{- if .command }}
  command:
    {{- toYaml .command | nindent 4 }}
  {{- end }}
  {{- if .args }}
  args:
    {{- toYaml .args | nindent 4 }}
  {{- end }}
  {{- if .ports }}
  ports:
    {{- toYaml .ports | nindent 4 }}
  {{- end }}
  {{- if .env }}
  env:
    {{- toYaml .env | nindent 4 }}
  {{- end }}
  {{- if .resources }}
  resources:
    {{- toYaml .resources | nindent 4 }}
  {{- end }}
  # PSA baseline/restricted defaults: drop ALL caps, no priv-escalation, runtime-default seccomp.
  # netAdmin=true keeps NET_ADMIN explicitly added back (still baseline-compliant; restricted
  # disallows non-default caps so callers with netAdmin can't reach restricted).
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
      {{- if .Values.gateway.netAdmin }}
      add:
        - NET_ADMIN
      {{- end }}
    seccompProfile:
      type: RuntimeDefault
  volumeMounts:
    {{- include "cdn-gateway.volumeMounts" . | nindent 4 }}
    {{- if .extraVolumeMounts }}
    {{- toYaml .extraVolumeMounts | nindent 4 }}
    {{- end }}
{{- if .securityContext }}
securityContext:
  {{- toYaml .securityContext | nindent 2 }}
{{- end }}
volumes:
  {{- include "cdn-gateway.volumes" . | nindent 2 }}
  {{- if .extraVolumes }}
  {{- toYaml .extraVolumes | nindent 2 }}
  {{- end }}
{{- end }}

{{/*
In-cluster host:port for moq-relay's internal QUIC backend.
Caller must gate `.Values.moqRelay.internalQuicPort`; non-numeric typos
render verbatim and fail at the consumer rather than being coerced to 0.
*/}}
{{- define "cdn-gateway.moqRelayInternalAddr" -}}
{{- printf "%s-moq-relay.%s.svc.cluster.local:%s" .Release.Name .Release.Namespace (toString .Values.moqRelay.internalQuicPort) -}}
{{- end }}

{{/*
SSM multicast GROUP the moq-pub-mmtp bridge joins to receive shreds.

`shreds.ssmGroup` is the group the in-cluster shred-forwarder EMITS to, and the
bridge historically reused it for its own JOIN — so the chart could not express
"the bridge receives a channel this cluster does not produce". `shreds.bridge`
already scopes the source half of the (S,G) (`shreds.bridge.ssmSource`); this
scopes the group half the same way, so the pair can point at an off-cluster
producer while the forwarder keeps emitting its own group.

Unset (the default) resolves to `shreds.ssmGroup`, so every environment that
does not set the override renders the same manifest as before this helper
existed (verified across all six values files; the only rendered-text deltas are
these comments and the chart-version label).

Both the bridge args and the published catalog resolve the join through THIS
helper — advertising a (S,G) the bridge does not actually join is the drift that
made the catalog misinform downstream consumers.
*/}}
{{- define "cdn-gateway.shredBridgeJoinGroup" -}}
{{- .Values.shreds.bridge.ssmGroup | default .Values.shreds.ssmGroup -}}
{{- end }}

{{/*
Validate the mroute IGMP-forcing inputs before they are interpolated into the
privileged `configure-igmp-max-msf` init container's shell.

Both values reach that container as bare shell text — an sysctl node path, a
`sysctl -w` argument, and a readback comparison — in a container that runs
`privileged: true, runAsUser: 0`. So an unvalidated `inputIface` is command
injection into a root shell (`net1;cmd` renders
`FIV=/proc/sys/net/ipv4/conf/net1;cmd/force_igmp_version`, and `cmd` runs), and
the far likelier real-world case — a typo or a trailing space — silently
produces a broken privileged script instead of a render-time error. Reject both
at render, where the operator sees it.

Bounds:
  - iface: kernel IFNAMSIZ is 16 including NUL, so 15 chars max, and an ifname
    cannot contain '/' or whitespace. Leading alnum keeps '-'-prefixed names
    from being read as flags by the tools that consume it.
  - version: force_igmp_version is 0..3 (0=adaptive, 1/2/3=pinned IGMPvN).
    Anything else is refused by the kernel at write time, so failing here
    converts a fail-closed pod crash into a clear chart error.

Callers pass the values path prefix so the message names the key they set.
*/}}
{{- define "cdn-gateway.validateMrouteIgmp" -}}
{{- $iface := .iface | toString -}}
{{- if not (regexMatch "^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$" $iface) -}}
{{- /* upgrade-safe: the pod is already broken -- this name reaches `ip link` in a privileged init container and the kernel refuses it. On upgrade this is where an operator typo is caught. */}}
{{- fail (printf "%s.mroute.inputIface must be a valid network interface name (max 15 chars, alphanumeric start, then alphanumerics . _ -), got %q. It is interpolated into a privileged init container's shell." .prefix $iface) -}}
{{- end -}}
{{- $version := .version | toString -}}
{{- if not (regexMatch "^[0-3]$" $version) -}}
{{- /* upgrade-safe: the kernel refuses any other value at write time, so the pod is already fail-closed; keep catching a new typo on upgrade. */}}
{{- fail (printf "%s.mroute.forceIgmpVersion must be 0, 1, 2 or 3 (0=kernel-adaptive, 3=pin IGMPv3 for SSM), got %q. The kernel refuses any other value." .prefix $version) -}}
{{- end -}}
{{- end }}

{{/*
The IPv6/MLD sibling of validateMrouteIgmp, for `mroute.inputIface6` and
`mroute.forceMldVersion`. Same injection surface, same reasoning — both land as
bare shell text in the `privileged: true, runAsUser: 0` init container.

Deliberately a separate helper rather than a parameterized one, because the two
families do NOT share a version range:
  - force_igmp_version is 0..3 (0=adaptive, 1/2/3=pinned IGMPvN).
  - force_mld_version is 0..2 ONLY. MLD has just two versions — MLDv1 (RFC 2710)
    and MLDv2 (RFC 3810) — so the kernel refuses 3. Reusing the IGMP validator
    would accept `forceMldVersion: 3` at render and hand the pod a write the
    kernel rejects, converting a clear chart error into a fail-closed crashloop.
*/}}
{{- define "cdn-gateway.validateMrouteMld" -}}
{{- $iface := .iface | toString -}}
{{- if not (regexMatch "^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$" $iface) -}}
{{- /* upgrade-safe: same as the IPv4 sibling: the kernel already refuses this ifname, so no healthy release holds it. */}}
{{- fail (printf "%s.mroute.inputIface6 must be a valid network interface name (max 15 chars, alphanumeric start, then alphanumerics . _ -), got %q. It is interpolated into a privileged init container's shell." .prefix $iface) -}}
{{- end -}}
{{- $version := .version | toString -}}
{{- if not (regexMatch "^[0-2]$" $version) -}}
{{- /* upgrade-safe: MLD has two versions; the kernel already refuses anything above 2, so no healthy release holds it. */}}
{{- fail (printf "%s.mroute.forceMldVersion must be 0, 1 or 2 (0=kernel-adaptive, 2=pin MLDv2 for SSM), got %q. MLD has only two versions, so the kernel refuses anything above 2." .prefix $version) -}}
{{- end -}}
{{- end }}

{{/*
Validate `mroute.inputVif`, the dummy netdev amt-astats registers as the mroute
input VIF in place of `mroute.inputIface` (see values.yaml). Renders nothing;
empty is valid and means "not requested". Same injection surface and the same
name bounds as validateMrouteIgmp: the name lands as shell text in a
`privileged: true` init container.

  - amt* names the relay's own amt netdevs (amtr, amtr6, and the amt-test /
    amt-health probes), which amt-relay.sh deletes and recreates after the
    relay container installed the redirect into the dummy; mirred then drops
    everything it redirects. dimt-* is reserved for DIMT tunnels.
  - ifaces: every other netdev name the caller renders for this relay. The
    dummy must be a netdev of its own.
  - podNetnsLinux: the dummy and its tc redirect live in the pod netns, so a
    hostNetwork pod would create them on the node, and a juniper relay has no
    kernel mroute to register them with.
  - on, imageTag: with the feature on (inputVif set and mroute enabled), the
    effective relay image tag must be immutable (sha-..., or one carrying
    @sha256:, the same test the tag-precedence rule uses). The redirect lives in
    the pod netns, so it outlives a relay container that is SIGKILLed before
    its teardown (an OOM kill, or a stop that overruns the grace period). A
    mutable tag under pullPolicy Always lets the restarted container be an
    older amtr image: one that never removes the redirect, registers the input
    iface itself, and so forwards no IPv4 multicast at all.

Usage:
  {{- include "cdn-gateway.validateMrouteInputVif" (dict "prefix" "amtRelay"
        "vif" $vif "podNetnsLinux" $podNetnsLinuxRelay "ifaces" (list ...)
        "on" $mrouteInputVifOn "imageTag" $amtRelayImageTag) -}}
*/}}
{{- define "cdn-gateway.validateMrouteInputVif" -}}
{{- $vif := .vif | toString -}}
{{- if $vif -}}
{{- if not (regexMatch "^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$" $vif) -}}
{{- /* upgrade-safe: mroute.inputVif is new in this commit, so no pre-existing release sets it. */}}
{{- fail (printf "%s.mroute.inputVif must be a valid network interface name (max 15 chars, alphanumeric start, then alphanumerics . _ -), got %q. It is interpolated into a privileged init container's shell." .prefix $vif) -}}
{{- end -}}
{{- if or (hasPrefix "amt" $vif) (hasPrefix "dimt-" $vif) -}}
{{- /* upgrade-safe: mroute.inputVif is new in this commit, so no pre-existing release sets it. */}}
{{- fail (printf "%s.mroute.inputVif=%q must not start with \"amt\" (the relay's amt netdevs: amtr, amtr6 and the amt-test / amt-health probes, which amt-relay.sh deletes and recreates) or \"dimt-\" (DIMT tunnels). Use e.g. mrvif0." .prefix $vif) -}}
{{- end -}}
{{- $ifaces := .ifaces | compact | uniq -}}
{{- if has $vif $ifaces -}}
{{- /* upgrade-safe: mroute.inputVif is new in this commit, so no pre-existing release sets it. */}}
{{- fail (printf "%s.mroute.inputVif=%q names an interface this relay already uses (%s); it must name a dummy of its own, e.g. mrvif0." .prefix $vif (join ", " $ifaces)) -}}
{{- end -}}
{{- if not .podNetnsLinux -}}
{{- /* upgrade-safe: mroute.inputVif is new in this commit, so no pre-existing release sets it. */}}
{{- fail (printf "%s.mroute.inputVif=%q is set on a hostNetwork or juniper relay; it applies only to a pod-networked linux relay (a hostNetwork pod would create the dummy and its redirect on the node, and a juniper relay has no kernel mroute). Clear it." .prefix $vif) -}}
{{- end -}}
{{- $tag := .imageTag | toString -}}
{{- if and .on (not (or (hasPrefix "sha-" $tag) (contains "@sha256:" $tag))) -}}
{{- /* upgrade-safe: mroute.inputVif is new in this commit, so no pre-existing release sets it. */}}
{{- fail (printf "%s.mroute.inputVif=%q needs an immutable relay image: %s.image.tag must be \"sha-...\" or carry \"@sha256:\", and the tag in effect is %q. The input-VIF redirect lives in the pod netns and outlives a relay container SIGKILLed before its teardown; a mutable tag lets the restarted container be an older amtr image that never removes it and so forwards no IPv4 multicast." .prefix $vif .prefix $tag) -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Validate an optional image digest pin. Renders nothing; fails the render when set
to anything other than a full sha256 digest, so a typo is caught at `helm template`
rather than surfacing as an ImagePullBackOff.

Caller passes its own values path so the message names the key the operator set, plus its
component tag and (optionally) the chart-global tag, so the two pinning conventions cannot
be combined by accident:
  {{- include "cdn-gateway.validateDigest" (dict
        "digest" .Values.x.image.digest "path" "x.image.digest"
        "tag" .Values.x.image.tag "tagPath" "x.image.tag"
        "globalTag" .Values.global.imageTag) }}

Pass `globalTag` RAW -- do not pre-resolve `global.imageTag | default x.image.tag` at the
call site. The helper applies that precedence itself so it also knows WHICH key won, and
can attribute the failure to the key the operator actually set. Resolving at the call site
loses that: `global.imageTag` wins the value but the message still blames `x.image.tag`,
sending the operator to edit a key they never touched. Keeping the rule in one place is
also the point of this helper -- a per-call-site copy of the precedence expression is the
same drift the extraction removed.

Call it INSIDE the same guard as the workload it belongs to — validating a disabled
component's values would fail renders that never use them.

Why `tag` matters: onprem-k8s/production-values.yaml pins this chart's shred path by
embedding the digest IN the tag string (tag: "pinned-21006781@sha256:653eef77..."), which
renders a valid pinned reference on its own. Setting `digest` as well appends a SECOND
@sha256: -- repo:tag@sha256:A@sha256:B -- which no per-value check can catch, because both
values are individually well-formed. The check is for any `@`, not `@sha256:` specifically:
`@` is not legal in a Docker tag, so its presence already means the tag is a tag@digest
composite -- which also catches a non-sha256 algorithm. `tag`/`tagPath`/`globalTag` are
optional; omit them all and only the digest shape is checked.
*/}}
{{- define "cdn-gateway.validateDigest" -}}
{{- $path := .path -}}
{{- with .digest -}}
{{- if not (regexMatch "^sha256:[a-f0-9]{64}$" .) -}}
{{- /* upgrade-safe: a malformed digest is an unpullable image ref -- the release is already broken, and an upgrade is where a new bad pin is caught. */}}
{{- fail (printf "%s must be a sha256 digest with 64 hexadecimal characters, got %q" $path .) -}}
{{- end -}}
{{- end -}}
{{/* Same precedence as every image ref in this chart unless the caller marks
   a digest-bearing component pin as authoritative. */}}
{{- $globalTag := printf "%v" (.globalTag | default "") -}}
{{- $componentTag := printf "%v" (.tag | default "") -}}
{{- $tag := $globalTag | default $componentTag -}}
{{- $tagPath := ternary "global.imageTag" (.tagPath | default "the image tag") (ne $globalTag "") -}}
{{- if and (.digestTagWins | default false) (ne $componentTag "") -}}
{{- $tag = $componentTag -}}
{{- $tagPath = .tagPath | default "the image tag" -}}
{{- end }}
{{- if and .digest (ne $tag "") -}}
{{- if contains "@" $tag -}}
{{- /* upgrade-safe: a double-digest ref is unpullable, so no healthy release holds it; catching the second pin on upgrade is the point. */}}
{{- fail (printf "%s already carries a digest (%q), so setting %s renders a double-digest reference; pin in exactly one place" $tagPath $tag $path) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
cdn-gateway.relayCachePath -- the node directory backing the relay's LUKS cache:
the operator override or a namespace-scoped default so co-tenant relays on one
node never share a directory. The relay Deployment (sidecar mode) and the DRA
driver DaemonSet (backing-file store) MUST resolve this identically, so both
call here rather than repeating the expression.
*/}}
{{- define "cdn-gateway.relayCachePath" -}}
{{- (.Values.relay.luks).hostPath | default (printf "/var/lib/blockcast/%s/relaycache" .Release.Namespace) -}}
{{- end -}}

{{/*
cdn-gateway.mconfigVolumeSource -- where blockcastd writes gateway.mconfig, as
the body of a pod volume (the caller emits `- name: mconfig` and nindents by 8).
The relay Deployment and the DRA driver DaemonSet MUST read the same file: a
DaemonSet naming a PVC the chart does not create sits in FailedMount forever.
In PVC mode the file lives under the `configs` subPath; mounts must add
`subPath: configs` when cdn-gateway.mconfigUsesSubPath renders "true".
*/}}
{{- define "cdn-gateway.mconfigVolumeSource" -}}
{{- if .Values.gateway.configsPath -}}
hostPath:
  path: {{ .Values.gateway.configsPath }}
  type: DirectoryOrCreate
{{- else if .Values.gateway.blockcastdDataPath -}}
hostPath:
  path: {{ .Values.gateway.blockcastdDataPath }}/configs
  type: DirectoryOrCreate
{{- else -}}
persistentVolumeClaim:
  claimName: {{ include "cdn-gateway.fullname" . }}-blockcastd-data
  readOnly: true
{{- end -}}
{{- end -}}

{{- define "cdn-gateway.mconfigUsesSubPath" -}}
{{- if and (not .Values.gateway.configsPath) (not .Values.gateway.blockcastdDataPath) -}}true{{- end -}}
{{- end -}}

{{/*
Relay peering list (BLO-50036): magmad writes mconfig
CDNGatewayConfigs.peering_ceilings to relay_peering.json next to
gateway.mconfig; relay-caddy and amt-astats read it via
RELAY_STATS_PEERING_FILE. Rendered only when relayStatsPeering.enabled.
cdn-gateway.relayPeeringEnv / Mount / Volume each emit a list item at column 0;
callers nindent them.
*/}}
{{- define "cdn-gateway.relayPeeringEnv" -}}
{{- if (.Values.relayStatsPeering).enabled -}}
- name: RELAY_STATS_PEERING_FILE
  value: "/var/opt/magma/configs/relay_peering.json"
{{- end -}}
{{- end -}}

{{- define "cdn-gateway.relayPeeringMount" -}}
{{- if (.Values.relayStatsPeering).enabled -}}
- name: mconfig
  mountPath: /var/opt/magma/configs
  {{- if eq (include "cdn-gateway.mconfigUsesSubPath" .) "true" }}
  subPath: configs
  {{- end }}
  readOnly: true
{{- end -}}
{{- end -}}

{{- define "cdn-gateway.relayPeeringVolume" -}}
{{- if (.Values.relayStatsPeering).enabled -}}
- name: mconfig
  {{- include "cdn-gateway.mconfigVolumeSource" . | nindent 2 }}
{{- end -}}
{{- end -}}

{{/*
cdn-gateway.draDriverName -- the DRA driver identity for THIS release:
<release>.<namespace>.luks.blockcast.io. Kubelet plugin registration is
node-scoped (/var/lib/kubelet/plugins/<name>/dra.sock), so two gateway releases
on one node need distinct names or one of their drivers never registers; the
DeviceClass selects device.driver == this and the claim's CEL indexes
device.attributes["<this>"], so the DaemonSet env, DeviceClass and claim all
render from this one helper. The driver validates the value at startup
(trafficcontrol cmd/dra-luks-plugin/main.go validateDriverName): a DNS-1123
subdomain of at most 63 bytes, the API server's ResourceSlice.spec.driver rule.
*/}}
{{- define "cdn-gateway.draDriverName" -}}
{{- $name := printf "%s.%s.luks.blockcast.io" .Release.Name .Release.Namespace -}}
{{- if gt (len $name) 63 -}}
{{- /* upgrade-safe: derived from release name + namespace, not from operator values -- it cannot change under a release, and an over-long name never registered with kubelet. */}}
{{- fail (printf "DRA driver name %q is %d bytes; ResourceSlice.spec.driver allows at most 63. Shorten the release name or namespace (relay.luks.dra)." $name (len $name)) -}}
{{- end -}}
{{- $name -}}
{{- end -}}

{{/*
Render a label map as YAML, dropping any key whose value is nil or empty.

BLO-34399. An overlay that "removes" an inherited extraSelectorLabels key by
setting it to null leaves the KEY behind: helm only strips nulls for keys the
chart itself declares, and the chart declares `extraSelectorLabels: {}` with no
sub-keys. `toYaml` then emits `key: null`, which Kubernetes decodes into an
empty-string label. In spec.selector — which is IMMUTABLE — that silently turns
a 2-key selector into a 4-key one, and every subsequent `helm upgrade` fails
with `field is immutable`, forever.

Emits nothing at all when every value is empty, so call sites can guard with
`with` and keep the surrounding block from rendering a bare `{}`.

Values are stringified (`printf "%v"`), so `key: true` renders as `key: "true"`
and `key: 123` as `key: "123"`. That is deliberate: label maps are
map[string]string and Kubernetes rejects a bare YAML bool or int there. Note
the emptiness test is `ne $s ""`, not truthiness -- `0` and `false` are
legitimate label values and are kept.
*/}}
{{- define "cdn-gateway.cleanLabels" -}}
{{- $out := dict -}}
{{- range $k, $v := . -}}
{{- if not (kindIs "invalid" $v) -}}
{{- $s := printf "%v" $v -}}
{{- if ne $s "" -}}
{{- $_ := set $out $k $s -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if $out -}}
{{- toYaml $out -}}
{{- end -}}
{{- end }}

{{/*
cdn-gateway.failOnInstall -- a hard `fail` scoped to `helm install`.

Use this for any guard that can fire on values an ALREADY-INSTALLED release
holds. magmad's in-pod helm loop upgrades each tenant with that release's
*stored* values (BLO-34691), so such a guard has no delivery path for its own
remedy: the upgrade that would carry the satisfying key is the upgrade the
guard rejects, and the namespace's chart loop then freezes on every attempt,
forever, with no backoff. Measured four times on three distinct guards --
BLO-30575 and BLO-34827 (amtRelay.mirrorVlan), BLO-35573
(relay.gatewayAPI.httpsCertificateRefs), BLO-39758 (multicast.ha). Generalised
in BLO-39762; the shape is #2090's, which fixed the third of those.

An install is different: it gets whatever values it is invoked with, so the
remedy IS deliverable there and failing closed is right. Scope the fail to
install and let the upgrade path render the pre-guard behaviour -- which is
what the frozen release is already running. Freezing does not repair that
shape; it only also blocks every unrelated fix queued behind it.

Do NOT use this for a guard that can only fire on a value an operator
affirmatively set to something already broken at runtime: a >15-char netdev
name, a double-digest image ref, an out-of-range IGMP version, a stateDir the
collector refuses. Those must keep failing on upgrade -- an upgrade is exactly
where they catch a new typo on its way in, and no previously-healthy release
can be holding the shape they reject. Same test for a guard that shipped in
the same commit as the feature it guards: no pre-existing release can have
that feature enabled, so it cannot fire on stored values.

Usage: {{- include "cdn-gateway.failOnInstall" (dict "r" $ "msg" "...") }}

tests/test-upgrade-safe-guards.sh enforces the choice: every `fail` AND every
`required` in templates/ must either route through here or carry a single-line
`upgrade-safe:` marker comment directly above it, saying why freezing an
existing release is the correct outcome. `required` is covered because it
aborts the render identically and so carries the identical hazard -- do not
read "every fail" as leaving the other spelling a way around the contract. It
has no install-scoped form, so a `required` that CAN fire on stored values must
be restructured into an explicit `if` + this helper rather than labeled.
*/}}
{{- define "cdn-gateway.failOnInstall" -}}
{{- if .r.Release.IsInstall }}{{- fail .msg }}{{- end -}}
{{- end -}}

{{/*
cdn-gateway.toCredentialEnvNames -- the env var names that carry a Traffic Ops
username/password on some gateway component, lowercased, space separated.

One source of truth for the BLO-47254 contract, shared by the free-form `env`
passthrough guards below. TO_USER/TO_PASSWORD are the relay (ats + caddy
frontend) spelling; tm_/tr_traffic_ops_username/password are the Traffic
Monitor and Traffic Router spellings rendered by their own templates.
*/}}
{{- define "cdn-gateway.toCredentialEnvNames" -}}
to_user to_password tm_traffic_ops_username tm_traffic_ops_password tr_traffic_ops_username tr_traffic_ops_password
{{- end -}}

{{/*
cdn-gateway.isToCredentialEnvName -- "true" when the given name is one of the
Traffic Ops credential env names, compared case-insensitively. Empty (falsey)
otherwise, so it reads naturally as `{{- if include ... }}`.

Usage: {{- if include "cdn-gateway.isToCredentialEnvName" .name }}
*/}}
{{- define "cdn-gateway.isToCredentialEnvName" -}}
{{- if has (lower (. | toString)) (splitList " " (include "cdn-gateway.toCredentialEnvNames" .)) }}true{{- end -}}
{{- end -}}

{{/*
cdn-gateway.toCredentialEnvMsg -- the single wording of the BLO-47254 free-form
`env` passthrough refusal, given the values path and the offending variable name.
The three call sites (toSafeEnv below, and the two `range` passthroughs in the
Traffic Monitor / Traffic Router templates) must state the identical contract, so
they share one definition rather than three copies that drift apart.

Usage:
  {{ include "cdn-gateway.toCredentialEnvMsg" (dict "path" "trafficMonitor.env" "name" .name) }}
*/}}
{{- define "cdn-gateway.toCredentialEnvMsg" -}}
{{- printf "%s carries %s: gateway components authenticate to Traffic Ops with the gateway client certificate only, and that holds for the free-form env passthrough exactly as it does for toUser/toPassword (BLO-47254). Remove the entry; on upgrade it is dropped from the manifest automatically." .path .name -}}
{{- end -}}

{{/*
cdn-gateway.toSafeEnv -- render a free-form `env` passthrough list with any
Traffic Ops credential entry REMOVED, and fail the render on install if one is
present.

BLO-47254 made gateway TO auth cert-only and added guards on the six NAMED
values (relay.ats / trafficMonitor / trafficRouter .toUser/.toPassword). Those
guards do not see the free-form `env` passthroughs that sit beside them, so the
identical credential could still be delivered through, e.g.,
relay.caddyFrontend.env or trafficMonitor.env -- the render succeeded and the
credential reached the pod. For the `toYaml` passthroughs that is a full bypass
including valueFrom.secretKeyRef, which is exactly the shape found live on
staging-blockcastd-receiver-2 (PEN-4274).

Two behaviours, deliberately different by lifecycle, mirroring the named keys:

  install  -- fail closed via cdn-gateway.failOnInstall. A fresh install gets
              whatever values it is invoked with, so the remedy is deliverable
              and refusing is right.
  upgrade  -- admit the release but DROP the entry. This half is load-bearing
              and is why this helper filters rather than only asserting: the
              passthrough is a verbatim toYaml dump, so unlike the named keys
              (whose template lines #2489 deleted) an upgrade would otherwise
              keep re-rendering the credential forever. Dropping it here is
              what makes "letting the upgrade through IS the removal" true for
              this path too. magmad upgrades each tenant with that release's
              STORED values (BLO-34691), so freezing instead would reject the
              very upgrade that strips the credential.

Usage:
  {{- with include "cdn-gateway.toSafeEnv" (dict "r" $ "env" .Values.relay.caddyFrontend.env "path" "relay.caddyFrontend.env") }}
  {{- . | nindent 8 }}
  {{- end }}
*/}}
{{- define "cdn-gateway.toSafeEnv" -}}
{{- $r := .r -}}
{{- $path := .path -}}
{{- $kept := list -}}
{{- range .env -}}
{{- if include "cdn-gateway.isToCredentialEnvName" .name -}}
{{- include "cdn-gateway.failOnInstall" (dict "r" $r "msg" (include "cdn-gateway.toCredentialEnvMsg" (dict "path" $path "name" .name))) -}}
{{- else -}}
{{- $kept = append $kept . -}}
{{- end -}}
{{- end -}}
{{- if $kept -}}
{{- toYaml $kept -}}
{{- end -}}
{{- end -}}

{{/*
cdn-gateway.envEntry -- render ONE entry of a free-form `env` passthrough list
as a container env var, preserving `valueFrom` instead of discarding it.

Eleven `range` passthroughs across nine values paths reconstructed the entry
from `.name`/`.value` alone. An entry supplying `valueFrom` has no `.value`, so
those rendered `value: ""`: the Secret reference was discarded, the render
SUCCEEDED and nothing warned, and the container got an empty string where the
operator meant a Secret value (PEN-4300). The hazard is a consumer that reads
an empty credential as "auth disabled" rather than erroring. cast.env was the
single site that already handled it; this is its shape, factored out so the
chart carries one definition rather than twelve copies that drift apart.

`value` entries render EXACTLY as before, `| quote` included. That coercion is
load-bearing, and is why this is a per-entry helper rather than a `toYaml` dump
of the whole list: Kubernetes requires env values to be strings, so a bare
`toYaml` would emit `value: 8080` for a numeric entry and be rejected at
admission -- converting a silent drop into a silent breakage of every entry
beside it. cdn-gateway.toSafeEnv (the four relay paths) dumps verbatim by
design and is deliberately left alone: its contract is to pass through whatever
shape it was given, minus the Traffic Ops credentials.

An entry carrying BOTH `value` and `valueFrom` renders both keys, and
Kubernetes rejects that pair at admission. That is the intended outcome: it is
operator error, and the contract here is that nothing is dropped silently --
picking a winner would reintroduce exactly the defect above, one key over.

This helper does NOT filter Traffic Ops credentials. The BLO-47254 guard is a
separate concern and stays where it is, in front of the call sites that need it
(trafficMonitor.env, trafficRouter.env); the other paths are not Traffic Ops
clients and are deliberately unguarded, per PEN-4276's scope note.

Usage:
  {{- range .Values.moqRelay.env }}
  {{- include "cdn-gateway.envEntry" . | nindent 8 }}
  {{- end }}
*/}}
{{- define "cdn-gateway.envEntry" -}}
- name: {{ .name }}
{{- if .valueFrom }}
  valueFrom:
    {{- toYaml .valueFrom | nindent 4 }}
{{- end }}
{{- if or (not .valueFrom) (hasKey . "value") }}
  value: {{ .value | quote }}
{{- end }}
{{- end -}}

{{/*
device-export egress CiliumNetworkPolicy gate (BLO-48356).
"render"  - enabled and the cluster serves cilium.io/v2/CiliumNetworkPolicy
"skipped" - enabled but the API is absent (any non-Cilium cluster: kind, k3s,
            minikube's default CNI, ...). Rendering it there makes helm reject
            the whole release, so it is skipped and NOTES.txt warns instead.
""        - disabled
Never `fail` on a missing API: blockcastd's upgrade guard renders offline with
--kube-version only, where every cluster looks Cilium-less (prod included).
*/}}
{{- define "cdn-gateway.deviceExportEgressPolicy" -}}
{{- $deviceExport := .Values.deviceExport | default dict -}}
{{- if (default (dict) $deviceExport.egressPolicy).enabled -}}
{{- if .Capabilities.APIVersions.Has "cilium.io/v2/CiliumNetworkPolicy" -}}render{{- else -}}skipped{{- end -}}
{{- end -}}
{{- end }}

{{/*
cdn-gateway.checkAmtMaxTunnels -- fail the render when an AMT relay's admission
cap (AMT_MAX_TUNNELS) exceeds its eBPF accounting-map capacity (MAX_GATEWAYS,
linux-amt cmd/amt-astats/bpf/amt_tracker.c) while eBPF billing is the
authoritative accounting source: tunnels admitted above MAX_GATEWAYS are
served but never billed. When eBPF billing is not authoritative the two
capacities are unrelated and the check is skipped.

The caller passes the values the relay's env vars render from:
  relayLabel         label for the error message, e.g. "amtRelayLinux"
  maxTunnels         AMT_MAX_TUNNELS
  maxGateways        eBPF accounting-map capacity
  enableEbpfBilling  ENABLE_EBPF_BILLING ("true"/"false")
  primarySource      AMT_ASTATS_PRIMARY_SOURCE

See BLO-23847 (the violation) and BLO-24459 (this guard).
*/}}
{{- define "cdn-gateway.checkAmtMaxTunnels" -}}
{{- if and (eq (toString .enableEbpfBilling) "true") (eq (toString .primarySource) "ebpf") }}
{{- $maxTunnels := int .maxTunnels }}
{{- $maxGateways := int .maxGateways }}
{{- if gt $maxTunnels $maxGateways }}
{{- /* upgrade-safe: no release stores amtRelay(Linux).maxTunnels (BLO-24459) and maxGateways is new with this guard, so it fires only on a new violating override, which is what it exists to refuse. */}}
{{- fail (printf "%s.maxTunnels (%d) exceeds %s.maxGateways (%d) while eBPF billing is authoritative (enableEbpfBilling=true, amtAstats.primarySource=ebpf): admission capacity must not exceed accounting capacity, or tunnels between the two counts are served but never billed. Lower %s.maxTunnels to <= %d, or raise %s.maxGateways only after confirming the eBPF map is resized to match (see BLO-23847)." .relayLabel $maxTunnels .relayLabel $maxGateways .relayLabel $maxGateways .relayLabel) }}
{{- end }}
{{- end }}
{{- end }}

{{/*
BLO-51574: does the Linux relay own the gateway's `amt-relay` lifecycle identity?
eventd types pod events by `service.type`, and orc8r maps `amt-relay` to the
gateway's single AMT_RELAY TO server, so exactly one workload may report it.
Only with a juniper collector AND a running Linux relay does the identity move
to the Linux StatefulSet; otherwise the amt-relay Deployment keeps it. Both
templates key on this one predicate so they cannot disagree.
*/}}
{{- define "cdn-gateway.amtRelayLinuxOwnsLifecycle" -}}
{{- if and (eq (.Values.amtRelay.relayType | default "linux") "juniper") .Values.amtRelayLinux.enabled (gt (int (.Values.amtRelayLinux.replicas | default 0)) 0) -}}
true
{{- end -}}
{{- end -}}
