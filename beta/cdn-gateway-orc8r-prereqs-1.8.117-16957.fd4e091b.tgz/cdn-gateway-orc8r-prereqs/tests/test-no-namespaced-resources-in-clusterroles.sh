#!/usr/bin/env bash
set -euo pipefail

# BLO-34775 regression guard.
#
# Every ClusterRole this chart renders is bound by a ClusterRoleBinding to the
# per-namespace <release>-gateway ServiceAccount, so ANY resource listed in one
# is granted across EVERY namespace in the cluster. Before this guard existed
# the relay ClusterRole carried `secrets: get,list,watch` with no
# resourceNames, which meant each per-namespace gateway SA could read every
# Secret in the cluster -- reachable in staging by one `kubectl exec` into an
# already-running pod, since the projected token is mounted at the default
# path.
#
# Namespaced permissions belong in a Role. The main cdn-gateway-orc8r chart
# already ships Role/<release>-gateway, bound to this same SA in this same
# namespace, covering secrets/configmaps/services/endpoints/leases and the
# Gateway API kinds at full CRUD.
#
# This asserts on the RENDERED manifests, not the template source: a source
# grep can pass while a conditional or indentation change puts the rule back
# into what Helm actually applies.

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Resources that may appear in a ClusterRole here, split by WHY they may. The
# split is not cosmetic: one combined list cannot distinguish "a Role could not
# grant this" from "a Role could, and we chose not to", so the success line
# below could not tell the truth and a namespaced entry could be slipped in
# under a heading that reads as though it were cluster-scoped.

# Genuinely cluster-scoped: a namespaced Role cannot grant these at all.
#
# ponytail: scope is asserted here, not read from the API -- nothing checks
# that these really are cluster-scoped. Verifying it needs `kubectl
# api-resources --namespaced=false`, i.e. live cluster access in this lint
# job. Worth paying for if a second exception ever shows up below.
cluster_scoped="
clusterroles
clusterrolebindings
ciliumegressgatewaypolicies
gatewayclasses
gatewayclasses/status
ingressclasses
"

# NAMESPACED, granted cluster-wide on purpose. Each entry widens every
# per-namespace gateway SA across the whole cluster, so adding one requires a
# stated reason in the template that renders it -- referencegrants is justified
# in dssync-rbac.yaml (cross-namespace ReferenceGrant reconciliation).
documented_exceptions="
referencegrants
"

rendered="$(helm template blockcastd-prereqs "$root" \
  --namespace staging-blockcastd-receiver \
  --set releaseName=blockcastd)"

# Pull the `resources:` entries that sit inside a document of the given kind,
# reading the rendered manifests on stdin. Handles both the flow style this
# chart uses (resources: ["a", "b"]) and block style.
#
# The kind test is exact equality on purpose. A substring match would conflate
# Role with RoleBinding, which is precisely how the events assertion below used
# to pass over a deleted Role.
resources_for_kind() {
  awk -v want="$1" '
    /^---$/                 { kind=""; inblock=0; next }
    /^kind:[[:space:]]/     { kind=$2; inblock=0 }
    kind != want            { next }
    /^[[:space:]]*resources:[[:space:]]*\[/ {
        line=$0
        gsub(/.*\[/, "", line); gsub(/\].*/, "", line)
        gsub(/[",]/, " ", line)
        n=split(line, a, " ")
        for (i=1; i<=n; i++) if (a[i] != "") print a[i]
        next
    }
    /^[[:space:]]*resources:[[:space:]]*$/ { inblock=1; next }
    inblock && /^[[:space:]]*-[[:space:]]/ {
        v=$2; gsub(/["'"'"']/, "", v); print v; next
    }
    { inblock=0 }
  ' | sort -u
}

clusterrole_resources="$(resources_for_kind ClusterRole <<<"$rendered")"

# Survivor check: an empty extraction would make every assertion below pass
# vacuously. This is the failure mode that hid the original bug, so fail loudly
# rather than reporting a clean run over nothing.
count="$(grep -c . <<<"$clusterrole_resources" || true)"
if [ "${count:-0}" -lt 3 ]; then
  echo "FAIL: extracted only ${count:-0} ClusterRole resources -- the parser or" >&2
  echo "      the chart changed shape. Refusing to pass on an empty read." >&2
  exit 1
fi

# Positive control: the guard must be able to SEE a cluster-scoped resource we
# know is rendered. If this disappears the extraction is looking at the wrong
# thing, even when the count above is non-zero.
grep -qx 'gatewayclasses' <<<"$clusterrole_resources" || {
  echo "FAIL: expected 'gatewayclasses' among ClusterRole resources; got:" >&2
  echo "$clusterrole_resources" >&2
  exit 1
}

rc=0
exceptions=""
while read -r res; do
  [ -n "$res" ] || continue
  grep -qxF "$res" <<<"$cluster_scoped" && continue
  if grep -qxF "$res" <<<"$documented_exceptions"; then
    exceptions="$exceptions $res"
    continue
  fi
  echo "FAIL: namespaced resource '$res' is granted by a ClusterRole in this" >&2
  echo "      chart, so every per-namespace gateway SA gets it cluster-wide." >&2
  echo "      Move it to a Role/RoleBinding (see relay-rbac.yaml)." >&2
  rc=1
done <<<"$clusterrole_resources"

[ "$rc" -eq 0 ] || exit 1

# The namespaced replacement must actually be rendered, so trimming the
# ClusterRole cannot silently drop event emission. Assert the GRANT rather than
# the kind: `grep -q 'kind: Role'` is an unanchored substring match that also
# matches `kind: RoleBinding`, so deleting the Role while leaving its binding --
# the exact silent drop this check exists to catch -- used to pass.
role_resources="$(resources_for_kind Role <<<"$rendered")"
grep -qx 'events' <<<"$role_resources" || {
  echo "FAIL: expected a namespaced Role granting 'events' for the relay." >&2
  echo "      Role resources rendered: ${role_resources:-<none>}" >&2
  exit 1
}

if [ -n "$exceptions" ]; then
  echo "ok: ${count} ClusterRole resources checked; cluster-scoped except" \
       "documented namespaced exception(s):${exceptions}"
else
  echo "ok: ${count} ClusterRole resources checked, all cluster-scoped"
fi
