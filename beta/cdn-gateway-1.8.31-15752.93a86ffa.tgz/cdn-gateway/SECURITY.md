# Pod Security Standards profile per pod

This chart targets [Kubernetes Pod Security Standards
`restricted`](https://kubernetes.io/docs/concepts/security/pod-security-standards/)
for the common cdn-gateway dynamic services. A subset of pods cannot reach
`restricted` because of legitimate operational needs (raw sockets, kernel
module install, dm-crypt management, etc) — those are listed below as
documented exceptions.

Related Linear ticket: BLO-2928.

## Quick reference

| Pod | PSA profile | Notes |
|---|---|---|
| `beacond` | restricted | Via helper. Non-root, fsGroup 999. |
| `blockcastd` | baseline | Runs as root (writes gateway-certs). NET_ADMIN optionally added. **Cannot be de-rooted** — it owns the cert write path that all consumers rely on. |
| `cast` (main) | restricted | Non-root, fsGroup 999. hostNetwork + NET_ADMIN/NET_RAW drop to baseline when enabled. |
| `cast` (init `cast-mcast-route`) | baseline | Short-lived init container needs root + NET_ADMIN to run `ip route replace`. busybox `ip` doesn't carry file capabilities. |
| `control-proxy` | restricted | De-rooted via fsGroup pattern. PR #983 unblocked this. |
| `dual-stack-relay` | restricted | Non-root, Secret-backed cert volume. |
| `ingress` (unified) | restricted | De-rooted via fsGroup pattern. |
| `moq-player` | restricted | NET_BIND_SERVICE added for ports 80/443 binding (allowed in restricted). |
| `moq-relay` | restricted | Non-root, fsGroup 999. |
| `pob` | restricted | Non-root, fsGroup 999. |
| `postgresql` | restricted | bitnami/postgres image, runs as uid 1001. |
| `traffic-monitor` | restricted | Non-root, fsGroup 999 (PR #983). Drops to baseline when `trafficMonitor.netAdmin=true`. |
| `traffic-router` | restricted | Non-root, fsGroup 999. Drops to baseline when `trafficRouter.netAdmin=true`. |

## Group A: restricted-compliant

These pods set the full restricted profile by default:

- pod-level: `runAsNonRoot: true`, `fsGroup: 999` (where they read `gateway-certs`), `seccompProfile.type: RuntimeDefault`
- container-level: `allowPrivilegeEscalation: false`, `capabilities.drop: [ALL]`, `seccompProfile.type: RuntimeDefault`

Pods: `beacond`, `cast` (main container), `control-proxy`, `dual-stack-relay`, `ingress` (unified), `moq-player`, `moq-relay`, `pob`, `postgresql`, `traffic-monitor`, `traffic-router`.

## Group B: baseline-compliant (NET_ADMIN exception)

Adding `NET_ADMIN` is incompatible with `restricted` (restricted disallows
non-default capabilities). When operators enable the `netAdmin: true` flag
on the corresponding values block, the pod drops from `restricted` to
`baseline`.

Affected pods (when flag enabled):

- `blockcastd` (when `gateway.netAdmin=true`)
- `traffic-monitor` (when `trafficMonitor.netAdmin=true`)
- `traffic-router` (when `trafficRouter.netAdmin=true`)
- `amt-relay` (when `amtRelay.netAdmin=true` — defaults to true)
- `cast` main (when `cast.hostNetwork=true` — defaults to true)

To run `restricted` profile for these, set the corresponding flag to
`false` in values and accept the reduced functionality (no IPv6 multicast,
no PIM SM/SSM forwarding via the gateway, etc).

## Group C: documented exceptions

These pods cannot reach `restricted` for legitimate reasons. Some are
`baseline` only; privileged/root paths require either a privileged-enforcing
namespace label, a per-namespace exception, or disabling the feature.

| Pod | Reason | Mitigation |
|---|---|---|
| `blockcastd` | Cert writer — needs root to write `0640 root:blockcast` to the shared PVC. | All cert consumers use `fsGroup: 999` to read instead of being root. blockcastd has no other privilege ask. |
| `amt-relay` (kmod init) | Root + `privileged: true` — `rmmod` + `insmod` of the OOT amt.ko kernel module. | Gated on `amtRelay.kmod.enabled` (default false). Read-only `/sys` mount. Exit-after-install. |
| `amt-relay` (main, when `useEbpf=true`) | CAP_BPF, CAP_PERFMON required for the eBPF TCX programs in amt_tracker.c (BLO-3293). | Gated on `amtRelay.useEbpf`. Other caps drop to baseline. |
| `ingress-cache` | `privileged: true` — needs `/dev` for ATS raw cache disk access. | Specific hostPath mounts only; no broader host filesystem. |
| `dra-luks-driver` | Root + dm-crypt management. | Already has `privileged: false` + `allowPrivilegeEscalation: false`. Per-host driver. |
| `multicast` (when `hostNetwork=true`) | Host network for multicast traffic. Requires NET_ADMIN. | Gated on `multicast.hostNetwork`. Configure `hostNetwork: false` to drop to baseline. |
| `multicast-egress-route-daemonset` | Host network + root + NET_ADMIN — manages multicast routes on the host. | Per-host daemon; hostNetwork is fundamental to its function. |
| `multicast-egress-bgp-anchor` | Raw sockets for BGP. | Per-host. |
| `yt-auth-bot` | Root (image). Cluster auth bot for harbor/etc. | Already sets `seccompProfile`. Image rebuild needed to de-root. |
| `cast` (init) | Root + NET_ADMIN for `ip route replace`. | Exits in ~1s after route set. busybox image; setcap on `ip` would require rebuild. |
| `relay` (LUKS init via DRA or cache-init sidecar) | Root + `privileged: true` for LUKS open/close on the cache device. | Gated on `relay.luks.enabled`. |
| `relay` (l4proxy sidecar) | Root/default-port binding with NET_BIND_SERVICE + NET_RAW for raw socket sendto() through Cilium. | Required for Gateway API UDPRoute/TCPRoute forwarding on DNS/QUIC/AMT ports. |

## Enforcement guidance

To opt a namespace into PSA enforcement for the Group A pods, set:

```yaml
metadata:
  labels:
    pod-security.kubernetes.io/enforce: restricted
    pod-security.kubernetes.io/enforce-version: latest
```

If the namespace also hosts Group B or C pods, use `enforce: baseline` or
`enforce: privileged` instead, and consider splitting the chart deployment
into separate namespaces by trust tier.
