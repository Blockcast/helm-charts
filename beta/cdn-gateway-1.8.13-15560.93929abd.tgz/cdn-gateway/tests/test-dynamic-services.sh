#!/usr/bin/env bash
# Helm template tests for BLO-4759: dynamic service Deployment replica defaults.
#
# Verifies that all registered_dynamic_services Deployments always render at
# replicas:0 by default, so GetState() never returns Active for a missing
# Deployment and blockcastd can bootstrap without a deadlock.
#
# Run from the chart root:
#   bash tests/test-dynamic-services.sh
#
# Requires: helm (any v3), awk
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

run_helm() {
  helm template "$RELEASE" "$CHART_DIR" "$@" 2>&1
}

assert_eq() {
  local label="$1" actual="$2" expected="$3"
  if [[ "$actual" -eq "$expected" ]]; then
    echo "  PASS: $label (got $actual)"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $label — expected $expected, got $actual"
    FAIL=$((FAIL + 1))
  fi
}

# Extract spec.replicas from a named Deployment in $OUTPUT.
# Returns -1 if the Deployment is not found (counts as failure when asserted == 0).
deployment_replicas() {
  local name="${RELEASE}-$1"
  echo "$OUTPUT" | awk \
    -v name="$name" \
    'BEGIN { in_dep=0; matched=0; result=-1 }
     /^---/            { in_dep=0; matched=0 }
     /^kind: Deployment/ { in_dep=1 }
     in_dep && /^  name: / {
       val=$0; sub(/^  name: /, "", val)
       if (val == name) matched=1
     }
     matched && /^  replicas: / {
       val=$0; sub(/^  replicas: /, "", val)
       result=val; matched=0; in_dep=0
     }
     END { print result }'
}

assert_replicas() {
  local svc="$1" expected="$2"
  local actual
  actual=$(deployment_replicas "$svc")
  if [[ "$actual" -eq "$expected" ]]; then
    echo "  PASS: $svc replicas=$actual"
    PASS=$((PASS + 1))
  else
    if [[ "$actual" -eq -1 ]]; then
      echo "  FAIL: $svc Deployment not found in output"
    else
      echo "  FAIL: $svc replicas — expected $expected, got $actual"
    fi
    FAIL=$((FAIL + 1))
  fi
}

# All 8 services in registered_dynamic_services (prod blockcastd.yml) plus pob.
DYNAMIC_SERVICES=(relay multicast traffic-monitor traffic-router moq-relay moq-player cast amt-relay pob)

echo "===== SCENARIO A: defaults — all dynamic services render at replicas:0 ====="
OUTPUT=$(run_helm)
for svc in "${DYNAMIC_SERVICES[@]}"; do
  assert_replicas "$svc" 0
done

echo ""
echo "===== SCENARIO B: explicit replicas override is respected ====="
OUTPUT=$(run_helm --set relay.replicas=1)
assert_replicas "relay" 1
# Others unaffected
for svc in multicast cast amt-relay moq-relay; do
  assert_replicas "$svc" 0
done

echo ""
echo "===== RESULTS: $PASS passed, $FAIL failed ====="
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
