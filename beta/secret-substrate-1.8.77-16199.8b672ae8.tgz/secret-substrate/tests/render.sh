#!/usr/bin/env bash
set -euo pipefail

chart_dir=$(cd "$(dirname "$0")/.." && pwd)
rendered=$(mktemp)
trap 'rm -f "$rendered"' EXIT

helm repo add hashicorp https://helm.releases.hashicorp.com --force-update
helm repo add external-secrets https://charts.external-secrets.io --force-update
helm dependency build "$chart_dir"
helm lint "$chart_dir"
helm template secret-substrate "$chart_dir" > "$rendered"

grep -q 'kind: ClusterSecretStore' "$rendered"
grep -q 'kind: ExternalSecret' "$rendered"
grep -q 'key: pop/networking/bgp-session' "$rendered"
grep -q 'storageClassName: rook-ceph-block' "$rendered"
grep -q 'tls_disable = 0' "$rendered"
grep -q 'server: "https://secret-substrate-vault-active.vault.svc:8200"' "$rendered"
grep -q 'secretName: vault-server-tls' "$rendered"
awk '/^kind: ServiceAccount$/{sa=1; next} sa && /^  name: external-secrets$/{found=1} /^---$/{sa=0} END{exit !found}' "$rendered"
if grep -Eiq 'root[_-]?token|unseal[_-]?(key|share).*:' "$rendered"; then
  printf 'rendered chart must not persist root or unseal material\n' >&2
  exit 1
fi
