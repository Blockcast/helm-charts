#!/bin/bash
#
# CDN Gateway Test Matrix
#
# This script tests all 4 combinations of Cloud and Gateway deployments:
#   Test 1: Docker Cloud + Docker Gateway
#   Test 2: Docker Cloud + K8s Gateway
#   Test 3: K8s Cloud + Docker Gateway
#   Test 4: K8s Cloud + K8s Gateway
#
# Prerequisites:
#   - Docker installed and running
#   - Minikube installed
#   - Helm 3 installed
#   - kubectl configured
#   - Test certs generated in .cache/test_certs/
#
# Usage:
#   ./test_matrix.sh [test_number]
#   ./test_matrix.sh           # Run all tests
#   ./test_matrix.sh 1         # Run only test 1
#   ./test_matrix.sh 3 4       # Run tests 3 and 4

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAGMA_ROOT="$(cd "$SCRIPT_DIR/../../../.." && pwd)"
HELM_CHART_DIR="$SCRIPT_DIR"
DOCKER_COMPOSE_DIR="$MAGMA_ROOT/cdn/gateway/docker"
ORC8R_DOCKER_DIR="$MAGMA_ROOT/orc8r/cloud/docker"
TEST_CERTS_DIR="$MAGMA_ROOT/.cache/test_certs"
GATEWAY_CERTS_DIR="$HOME/.blockcast/certs"
GATEWAY_SNOWFLAKE_DIR="$HOME/.blockcast/snowflake"

# Timeouts
STARTUP_TIMEOUT=180
CHECKIN_TIMEOUT=120

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test results
declare -A TEST_RESULTS

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

log_error() {
    echo -e "${RED}[FAIL]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_header() {
    echo ""
    echo "=============================================="
    echo -e "${BLUE}$1${NC}"
    echo "=============================================="
}

# Check prerequisites
check_prerequisites() {
    log_header "Checking Prerequisites"

    local missing=()

    if ! command -v docker &> /dev/null; then
        missing+=("docker")
    fi

    if ! command -v minikube &> /dev/null; then
        missing+=("minikube")
    fi

    if ! command -v helm &> /dev/null; then
        missing+=("helm")
    fi

    if ! command -v kubectl &> /dev/null; then
        missing+=("kubectl")
    fi

    if [ ! -d "$TEST_CERTS_DIR" ]; then
        missing+=("test_certs (run: cd $MAGMA_ROOT && make test_certs)")
    fi

    if [ ${#missing[@]} -gt 0 ]; then
        log_error "Missing prerequisites: ${missing[*]}"
        exit 1
    fi

    log_success "All prerequisites met"
}

# Create necessary directories
setup_directories() {
    log_info "Creating gateway certificate directories..."
    mkdir -p "$GATEWAY_CERTS_DIR" "$GATEWAY_SNOWFLAKE_DIR"
}

# Start minikube with required configuration
setup_minikube() {
    log_header "Setting up Minikube"

    if minikube status &>/dev/null; then
        log_info "Minikube is already running"
    else
        log_info "Starting minikube..."
        minikube start \
            --cpus=4 \
            --memory=8192 \
            --driver=docker \
            --container-runtime=docker
    fi

    # Pin every kubectl/helm call in this script to minikube. Without this,
    # commands run against the user's default context — which on machines that
    # also have a production kubeconfig means tests can leak resources into
    # production. Only the script's KUBECONFIG is touched (export, not config
    # use-context) so the user's environment is unaffected.
    if [ -z "${MINIKUBE_KUBECONFIG_SET:-}" ]; then
        local minikube_kubeconfig="${TMPDIR:-/tmp}/test_matrix_kubeconfig.$$"
        kubectl --context minikube config view --minify --raw > "$minikube_kubeconfig" \
            || { log_error "Failed to extract minikube kubeconfig — is the 'minikube' context present?"; exit 1; }
        export KUBECONFIG="$minikube_kubeconfig"
        export MINIKUBE_KUBECONFIG_SET=1
        trap 'rm -f "$minikube_kubeconfig"' EXIT
        log_info "Pinned KUBECONFIG to minikube-only ($minikube_kubeconfig)"
    fi

    # Increase inotify limits (needed for cert watchers)
    log_info "Setting inotify limits..."
    minikube ssh "sudo sysctl -w fs.inotify.max_user_instances=1024" &>/dev/null || true
    minikube ssh "sudo sysctl -w fs.inotify.max_user_watches=524288" &>/dev/null || true

    # Setup required mounts
    log_info "Setting up minikube mounts..."
    setup_minikube_mounts

    log_success "Minikube ready"
}

# Setup minikube mounts for host paths
setup_minikube_mounts() {
    local mounts=(
        "$TEST_CERTS_DIR:$TEST_CERTS_DIR"
        "$MAGMA_ROOT/orc8r/cloud/configs:$MAGMA_ROOT/orc8r/cloud/configs"
        "$MAGMA_ROOT/cdn/cloud/configs:$MAGMA_ROOT/cdn/cloud/configs"
        "$MAGMA_ROOT/bandwidth/cloud/configs:$MAGMA_ROOT/bandwidth/cloud/configs"
        "$MAGMA_ROOT/cdn/gateway/configs:$MAGMA_ROOT/cdn/gateway/configs"
        "$HOME/.blockcast:$HOME/.blockcast"
    )

    for mount in "${mounts[@]}"; do
        local src="${mount%%:*}"
        local dst="${mount##*:}"

        # Check if mount is already running
        if ! pgrep -f "minikube mount $src:" &>/dev/null; then
            log_info "Starting mount: $src -> $dst"
            mkdir -p "$src"
            nohup minikube mount "$src:$dst" > "/tmp/minikube-mount-$(basename $src).log" 2>&1 &
            sleep 1
        fi
    done
}

# Stop all minikube mounts
cleanup_minikube_mounts() {
    log_info "Stopping minikube mounts..."
    pkill -f "minikube mount" || true
}

# Start Docker Cloud (orc8r)
start_docker_cloud() {
    log_info "Starting Docker Cloud..."
    cd "$ORC8R_DOCKER_DIR"

    # Build if needed
    if ! docker images | grep -q "orc8r_controller.*latest"; then
        log_info "Building orc8r images..."
        python3 build.py
    fi

    # Start services
    docker compose up -d

    # Wait for services to be healthy
    log_info "Waiting for Docker Cloud to be ready..."
    local timeout=$STARTUP_TIMEOUT
    while [ $timeout -gt 0 ]; do
        if curl -sk https://localhost:7443/healthz &>/dev/null; then
            log_success "Docker Cloud is ready"
            return 0
        fi
        sleep 5
        timeout=$((timeout - 5))
    done

    log_error "Docker Cloud failed to start within timeout"
    return 1
}

# Register gateway with cloud
register_gateway() {
    local cloud_type=$1
    log_info "Registering test gateway..."

    local cert_args="--cert $TEST_CERTS_DIR/admin_operator.pem --key $TEST_CERTS_DIR/admin_operator.key.pem"
    local api_base

    if [ "$cloud_type" == "docker" ]; then
        api_base="https://localhost:9443/magma/v1"
    else
        api_base="https://localhost:9443/magma/v1"
    fi

    # Get gateway hardware ID from snowflake
    local hw_id
    if [ -f "$HOME/.blockcast/snowflake/snowflake" ]; then
        hw_id=$(cat "$HOME/.blockcast/snowflake/snowflake")
    else
        hw_id="9197a93b-b41d-4b1a-ba18-8c34ebfd3b60"
    fi

    # Create network if not exists
    curl -sk $cert_args -X POST "$api_base/cdn/networks" \
        -H "Content-Type: application/json" \
        -d '{"id":"test_cdn_network","name":"Test CDN Network","description":"Test network for CI"}' 2>/dev/null || true

    # Get challenge key (DER bytes, base64 encoded)
    # The API expects base64-encoded DER bytes, not the whole PEM file.
    # The PEM file already contains base64 DER data between the headers.
    local challenge_key=""
    if [ -f "$HOME/.blockcast/certs/gw_challenge.pem" ]; then
        # Extract just the base64 content (without PEM headers)
        challenge_key=$(grep -v '^-----' "$HOME/.blockcast/certs/gw_challenge.pem" | tr -d '\n')
    fi

    # Register gateway
    curl -sk $cert_args -X POST "$api_base/cdn/networks/test_cdn_network/gateways" \
        -H "Content-Type: application/json" \
        -d "{
            \"device\": {
                \"hardware_id\": \"$hw_id\",
                \"key\": {
                    \"key\": \"$challenge_key\",
                    \"key_type\": \"SOFTWARE_ECDSA_SHA256\"
                }
            },
            \"id\": \"test_gateway\",
            \"name\": \"Test Gateway\",
            \"description\": \"Test gateway for CI\",
            \"magmad\": {
                \"autoupgrade_enabled\": false,
                \"autoupgrade_poll_interval\": 300,
                \"checkin_interval\": 60,
                \"checkin_timeout\": 30
            },
            \"tier\": \"default\"
        }" 2>/dev/null || true

    log_success "Gateway registration attempted"
}

# Stop Docker Cloud
stop_docker_cloud() {
    log_info "Stopping Docker Cloud..."
    cd "$ORC8R_DOCKER_DIR"
    docker compose down --remove-orphans || true
}

# Start K8s Cloud (orc8r on minikube)
start_k8s_cloud() {
    log_info "Starting K8s Cloud..."

    # Create namespace if needed
    kubectl create namespace orc8r 2>/dev/null || true

    # Check if cloud is already deployed via helm
    if helm list -n orc8r 2>/dev/null | grep -q "orc8r"; then
        log_info "K8s Cloud already deployed via Helm"
    else
        # Try to deploy using helm if chart exists
        local orc8r_chart="$MAGMA_ROOT/orc8r/cloud/helm/orc8r"
        if [ -d "$orc8r_chart" ] && [ -f "$orc8r_chart/Chart.yaml" ]; then
            cd "$orc8r_chart"

            # Load images to minikube
            log_info "Loading orc8r images to minikube..."
            for img in orc8r_controller orc8r_caddy_proxy; do
                if docker images | grep -q "$img.*latest"; then
                    minikube image load "$img:latest" || true
                fi
            done

            # Find values file
            local values_file=""
            for vf in values_minikube.yaml values.yaml; do
                if [ -f "$vf" ]; then
                    values_file="$vf"
                    break
                fi
            done

            if [ -n "$values_file" ]; then
                log_info "Installing K8s Cloud from $orc8r_chart..."
                helm install orc8r . -n orc8r -f "$values_file" --wait --timeout 5m || true
            else
                log_warning "No values file found, skipping helm install"
            fi
        else
            log_info "K8s Cloud helm chart not found, checking if already running..."
        fi
    fi

    # Wait for pods to be ready
    log_info "Waiting for K8s Cloud pods to be ready..."
    local timeout=$STARTUP_TIMEOUT
    local ready=0
    while [ $timeout -gt 0 ]; do
        # `grep -c` always emits a single-line count; `|| echo 0` would append
        # a second "0" on grep's no-match exit, producing "0\n0" and breaking
        # the numeric comparison below. `|| true` keeps grep -c's count only.
        ready=$(kubectl get pods -n orc8r --no-headers 2>/dev/null | grep -c "Running" || true)
        ready=${ready:-0}
        if [ "$ready" -ge 20 ]; then
            log_success "K8s Cloud is ready ($ready pods running)"
            return 0
        fi
        sleep 5
        timeout=$((timeout - 5))
    done

    log_warning "K8s Cloud may not be fully ready (only $ready pods running)"
    return 0
}

# Stop K8s Cloud
stop_k8s_cloud() {
    log_info "Stopping K8s Cloud..."
    helm uninstall orc8r -n orc8r 2>/dev/null || true
    kubectl delete namespace orc8r --timeout=60s 2>/dev/null || true
}

# Start Docker Gateway
start_docker_gateway() {
    local cloud_type=$1  # "docker" or "k8s"
    log_info "Starting Docker Gateway (connecting to $cloud_type cloud)..."

    cd "$DOCKER_COMPOSE_DIR"

    # Unset any problematic environment variables that might interfere
    # The .env file in the docker directory has correct defaults
    unset CONTROLLER_HOST CONTROLLER_PORT

    if [ "$cloud_type" == "docker" ]; then
        # Docker-to-Docker: uses Docker network linking
        # CONTROLLER_HOST defaults to host-gateway in .env file
        # controller.magma.test resolves via extra_hosts to host machine
        docker compose up -d
    else
        # Docker-to-K8s: need to set up port forwards from host to K8s
        log_info "Setting up port forwards for K8s cloud..."
        local minikube_ip=$(minikube ip)

        # Start port forwards in background (host:7443 -> minikube NodePort)
        # The NodePort for the cloud ingress is typically 30443
        kubectl port-forward -n orc8r svc/orc8r-caddy-proxy 7443:8443 &>/dev/null &
        kubectl port-forward -n orc8r svc/orc8r-caddy-proxy 7444:8444 &>/dev/null &
        sleep 3

        docker compose up -d
    fi

    # Wait for gateway to start
    log_info "Waiting for Docker Gateway to start..."
    sleep 10

    if docker compose ps | grep -q "Up"; then
        log_success "Docker Gateway started"
        return 0
    else
        log_error "Docker Gateway failed to start"
        return 1
    fi
}

# Stop Docker Gateway
stop_docker_gateway() {
    log_info "Stopping Docker Gateway..."
    cd "$DOCKER_COMPOSE_DIR"
    docker compose down --remove-orphans || true
}

# Start K8s Gateway
start_k8s_gateway() {
    local cloud_type=$1  # "docker" or "k8s"
    log_info "Starting K8s Gateway (connecting to $cloud_type cloud)..."

    cd "$HELM_CHART_DIR"

    # Load gateway image to minikube
    log_info "Loading gateway image to minikube..."
    if docker images | grep -q "blockcast/cdn_gateway_go.*local-dev"; then
        minikube image load blockcast/cdn_gateway_go:local-dev || true
    fi

    # Prepare values based on cloud type
    local controller_ip configs_path cloud_port bootstrap_port
    if [ "$cloud_type" == "k8s" ]; then
        controller_ip="$(kubectl get svc -n orc8r orc8r-caddy-proxy -o jsonpath='{.spec.clusterIP}' 2>/dev/null || echo "10.96.0.1")"
        # K8s-to-K8s uses ports 8443/8444 and minikube configs
        configs_path="$MAGMA_ROOT/cdn/gateway/configs/minikube"
        cloud_port=8443
        bootstrap_port=8444
        # Ensure minikube configs mount is running
        if ! pgrep -f "minikube mount $configs_path:" &>/dev/null; then
            mkdir -p "$configs_path"
            nohup minikube mount "$configs_path:$configs_path" > "/tmp/minikube-mount-minikube-configs.log" 2>&1 &
            sleep 2
        fi
    else
        # Docker cloud - use host network with port forwards
        controller_ip="$(hostname -I | awk '{print $1}')"
        configs_path="$MAGMA_ROOT/cdn/gateway/configs/local"
        cloud_port=7443
        bootstrap_port=7444
    fi

    # Ensure namespace exists
    kubectl create namespace orc8r 2>/dev/null || true

    # Deploy with helm
    helm upgrade --install cdn-gateway . \
        -n orc8r --create-namespace \
        -f values_minikube.yaml \
        -f values_local.yaml \
        --set gateway.image.repository=blockcast/cdn_gateway_go \
        --set gateway.image.tag=local-dev \
        --set gateway.image.pullPolicy=Never \
        --set gateway.certsVolume.hostPath="$GATEWAY_CERTS_DIR" \
        --set gateway.snowflakeVolume.hostPath="$GATEWAY_SNOWFLAKE_DIR" \
        --set gateway.rootCAPath="$TEST_CERTS_DIR" \
        --set gateway.configsPath="$configs_path" \
        --set gateway.cloud_port="$cloud_port" \
        --set gateway.bootstrap_port="$bootstrap_port" \
        --set "gateway.hostAliases[0].ip=$controller_ip" \
        --set "gateway.hostAliases[0].hostnames[0]=controller.magma.test" \
        --set "gateway.hostAliases[0].hostnames[1]=bootstrapper-controller.magma.test" \
        --set "gateway.hostAliases[0].hostnames[2]=streamer-controller.magma.test" \
        --set "gateway.hostAliases[0].hostnames[3]=dispatcher-controller.magma.test" \
        --set "gateway.hostAliases[0].hostnames[4]=state-controller.magma.test" \
        --set "gateway.hostAliases[0].hostnames[5]=metricsd-controller.magma.test" \
        --set service.ipFamilyPolicy=SingleStack \
        --set "service.ipFamilies={IPv4}" \
        --wait --timeout 3m || true

    # Wait for gateway pods to be ready
    log_info "Waiting for K8s Gateway pods to be ready..."
    local timeout=60
    while [ $timeout -gt 0 ]; do
        local ready=$(kubectl get pods -n orc8r -l app.kubernetes.io/instance=cdn-gateway --no-headers 2>/dev/null | grep -c "Running" 2>/dev/null || echo "0")
        ready=${ready//[^0-9]/}  # Remove non-numeric chars
        ready=${ready:-0}
        if [ "$ready" -ge 3 ]; then
            log_success "K8s Gateway is ready ($ready pods running)"
            return 0
        fi
        sleep 5
        timeout=$((timeout - 5))
    done

    log_warning "K8s Gateway may not be fully ready"
    return 0
}

# Stop K8s Gateway
stop_k8s_gateway() {
    log_info "Stopping K8s Gateway..."
    helm uninstall cdn-gateway -n orc8r 2>/dev/null || true
}

# Verify gateway connectivity
verify_gateway() {
    local cloud_type=$1
    local gateway_type=$2
    log_info "Verifying gateway connectivity..."

    local cert_args="--cert $TEST_CERTS_DIR/admin_operator.pem --key $TEST_CERTS_DIR/admin_operator.key.pem"
    local api_url

    if [ "$cloud_type" == "docker" ]; then
        api_url="https://localhost:9443/magma/v1/networks/test_cdn_network/gateways/test_gateway/status"
    else
        # K8s cloud - need port forward
        # Kill any existing port forwards on 9443
        pkill -f "kubectl port-forward.*9443" 2>/dev/null || true
        sleep 1

        kubectl port-forward -n orc8r svc/orc8r-caddy-proxy 9443:9443 &>/dev/null &
        local pf_pid=$!
        sleep 3
        api_url="https://localhost:9443/magma/v1/networks/test_cdn_network/gateways/test_gateway/status"
    fi

    # Wait for gateway to check in
    local timeout=$CHECKIN_TIMEOUT
    while [ $timeout -gt 0 ]; do
        local status=$(curl -sk $cert_args "$api_url" 2>/dev/null)
        if echo "$status" | grep -q "checkin_time"; then
            local checkin_time=$(echo "$status" | grep -oP '"checkin_time":\d+' | cut -d: -f2)
            local now=$(date +%s)000
            local age=$(( (now - checkin_time) / 1000 ))

            if [ $age -lt 120 ]; then
                log_success "Gateway checked in ${age}s ago"
                [ -n "$pf_pid" ] && kill $pf_pid 2>/dev/null || true
                return 0
            fi
        fi
        sleep 5
        timeout=$((timeout - 5))
    done

    log_error "Gateway failed to check in within timeout"
    [ -n "$pf_pid" ] && kill $pf_pid 2>/dev/null || true
    return 1
}

# Run a single test
run_test() {
    local test_num=$1
    local cloud_type gateway_type

    case $test_num in
        1) cloud_type="docker"; gateway_type="docker" ;;
        2) cloud_type="docker"; gateway_type="k8s" ;;
        3) cloud_type="k8s"; gateway_type="docker" ;;
        4) cloud_type="k8s"; gateway_type="k8s" ;;
        *) log_error "Invalid test number: $test_num"; return 1 ;;
    esac

    log_header "Test $test_num: ${cloud_type^} Cloud + ${gateway_type^} Gateway"

    # Cleanup previous deployments
    stop_docker_gateway
    stop_k8s_gateway

    if [ "$cloud_type" == "docker" ]; then
        stop_k8s_cloud
        start_docker_cloud || { TEST_RESULTS[$test_num]="FAIL (cloud)"; return 1; }
    else
        stop_docker_cloud
        start_k8s_cloud || { TEST_RESULTS[$test_num]="FAIL (cloud)"; return 1; }
    fi

    # Register gateway with cloud
    register_gateway "$cloud_type"

    if [ "$gateway_type" == "docker" ]; then
        start_docker_gateway "$cloud_type" || { TEST_RESULTS[$test_num]="FAIL (gateway)"; return 1; }
    else
        start_k8s_gateway "$cloud_type" || { TEST_RESULTS[$test_num]="FAIL (gateway)"; return 1; }
    fi

    if verify_gateway "$cloud_type" "$gateway_type"; then
        TEST_RESULTS[$test_num]="PASS"
        log_success "Test $test_num PASSED"
        return 0
    else
        TEST_RESULTS[$test_num]="FAIL (connectivity)"
        log_error "Test $test_num FAILED"
        return 1
    fi
}

# Print test results summary
print_summary() {
    log_header "Test Results Summary"

    echo ""
    printf "%-8s %-15s %-15s %-10s\n" "Test" "Cloud" "Gateway" "Result"
    printf "%-8s %-15s %-15s %-10s\n" "----" "-----" "-------" "------"

    for test_num in 1 2 3 4; do
        local cloud gateway result
        case $test_num in
            1) cloud="Docker"; gateway="Docker" ;;
            2) cloud="Docker"; gateway="K8s" ;;
            3) cloud="K8s"; gateway="Docker" ;;
            4) cloud="K8s"; gateway="K8s" ;;
        esac
        result="${TEST_RESULTS[$test_num]:-NOT RUN}"

        if [ "$result" == "PASS" ]; then
            printf "%-8s %-15s %-15s ${GREEN}%-10s${NC}\n" "$test_num" "$cloud" "$gateway" "$result"
        elif [ "$result" == "NOT RUN" ]; then
            printf "%-8s %-15s %-15s ${YELLOW}%-10s${NC}\n" "$test_num" "$cloud" "$gateway" "$result"
        else
            printf "%-8s %-15s %-15s ${RED}%-10s${NC}\n" "$test_num" "$cloud" "$gateway" "$result"
        fi
    done
    echo ""
}

# Cleanup everything
cleanup_all() {
    log_header "Cleanup"
    stop_docker_gateway
    stop_k8s_gateway
    stop_docker_cloud
    stop_k8s_cloud
    cleanup_minikube_mounts
    log_success "Cleanup complete"
}

# Main function
main() {
    local tests_to_run=("$@")

    # If no tests specified, run all
    if [ ${#tests_to_run[@]} -eq 0 ]; then
        tests_to_run=(1 2 3 4)
    fi

    check_prerequisites
    setup_directories
    setup_minikube

    for test_num in "${tests_to_run[@]}"; do
        run_test "$test_num" || true
    done

    print_summary

    # Return success if all requested tests passed
    for test_num in "${tests_to_run[@]}"; do
        if [ "${TEST_RESULTS[$test_num]}" != "PASS" ]; then
            exit 1
        fi
    done
    exit 0
}

# Handle script arguments
case "${1:-}" in
    -h|--help)
        echo "Usage: $0 [test_numbers...]"
        echo ""
        echo "Tests:"
        echo "  1 - Docker Cloud + Docker Gateway"
        echo "  2 - Docker Cloud + K8s Gateway"
        echo "  3 - K8s Cloud + Docker Gateway"
        echo "  4 - K8s Cloud + K8s Gateway"
        echo ""
        echo "Examples:"
        echo "  $0           # Run all tests"
        echo "  $0 1         # Run only test 1"
        echo "  $0 3 4       # Run tests 3 and 4"
        echo "  $0 --cleanup # Cleanup all deployments"
        exit 0
        ;;
    --cleanup)
        cleanup_all
        exit 0
        ;;
    *)
        main "$@"
        ;;
esac
