#!/usr/bin/env bash
# Helm template tests for BLO-4759: dynamic-service Deployment fields owned
# by k8s_manager.
#
# Contract: the chart RENDERS the Deployment shell, but does NOT set
# `spec.replicas`. k8s_manager patches replicas at runtime based on the
# gateway's registered_dynamic_services state. If Helm also sets
# `spec.replicas`, every helm-upgrade fights k8s_manager's runtime patch
# via SSA, manifesting as a constant scale-up/scale-down oscillation.
#
# Run from the chart root:
#   bash tests/test-dynamic-services.sh
#
# Requires: helm (any v3), awk
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

run_helm() {
  helm template "$RELEASE" "$CHART_DIR" "$@" 2>&1
}

# All registered_dynamic_services (prod blockcastd.yml) plus pob.
DYNAMIC_SERVICES=(relay multicast traffic-monitor traffic-router moq-relay moq-player cast amt-relay)

# Assert that the Deployment named ${RELEASE}-$svc is rendered AND has no
# `spec.replicas` line (the field is owned by k8s_manager at runtime).
assert_deployment_without_replicas() {
  local svc="$1"
  local name="${RELEASE}-$svc"
  local has_dep has_replicas
  # Find the Deployment header for this svc.
  has_dep=$(echo "$OUTPUT" | awk -v want="$name" '
    /^---/             { in_dep=0 }
    /^kind: Deployment/ { in_dep=1 }
    in_dep && /^  name: / {
      n=$0; sub(/^  name: /, "", n)
      if (n == want) { print "yes"; in_dep=0 }
    }')
  if [[ "$has_dep" != "yes" ]]; then
    echo "  FAIL: $svc Deployment not rendered by chart"
    FAIL=$((FAIL + 1))
    return
  fi
  # Within the matching Deployment, look for any `  replicas:` line under spec.
  has_replicas=$(echo "$OUTPUT" | awk -v want="$name" '
    /^---/             { in_dep=0; matched=0 }
    /^kind: Deployment/ { in_dep=1 }
    in_dep && /^  name: / {
      n=$0; sub(/^  name: /, "", n)
      if (n == want) matched=1
    }
    matched && /^  replicas:/ { print $0; matched=0 }')
  if [[ -n "$has_replicas" ]]; then
    echo "  FAIL: $svc Deployment still sets replicas — will conflict with k8s_manager SSA"
    echo "    offending line: $has_replicas"
    FAIL=$((FAIL + 1))
  else
    echo "  PASS: $svc Deployment rendered without replicas (k8s_manager-owned)"
    PASS=$((PASS + 1))
  fi
}

echo "===== Dynamic-service Deployments render without spec.replicas (BLO-4759) ====="
OUTPUT=$(run_helm)
for svc in "${DYNAMIC_SERVICES[@]}"; do
  assert_deployment_without_replicas "$svc"
done

echo ""
echo ""
echo "===== pob is opt-in (.Values.pob.enabled=true) =====" 
echo ""
OUTPUT=$(run_helm --set pob.enabled=true)
assert_deployment_without_replicas "pob"
echo ""
echo "===== RESULTS: $PASS passed, $FAIL failed ====="
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
