#!/usr/bin/env bash
# Helm template matrix tests for the relay.ats container-level runAsUser pin.
# Guards the chart-1.8.40 fix for the regression where staging-blockcastd-receiver
# pod-level runAsUser:0 (needed for caddy-frontend's /opt/relay/var writes) caused
# traffic_server to crash with `Fatal: switching to user root, failed to set group ID 0`
# every ~13-20min — the privilege-drop code path's setgid attempt on reload-fork
# failed after the initial drop. Pinning trafficserver to runAsUser:1000 (image
# USER default) at the container level skips the drop entirely.
#
# Run from the chart root:
#   bash tests/test-relay-ats-runasuser.sh
#
# Requires: helm (any v3), grep, awk.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

# Helper: render only the relay deployment, extract just the trafficserver container block
run_helm_relay_trafficserver() {
  helm template "$RELEASE" "$CHART_DIR" \
    --show-only templates/relay/deployment.yaml \
    --set relay.caddyFrontend.enabled=true \
    "$@" 2>&1 \
    | awk '
        /- name: trafficserver/ { in_block=1 }
        in_block && /^      - name: [^t]/ { in_block=0 }
        in_block && /^      {{/ { in_block=0 }
        in_block { print }
      '
}

# Match only actual YAML key:value lines (skip comments containing the same string).
# Real lines look like "          runAsUser: 1000" (10-space indent). Comments
# look like "        # ... runAsUser: 0 ..." — has '#' before the match.
count_matches() { echo "$OUTPUT" | grep -v '^\s*#' | grep -c -e "$1" || true; }

assert_eq() {
  local label="$1" actual="$2" expected="$3"
  if [[ "$actual" -eq "$expected" ]]; then
    echo "  PASS: $label (got $actual)"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $label — expected $expected, got $actual"
    FAIL=$((FAIL + 1))
  fi
}

echo "===== SCENARIO A: defaults (runAsRoot omitted → ats:1000 pin) ====="
OUTPUT=$(run_helm_relay_trafficserver)
assert_eq "runAsUser: 1000 set"          "$(count_matches 'runAsUser: 1000')"        1
assert_eq "runAsGroup: 1000 set"         "$(count_matches 'runAsGroup: 1000')"       1
assert_eq "no runAsUser: 0"              "$(count_matches 'runAsUser: 0')"           0
assert_eq "no runAsGroup: 0"             "$(count_matches 'runAsGroup: 0')"          0

echo ""
echo "===== SCENARIO B: explicit runAsUser=2000 → that value emitted ====="
OUTPUT=$(run_helm_relay_trafficserver --set relay.ats.runAsUser=2000 --set relay.ats.runAsGroup=2000)
assert_eq "runAsUser: 2000 set"          "$(count_matches 'runAsUser: 2000')"        1
assert_eq "runAsGroup: 2000 set"         "$(count_matches 'runAsGroup: 2000')"       1
assert_eq "no default runAsUser: 1000"   "$(count_matches 'runAsUser: 1000')"        0

echo ""
echo "===== SCENARIO C: runAsRoot=true escape hatch → runAsUser:0 ====="
OUTPUT=$(run_helm_relay_trafficserver --set relay.ats.runAsRoot=true)
assert_eq "runAsUser: 0 set"             "$(count_matches 'runAsUser: 0')"           1
assert_eq "runAsGroup: 0 set"            "$(count_matches 'runAsGroup: 0')"          1
assert_eq "no runAsUser: 1000"           "$(count_matches 'runAsUser: 1000')"        0
assert_eq "no runAsGroup: 1000"          "$(count_matches 'runAsGroup: 1000')"       0

echo ""
echo "===== SCENARIO D: runAsRoot=false (explicit, identical to defaults) ====="
OUTPUT=$(run_helm_relay_trafficserver --set relay.ats.runAsRoot=false)
assert_eq "runAsUser: 1000 set"          "$(count_matches 'runAsUser: 1000')"        1
assert_eq "no runAsUser: 0"              "$(count_matches 'runAsUser: 0')"           0

echo ""
echo "===== RESULTS: $PASS passed, $FAIL failed ====="
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
