#!/usr/bin/env bash
# Helm template matrix tests for BLO-2393 postgresql architecture.
# Run from the chart root:
#   bash tests/test-postgresql-matrix.sh
#
# Requires: helm (any v3), grep
# Wire into CI: add a step that runs this script and checks exit code.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

run_helm() {
  helm template "$RELEASE" "$CHART_DIR" "$@" 2>&1
}

# Count occurrences of a grep pattern in $OUTPUT
count_matches() { echo "$OUTPUT" | grep -c "$1" || true; }

assert_eq() {
  local label="$1" actual="$2" expected="$3"
  if [[ "$actual" -eq "$expected" ]]; then
    echo "  PASS: $label (got $actual)"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $label — expected $expected, got $actual"
    FAIL=$((FAIL + 1))
  fi
}

assert_contains() {
  local label="$1" pattern="$2"
  if echo "$OUTPUT" | grep -q "$pattern"; then
    echo "  PASS: $label"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $label — expected output to contain: $pattern"
    FAIL=$((FAIL + 1))
  fi
}

echo "===== SCENARIO A: defaults (postgresql.enabled=false) ====="
OUTPUT=$(run_helm)
assert_eq "total resource count"                "$(count_matches '^kind:')"  15
assert_eq "zero StatefulSets"                   "$(count_matches 'kind: StatefulSet')" 0
assert_eq "zero postgres ConfigMaps"            "$(count_matches 'kind: ConfigMap')"   0
assert_eq "zero Secrets"                        "$(count_matches 'kind: Secret')"      0

echo ""
echo "===== SCENARIO B: postgresql.enabled=true + ingress.enabled=true + ingress.postgresql.create=true (legacy) ====="
OUTPUT=$(run_helm \
  --set postgresql.enabled=true \
  --set ingress.enabled=true \
  --set "ingress.postgresql.create=true")
assert_eq "no StatefulSet (legacy ingress postgres was StatefulSet)" \
          "$(count_matches 'kind: StatefulSet')" 0
assert_eq "exactly one postgres init ConfigMap"  "$(count_matches 'kind: ConfigMap')"  1
assert_eq "exactly one shared Secret"            "$(count_matches 'kind: Secret')"     1
# The postgres Deployment is one of four total; verify no naming collision by checking
# that only one resource is named '*-postgresql' at the Deployment level.
assert_eq "exactly one postgres Deployment" \
          "$(echo "$OUTPUT" | awk '/kind: Deployment/{found=1} found && /name:.*postgresql/{count++; found=0} END{print count+0}')" 1

echo ""
echo "===== SCENARIO C: postgresql.externalHost — Secret present, no in-cluster postgres Deployment ====="
OUTPUT=$(run_helm \
  --set postgresql.externalHost="db.internal" \
  --set ingress.enabled=true)
# Secret MUST be created so secretKeyRef in multicast/ingress pods resolves.
# Omitting it would cause CreateContainerConfigError at runtime even though
# helm template succeeds — this assertion catches that regression.
assert_eq "exactly one shared Secret"     "$(count_matches 'kind: Secret')"     1
assert_eq "zero ConfigMaps (no init-db)"  "$(count_matches 'kind: ConfigMap')"  0
assert_eq "zero postgres Deployments"     \
          "$(echo "$OUTPUT" | awk '/kind: Deployment/{found=1} found && /name:.*postgresql/{count++; found=0} END{print count+0}')" 0
assert_eq "chart still renders other resources" "$(count_matches '^kind:')"     16

echo ""
echo "===== SCENARIO D: fail-loud guard — ingress.postgresql.create=true with no backend ====="
OUTPUT=$(run_helm \
  --set ingress.enabled=true \
  --set "ingress.postgresql.create=true" 2>&1 || true)
assert_contains "fail() fires with descriptive message" \
                "standalone ingress postgres StatefulSet has been removed"

echo ""
echo "===== RESULTS: $PASS passed, $FAIL failed ====="
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
