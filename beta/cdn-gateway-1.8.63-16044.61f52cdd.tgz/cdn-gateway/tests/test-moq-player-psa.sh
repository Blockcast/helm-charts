#!/usr/bin/env bash
# Helm template matrix tests for the moqPlayer.rootEntrypoint PSA gate.
# Covers the regression that broke staging-blockcastd helm rev 727 on
# 2026-05-27: chart 1.8.31 rendered runAsNonRoot:true unconditionally
# while moq-player-origin:beta image has User=None.
#
# Run from the chart root:
#   bash tests/test-moq-player-psa.sh
#
# Requires: helm (any v3), grep.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

run_helm_moq_player() {
  helm template "$RELEASE" "$CHART_DIR" \
    --show-only templates/moq-player-deployment.yaml "$@" 2>&1
}

run_helm_moq_player_service() {
  helm template "$RELEASE" "$CHART_DIR" \
    --show-only templates/moq-player-service.yaml "$@" 2>&1
}

count_matches() { echo "$OUTPUT" | grep -c -e "$1" || true; }

assert_eq() {
  local label="$1" actual="$2" expected="$3"
  if [[ "$actual" -eq "$expected" ]]; then
    echo "  PASS: $label (got $actual)"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $label — expected $expected, got $actual"
    FAIL=$((FAIL + 1))
  fi
}

echo "===== SCENARIO A: defaults (rootEntrypoint omitted → true) ====="
OUTPUT=$(run_helm_moq_player)
assert_eq "runAsUser: 0 set"             "$(count_matches 'runAsUser: 0')"           1
assert_eq "runAsGroup: 0 set"            "$(count_matches 'runAsGroup: 0')"          1
assert_eq "runAsNonRoot: false set"      "$(count_matches 'runAsNonRoot: false')"    1
assert_eq "fsGroup: 999 set"             "$(count_matches 'fsGroup: 999')"           1
assert_eq "no helper runAsNonRoot"       "$(count_matches 'runAsNonRoot: true')"     0
assert_eq "CHOWN added to caps"          "$(count_matches '- CHOWN')"                1
assert_eq "SETUID added to caps"         "$(count_matches '- SETUID')"               1
assert_eq "SETGID added to caps"         "$(count_matches '- SETGID')"               1
assert_eq "NET_BIND_SERVICE retained"    "$(count_matches '- NET_BIND_SERVICE')"     1
assert_eq "cert sync init removed"       "$(count_matches 'name: moq-player-cert-sync-init')" 0
assert_eq "cert sync sidecar removed"    "$(count_matches 'name: moq-player-cert-sync$')" 0
assert_eq "busybox sync image removed"   "$(count_matches 'busybox')" 0
assert_eq "gateway cert dir mounted"     "$(count_matches 'mountPath: /var/opt/magma/certs')" 1
assert_eq "app cert dir not mounted"     "$(count_matches 'mountPath: /app/certs')" 0
assert_eq "emptyDir cert target removed" "$(count_matches 'emptyDir: {}')" 0
assert_eq "no file subPath rendered"     "$(count_matches 'subPath:')" 0
assert_eq "legacy moq Secret not defaulted"    "$(count_matches 'secretName: moq-relay-tls')" 0
assert_eq "moq-tls volume not defaulted"       "$(count_matches 'name: moq-tls')" 0

OUTPUT=$(run_helm_moq_player_service)
assert_eq "skip-mtls defaults to exact true"   "$(count_matches 'blockcast.net/skip-mtls: \"true\"')" 1
assert_eq "skip-mtls hostname pattern removed" "$(count_matches 'moq\\.\\*\\.bcast\\.id')" 0

echo ""
echo "===== SCENARIO B: rootEntrypoint=true (explicit) — identical to defaults ====="
OUTPUT=$(run_helm_moq_player --set moqPlayer.rootEntrypoint=true)
assert_eq "runAsNonRoot: false set"      "$(count_matches 'runAsNonRoot: false')"    1
assert_eq "CHOWN added"                  "$(count_matches '- CHOWN')"                1

echo ""
echo "===== SCENARIO C: rootEntrypoint=false — restricted-compliant ====="
OUTPUT=$(run_helm_moq_player --set moqPlayer.rootEntrypoint=false)
assert_eq "runAsNonRoot: true set"       "$(count_matches 'runAsNonRoot: true')"     1
assert_eq "no runAsUser: 0"              "$(count_matches 'runAsUser: 0')"           0
assert_eq "no runAsNonRoot: false"       "$(count_matches 'runAsNonRoot: false')"    0
assert_eq "no CHOWN"                     "$(count_matches '- CHOWN')"                0
assert_eq "no SETUID"                    "$(count_matches '- SETUID')"               0
assert_eq "no SETGID"                    "$(count_matches '- SETGID')"               0
assert_eq "NET_BIND_SERVICE still there" "$(count_matches '- NET_BIND_SERVICE')"     1

echo ""
echo "===== SCENARIO D: legacy Secret TLS source remains opt-in ====="
OUTPUT=$(run_helm_moq_player --set moqPlayer.tlsSource=secret --set moqPlayer.tlsSecretName=moq-relay-tls)
assert_eq "legacy Secret mounted as gateway cert dir" "$(count_matches 'mountPath: /var/opt/magma/certs')" 1
assert_eq "legacy Secret volume rendered"     "$(count_matches 'name: moq-tls')" 2
assert_eq "legacy Secret name rendered"       "$(count_matches 'secretName: moq-relay-tls')" 1
assert_eq "legacy Secret exposes gateway.crt" "$(count_matches 'path: gateway.crt')" 1
assert_eq "legacy Secret exposes gateway.key" "$(count_matches 'path: gateway.key')" 1
assert_eq "app cert dir skipped"              "$(count_matches 'mountPath: /app/certs')" 0
assert_eq "sync helper skipped"               "$(count_matches 'moq-player-cert-sync')" 0

echo ""
echo "===== SCENARIO E: old tlsSecretName-only overlays infer Secret mode ====="
OUTPUT=$(run_helm_moq_player --set moqPlayer.tlsSecretName=moq-relay-tls)
assert_eq "tlsSecretName-only Secret mounted" "$(count_matches 'mountPath: /var/opt/magma/certs')" 1
assert_eq "tlsSecretName-only Secret named"   "$(count_matches 'secretName: moq-relay-tls')" 1
assert_eq "tlsSecretName-only sync skipped"   "$(count_matches 'moq-player-cert-sync')" 0

echo ""
echo "===== RESULTS: $PASS passed, $FAIL failed ====="
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
