#!/usr/bin/env bash
# Helm template test for the TR bootstrap-zone persistence mount (BLO-9051).
#
# TR's NameServer self-seeds static bootstrap zones to
# /opt/traffic_router/var/auto-zones and reads them on cold start
# (loadBootstrapZones, before CrConfig). The chart mounts the traffic-router-db
# volume a 2nd time under subPath auto-zones so a previously-written bootstrap
# zone survives pod recreation, breaking the cold-start deadlock
# (no zone -> can't resolve the TM FQDN -> can't fetch CrConfig).
#
# The subPath mount is STRUCTURAL — it must render for BOTH dbVolume types
# (persistentVolumeClaim and emptyDir). Only the *persistence guarantee* is
# PVC-only (an emptyDir db volume still loses auto-zones on pod recreation;
# that's the non-persistent dev path). This test pins the mount's presence so a
# future edit to traffic-router-deployment.yaml can't silently drop the
# cold-start fix — the recurring helm-only-PR gap Ally flagged on #1110.
#
# Run from the chart root:  bash tests/test-tr-bootstrap-zones-subpath.sh
# Requires: helm (any v3), awk.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

# Render traffic-router-deployment.yaml and report whether the bootstrap-zone
# mount is present: a `mountPath: /opt/traffic_router/var/auto-zones` whose very
# next volumeMount key is `subPath: auto-zones`. Comment lines are stripped first
# ('^[[:space:]]*#', not '\s', for BSD-grep portability) so the YAML comment
# block above the mount can't false-positive. A hard render failure surfaces as
# the explicit RENDER_FAILED token so an assert fails loudly instead of being
# misread as "absent".
render_has_autozones_mount() {
  local out errf
  errf=$(mktemp)
  if ! out=$(helm template "$RELEASE" "$CHART_DIR" \
      --show-only templates/traffic-router-deployment.yaml "$@" 2>"$errf"); then
    echo "  RENDER_FAILED (helm error): $(tr '\n' ' ' < "$errf")" >&2
    rm -f "$errf"; echo "RENDER_FAILED"; return 0
  fi
  rm -f "$errf"
  printf '%s\n' "$out" \
    | grep -v '^[[:space:]]*#' \
    | awk '
        /mountPath:[[:space:]]*\/opt\/traffic_router\/var\/auto-zones/ { m=1; next }
        m && /subPath:[[:space:]]*auto-zones/ { print "present"; found=1; exit }
        m { m=0 }
        END { if (!found) print "absent" }'
}

assert_eq() {
  local label="$1" actual="$2" expected="$3"
  if [[ "$actual" == "$expected" ]]; then
    echo "  PASS: $label (got '$actual')"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $label — expected '$expected', got '$actual'"
    FAIL=$((FAIL + 1))
  fi
}

echo "===== SCENARIO A: default dbVolume (persistentVolumeClaim) → auto-zones subPath mount present ====="
assert_eq "auto-zones subPath mount present (PVC)" \
  "$(render_has_autozones_mount)" "present"

echo ""
echo "===== SCENARIO B: dbVolume.type=emptyDir → auto-zones subPath mount STILL present (structural; persistence is PVC-only) ====="
assert_eq "auto-zones subPath mount present (emptyDir)" \
  "$(render_has_autozones_mount --set trafficRouter.dbVolume.type=emptyDir)" "present"

echo ""
echo "===== RESULTS: ${PASS} passed, ${FAIL} failed ====="
[[ "${FAIL}" -eq 0 ]] || exit 1
