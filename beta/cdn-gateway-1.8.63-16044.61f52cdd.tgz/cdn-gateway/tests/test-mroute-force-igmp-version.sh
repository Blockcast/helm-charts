#!/usr/bin/env bash
# Helm template tests for amtRelay.mroute.forceIgmpVersion → MROUTE_FORCE_IGMP_VERSION.
#
# This knob lets a routed SSM receiver VLAN pin the kernel IGMP version on the
# amt-astats mroute input iface (force_igmp_version=3) so the source-specific
# join egresses as an IGMPv3 INCLUDE report. An iface that negotiated IGMPv2
# silently degrades the (S,G) filter to an any-source join, which an SSM-only
# upstream (MX204 PIM-SSM) will not forward. Default 0 = leave it untouched.
# Consumed by amt-astats (linux-amt mroute.Config.ForceIGMPVersion).
#
# Run from the chart root:
#   bash tests/test-mroute-force-igmp-version.sh
#
# Requires: helm (any v3), grep, awk.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

# Render the amt-relay deployment, extract the value line immediately after the
# MROUTE_FORCE_IGMP_VERSION env name (skip comment lines containing the string).
render_force_igmp_value() {
  # Keep helm's stderr out of the parsed stream and surface a hard render
  # failure as an explicit RENDER_FAILED token (≠ any expected value, so the
  # assert fails clearly instead of silently comparing against "").
  local out errf
  errf=$(mktemp)
  if ! out=$(helm template "$RELEASE" "$CHART_DIR" \
      --show-only templates/amt-relay-deployment.yaml "$@" 2>"$errf"); then
    echo "  RENDER_FAILED (helm error): $(tr '\n' ' ' < "$errf")" >&2
    rm -f "$errf"
    echo "RENDER_FAILED"
    return 0
  fi
  rm -f "$errf"
  # '^[[:space:]]*#' (not '\s') so the comment strip is portable to BSD grep.
  printf '%s\n' "$out" \
    | grep -v '^[[:space:]]*#' \
    | awk '/- name: MROUTE_FORCE_IGMP_VERSION/{getline; print; exit}' \
    | sed -E 's/.*value:[[:space:]]*//; s/"//g; s/[[:space:]]*$//'
}

assert_eq() {
  local label="$1" actual="$2" expected="$3"
  if [[ "$actual" == "$expected" ]]; then
    echo "  PASS: $label (got '$actual')"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $label — expected '$expected', got '$actual'"
    FAIL=$((FAIL + 1))
  fi
}

echo "===== SCENARIO A: default (no override) → 0, behavior unchanged ====="
assert_eq "MROUTE_FORCE_IGMP_VERSION defaults to 0" "$(render_force_igmp_value)" "0"

echo ""
echo "===== SCENARIO B: forceIgmpVersion=3 → 3 (routed SSM receiver VLAN) ====="
assert_eq "override emitted" "$(render_force_igmp_value --set amtRelay.mroute.forceIgmpVersion=3)" "3"

echo ""
echo "===== SCENARIO C: forceIgmpVersion=2 → 2 (explicit other value passes through) ====="
assert_eq "arbitrary value passthrough" "$(render_force_igmp_value --set amtRelay.mroute.forceIgmpVersion=2)" "2"

echo ""
echo "===== RESULTS: $PASS passed, $FAIL failed ====="
[[ "$FAIL" -eq 0 ]]
