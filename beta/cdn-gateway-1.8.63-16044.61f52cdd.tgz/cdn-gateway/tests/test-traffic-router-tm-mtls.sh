#!/usr/bin/env bash
# Helm template tests for Traffic Router -> Traffic Monitor mTLS wiring.
#
# Contract: TM polling uses gateway PEM files directly; Traffic Router should
# not depend on derived Java keystores for that identity.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

run_helm() {
  helm template "$RELEASE" "$CHART_DIR" \
    --show-only templates/traffic-router-deployment.yaml "$@" 2>&1
}

env_value() {
  local key="$1"
  echo "$OUTPUT" | awk -v key="$key" '
    $0 ~ "- name: " key "$" { found=1; next }
    found && $1 == "value:" {
      v=$2
      gsub(/^"/, "", v)
      gsub(/"$/, "", v)
      print v
      exit
    }
  '
}

assert_env_eq() {
  local key="$1" expected="$2" actual
  actual="$(env_value "$key")"
  if [[ "$actual" == "$expected" ]]; then
    echo "  PASS: $key=$expected"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $key expected $expected, got ${actual:-<missing>}"
    FAIL=$((FAIL + 1))
  fi
}

assert_not_contains() {
  local needle="$1"
  if grep -Fq -- "$needle" <<<"$OUTPUT"; then
    echo "  FAIL: rendered output contains $needle"
    FAIL=$((FAIL + 1))
  else
    echo "  PASS: rendered output does not contain $needle"
    PASS=$((PASS + 1))
  fi
}

echo "===== Traffic Router TM mTLS defaults to gateway PEM ====="
OUTPUT="$(run_helm)"
assert_env_eq "tr_tm_client_cert_file" "/var/opt/magma/certs/gateway.crt"
assert_env_eq "tr_tm_client_key_file" "/var/opt/magma/certs/gateway.key"
assert_not_contains "client.p12"
assert_not_contains "truststore.p12"

echo ""
echo "===== Traffic Router TM CA follows trafficRouter.caCertFile ====="
OUTPUT="$(run_helm --set trafficRouter.caCertFile=/var/opt/magma/certs/certifier.pem)"
assert_env_eq "tr_tm_ca_cert_file" "/var/opt/magma/certs/certifier.pem"

echo ""
echo "===== Traffic Router TM mTLS can override identity independently ====="
OUTPUT="$(run_helm \
  --set trafficRouter.tmClientCertFile=/custom/tm-client.crt \
  --set trafficRouter.tmClientKeyFile=/custom/tm-client.key \
  --set trafficRouter.tmCaCertFile=/custom/tm-ca.pem)"
assert_env_eq "tr_tm_client_cert_file" "/custom/tm-client.crt"
assert_env_eq "tr_tm_client_key_file" "/custom/tm-client.key"
assert_env_eq "tr_tm_ca_cert_file" "/custom/tm-ca.pem"

echo ""
echo "===== RESULTS: $PASS passed, $FAIL failed ====="
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
