#!/usr/bin/env bash
# Helm template tests for amtRelay.listenIface / listenIface6 → AMT_LISTEN_IFACE.
#
# AMT_LISTEN_IFACE pins the kernel relay stream_dev — the gateway-facing AMT
# tunnel egress plane + the device the advertised VIP binds on. It is distinct
# from MROUTE_INPUT_IFACE (the multicast-receive VLAN where amt-astats issues
# the (S,G) join). The two were a single device historically, so when
# listenIface is UNSET the env MUST NOT be emitted — the amtr wrapper then
# defaults stream_dev to MROUTE_INPUT_IFACE (legacy behavior, byte-identical
# render). Set listenIface to split the AMT tunnel plane (e.g. net2 / the VIP)
# from a dedicated routed multicast-receive VLAN (mroute.inputIface, e.g. net3).
# Consumed by the amtr wrapper (linux-amt#70: scripts/amt-relay.sh PRIMARY_IFACE).
#
# Run from the chart root:
#   bash tests/test-amt-listen-iface.sh
#
# Requires: helm (any v3), grep, awk.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

# Render the amt-relay deployment and return the value immediately after the
# given env name (skip comment lines containing the string). Empty output =
# the env was not emitted at all. A hard render failure surfaces as the
# explicit RENDER_FAILED token so an assert fails loudly instead of comparing
# against "" (which is also the legitimate "not emitted" result).
render_env_value() {
  local envname="$1"; shift
  local out errf
  errf=$(mktemp)
  if ! out=$(helm template "$RELEASE" "$CHART_DIR" \
      --show-only templates/amt-relay-deployment.yaml "$@" 2>"$errf"); then
    echo "  RENDER_FAILED (helm error): $(tr '\n' ' ' < "$errf")" >&2
    rm -f "$errf"
    echo "RENDER_FAILED"
    return 0
  fi
  rm -f "$errf"
  # '^[[:space:]]*#' (not '\s') so the comment strip is portable to BSD grep.
  printf '%s\n' "$out" \
    | grep -v '^[[:space:]]*#' \
    | awk -v n="- name: $envname" '$0 ~ n {getline; print; exit}' \
    | sed -E 's/.*value:[[:space:]]*//; s/"//g; s/[[:space:]]*$//'
}

assert_eq() {
  local label="$1" actual="$2" expected="$3"
  if [[ "$actual" == "$expected" ]]; then
    echo "  PASS: $label (got '$actual')"
    PASS=$((PASS + 1))
  else
    echo "  FAIL: $label — expected '$expected', got '$actual'"
    FAIL=$((FAIL + 1))
  fi
}

echo "===== SCENARIO A: default (no listenIface) → AMT_LISTEN_IFACE NOT emitted (legacy coupling) ====="
assert_eq "v4 env absent by default" "$(render_env_value AMT_LISTEN_IFACE)" ""
assert_eq "v6 env absent by default" "$(render_env_value AMT_LISTEN_IFACE6)" ""

echo ""
echo "===== SCENARIO B: listenIface=net2 → AMT_LISTEN_IFACE=net2 (split tunnel plane onto net2/.96) ====="
assert_eq "v4 env emitted" "$(render_env_value AMT_LISTEN_IFACE --set amtRelay.listenIface=net2)" "net2"
# v6 stays absent unless explicitly set — setting v4 alone must not leak a v6 env.
assert_eq "v6 stays absent when only v4 set" "$(render_env_value AMT_LISTEN_IFACE6 --set amtRelay.listenIface=net2)" ""

echo ""
echo "===== SCENARIO C: listenIface6=net2 → AMT_LISTEN_IFACE6=net2 (independent v6 override) ====="
assert_eq "v6 env emitted" "$(render_env_value AMT_LISTEN_IFACE6 --set amtRelay.listenIface6=net2)" "net2"

echo ""
echo "===== SCENARIO D: both set → both emitted (full mcast-rx cutover shape) ====="
assert_eq "v4 emitted" "$(render_env_value AMT_LISTEN_IFACE --set amtRelay.listenIface=net2 --set amtRelay.listenIface6=net2)" "net2"
assert_eq "v6 emitted" "$(render_env_value AMT_LISTEN_IFACE6 --set amtRelay.listenIface=net2 --set amtRelay.listenIface6=net2)" "net2"

echo ""
echo "===== RESULTS: $PASS passed, $FAIL failed ====="
[[ "$FAIL" -eq 0 ]]
