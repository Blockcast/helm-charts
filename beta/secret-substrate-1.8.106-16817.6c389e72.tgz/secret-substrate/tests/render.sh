#!/usr/bin/env bash
set -euo pipefail

chart_dir=$(cd "$(dirname "$0")/.." && pwd)
rendered=$(mktemp)
trap 'rm -f "$rendered"' EXIT

helm repo add hashicorp https://helm.releases.hashicorp.com --force-update
helm repo add external-secrets https://charts.external-secrets.io --force-update
helm dependency build "$chart_dir"
helm lint "$chart_dir"
helm template secret-substrate "$chart_dir" > "$rendered"
bash "$chart_dir/tests/unseal-sidecar.sh"

grep -q 'kind: ClusterSecretStore' "$rendered"
grep -q 'kind: ExternalSecret' "$rendered"
grep -q 'key: pop/networking/bgp-session' "$rendered"
grep -q 'storageClassName: rook-ceph-block' "$rendered"
grep -q 'tls_disable = 0' "$rendered"
grep -q 'server: "https://secret-substrate-vault-active.vault.svc:8200"' "$rendered"
grep -q 'secretName: vault-server-tls' "$rendered"
grep -q 'name: tpm-read' "$rendered"
grep -q 'registry.blockcast.net/blockcast/tpm-read:latest@sha256:1034d72410b13c1ac071bba8e6425ce05a24f7669e430a8b267e40438219ca2b' "$rendered"
grep -q 'tpm2_nvread 0x1500000' "$rendered"
grep -q 'chown 100:1000 /vault/unseal/key.next' "$rendered"
grep -q 'chmod 0400 /vault/unseal/key.next' "$rendered"
grep -q 'medium: Memory' "$rendered"
grep -q 'path: /dev/tpm0' "$rendered"
grep -q 'path: /dev/tpmrm0' "$rendered"
grep -q 'name: tpm-unseal' "$rendered"
grep -q 'Vault unseal request failed; retrying' "$rendered"
grep -q 'name: vault-server-tls' "$rendered"
grep -q 'namespace: vault' "$rendered"
if awk '/^    volumeMounts:/{main_mounts=1; next} main_mounts && /^external-secrets:/{exit} main_mounts && /name: vault-unseal/{found=1} END{exit !found}' "$chart_dir/values.yaml"; then
  printf 'Vault server container must not mount unseal material\n' >&2
  exit 1
fi
awk '/^kind: ServiceAccount$/{sa=1; next} sa && /^  name: external-secrets$/{found=1} /^---$/{sa=0} END{exit !found}' "$rendered"
if grep -Eiq 'root[_-]?token|unseal[_-]?(key|share)[[:space:]]*:' "$rendered"; then
  printf 'rendered chart must not persist root or unseal material\n' >&2
  exit 1
fi
