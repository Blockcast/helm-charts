#!/usr/bin/env bash
set -euo pipefail

chart_dir=$(cd "$(dirname "$0")/.." && pwd)
sidecar_script=$(mktemp)
fake_bin=$(mktemp -d)
unseal_key=$(mktemp)
unseal_log=$(mktemp)
trap 'rm -rf "$sidecar_script" "$fake_bin" "$unseal_key" "$unseal_log"' EXIT

awk '
  $0 == "      - name: tpm-unseal" { container = 1 }
  container && $0 == "          - |" { script = 1; next }
  script && substr($0, 1, 12) == "            " { print substr($0, 13); next }
  script { exit }
' "$chart_dir/values.yaml" > "$sidecar_script"
test -s "$sidecar_script"

cat > "$fake_bin/curl" <<'EOF'
#!/bin/sh
url=
for arg do
  url=$arg
done
case "$url" in
  */seal-status)
    if [ "${FAKE_VAULT_UNREACHABLE:-false}" = true ]; then
      exit 7
    fi
    printf '{"sealed":%s}\n' "${FAKE_VAULT_SEALED:-false}"
    ;;
  */unseal)
    cat >> "$FAKE_VAULT_UNSEAL_LOG"
    printf '\n' >> "$FAKE_VAULT_UNSEAL_LOG"
    ;;
  *)
    exit 2
    ;;
esac
EOF
chmod +x "$fake_bin/curl"

printf 'vaultshare+/=' > "$unseal_key"
set +e
PATH="$fake_bin:$PATH" \
  VAULT_UNSEAL_KEY_FILE="$unseal_key" \
  VAULT_UNSEAL_POLL_INTERVAL=0.01 \
  FAKE_VAULT_SEALED=false \
  FAKE_VAULT_UNSEAL_LOG="$unseal_log" \
  timeout 0.1 /bin/sh -e "$sidecar_script"
status=$?
set -e
test "$status" -eq 124
test ! -s "$unseal_log"

set +e
PATH="$fake_bin:$PATH" \
  VAULT_UNSEAL_KEY_FILE="$unseal_key" \
  VAULT_UNSEAL_POLL_INTERVAL=0.01 \
  FAKE_VAULT_UNREACHABLE=true \
  FAKE_VAULT_UNSEAL_LOG="$unseal_log" \
  timeout 0.1 /bin/sh -e "$sidecar_script"
status=$?
set -e
test "$status" -eq 124
test ! -s "$unseal_log"

set +e
PATH="$fake_bin:$PATH" \
  VAULT_UNSEAL_KEY_FILE="$unseal_key" \
  VAULT_UNSEAL_POLL_INTERVAL=0.01 \
  FAKE_VAULT_SEALED=true \
  FAKE_VAULT_UNSEAL_LOG="$unseal_log" \
  timeout 0.1 /bin/sh -e "$sidecar_script"
status=$?
set -e
test "$status" -eq 124
test -s "$unseal_log"
awk '$0 != "{\"key\":\"vaultshare+/=\"}" { exit 1 }' "$unseal_log"

printf 'not"json-safe' > "$unseal_key"
set +e
PATH="$fake_bin:$PATH" \
  VAULT_UNSEAL_KEY_FILE="$unseal_key" \
  VAULT_UNSEAL_POLL_INTERVAL=0.01 \
  FAKE_VAULT_SEALED=true \
  FAKE_VAULT_UNSEAL_LOG="$unseal_log" \
  timeout 0.1 /bin/sh -e "$sidecar_script"
status=$?
set -e
test "$status" -eq 1
