#!/usr/bin/env bash
# Helm template tests for QUIC catch-all routing.
#
# Contract: when moqRelay is enabled (with or without internalQuicPort/quicSNI),
# the `-quic` UDPRoute must be a plain-UDP catch-all (no annotations), so
# caddy_watcher's pushQUICServer resolves the default backend via the
# annotation-driven UDPRoute path documented in
# trafficcontrol/blockcast/ingress/caddy_watcher.go:781 (internal issue fix C):
#
#   defaultBackend := w.QUICDefaultBackend          // L4_QUIC_DEFAULT_BACKEND env
#   if defaultBackend == "" {
#       // fall through to highest-priority plain-UDP UDPRoute (no SNI/ALPN)
#       ...
#   }
#
# Failure mode this test pins down:
#   - When `-quic` carries `blockcast.net/quic-alpn`, browser WebTransport
#     (which negotiates with ALPN=h3, NOT in the list) does not match any
#     ALPN rule, falls to the catch-all, and reaches L4_QUIC_DEFAULT_BACKEND.
#   - Chart used to set L4_QUIC_DEFAULT_BACKEND to the *internal* mTLS port
#     (4453, ED25519 gateway cert), causing Chrome's WT handshake to fail
#     with `NoSignatureSchemesInCommon`. The RKS-served LE cert sat on the
#     *external* port (4443) unreachable by browsers.
#
# Run from the chart root:
#   bash tests/test-quic-routing.sh
#
# Requires: helm (any v3), awk

set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

run_helm() {
  helm template "$RELEASE" "$CHART_DIR" "$@" 2>&1
}

# Render with moqRelay enabled + Gateway API enabled (UDPRoutes only render
# under that gate) + an internal-only SNI route. The public browser relay
# wildcard is covered by a negative assertion below.
OUTPUT=$(run_helm \
  --set moqRelay.enabled=true \
  --set moqRelay.internalQuicPort=4453 \
  --set moqRelay.quicSNI="moq-relay-internal.*.bcast.id" \
  --set relay.gatewayAPI.enabled=true)

# --- Assertion 1: `-quic` UDPRoute must have NO annotations.
# It is the catch-all default; the converter at
# blockcast/ingress/caddy_watcher.go:781 only treats UDPRoutes without
# QuicSNI AND without QuicALPN as the plain-UDP catch-all.
assert_quic_udproute_has_no_annotations() {
  local quic_block
  quic_block=$(echo "$OUTPUT" | awk -v want="${RELEASE}-quic" '
    /^---/                       { in_block=0; matched=0; saw_meta=0 }
    /^kind: UDPRoute/            { in_block=1 }
    in_block && /^  name: /      {
      n=$0; sub(/^  name: /, "", n)
      if (n == want) { matched=1; print "kind: UDPRoute"; print $0 }
      else           { in_block=0 }
    }
    matched && /^  [a-z]/        { print $0 }
    matched && /^---/            { matched=0 }
  ')
  if [[ -z "$quic_block" ]]; then
    echo "  FAIL: ${RELEASE}-quic UDPRoute not rendered"
    FAIL=$((FAIL + 1)); return
  fi
  if echo "$quic_block" | grep -qE '^\s+annotations:'; then
    echo "  FAIL: ${RELEASE}-quic UDPRoute has annotations (must be plain-UDP catch-all)"
    echo "$quic_block" | sed 's/^/    /'
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: ${RELEASE}-quic UDPRoute is plain-UDP (no annotations)"
  PASS=$((PASS + 1))
}

# --- Assertion 2: `-quic-internal` UDPRoute must keep its SNI annotation +
# priority 200. (Regression guard — this is the route that splits cast→relay
# mTLS traffic off the catch-all.)
assert_quic_internal_keeps_sni_routing() {
  local internal_block
  internal_block=$(echo "$OUTPUT" | awk -v want="${RELEASE}-quic-internal" '
    /^---/                       { in_block=0; matched=0 }
    /^kind: UDPRoute/            { in_block=1 }
    in_block && /^  name: /      {
      n=$0; sub(/^  name: /, "", n)
      if (n == want) { matched=1; print "kind: UDPRoute"; print $0 }
      else           { in_block=0 }
    }
    matched && /^  [a-z]/        { print $0 }
    matched && /^---/            { matched=0 }
    matched && /^    /           { print $0 }
  ')
  if [[ -z "$internal_block" ]]; then
    echo "  FAIL: ${RELEASE}-quic-internal UDPRoute not rendered"
    FAIL=$((FAIL + 1)); return
  fi
  if ! echo "$internal_block" | grep -qE 'blockcast\.net/quic-sni:'; then
    echo "  FAIL: ${RELEASE}-quic-internal missing blockcast.net/quic-sni annotation"
    FAIL=$((FAIL + 1)); return
  fi
  if ! echo "$internal_block" | grep -qE 'blockcast\.net/priority:[[:space:]]*"?200"?'; then
    echo "  FAIL: ${RELEASE}-quic-internal missing blockcast.net/priority: 200"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: ${RELEASE}-quic-internal keeps SNI + priority annotations"
  PASS=$((PASS + 1))
}

# --- Assertion 3: caddy-frontend container must NOT carry L4_QUIC_DEFAULT_BACKEND.
# This env was the internal issue stopgap that has been superseded by the annotation
# pipeline (templates/relay/gateway-api.yaml UDPRoutes). Re-introducing it
# forces a single default for ALL unmatched QUIC traffic — which on the
# pre-fix chart pointed at the mTLS-required internal port and broke
# browser WebTransport.
assert_no_l4_quic_default_backend_env() {
  if echo "$OUTPUT" | grep -qE '^\s+(- )?name:\s*L4_QUIC_DEFAULT_BACKEND\b'; then
    echo "  FAIL: caddy-frontend container has L4_QUIC_DEFAULT_BACKEND env (must use annotation pipeline)"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: L4_QUIC_DEFAULT_BACKEND env tombstoned"
  PASS=$((PASS + 1))
}

# --- Assertion 4: dead annotation `blockcast.net/quic-internal-backend`
# must not be emitted. The converter at
# blockcast/ingress/gateway/annotations.go has no constant for it; it is
# silently dropped. Emitting it gives the false impression that it drives
# routing — keep the chart honest about what is consumed.
assert_no_quic_internal_backend_annotation() {
  if echo "$OUTPUT" | grep -qE 'blockcast\.net/quic-internal-backend:'; then
    echo "  FAIL: blockcast.net/quic-internal-backend annotation present (dead annotation, converter does not consume)"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: dead annotation blockcast.net/quic-internal-backend removed"
  PASS=$((PASS + 1))
}

# --- Assertion 5: the internal mTLS UDPRoute must not claim the public
# browser relay SNI. Browser WebTransport also uses `moq-relay.*.bcast.id`;
# routing that SNI to :4453 serves the ED25519 gateway cert and Chrome fails
# before cert pinning with `NoSignatureSchemesInCommon`.
assert_public_relay_sni_rejected_for_internal_route() {
  local err rc
  set +e
  err=$(run_helm \
    --set moqRelay.enabled=true \
    --set moqRelay.internalQuicPort=4453 \
    --set moqRelay.quicSNI="moq-relay.*.bcast.id" \
    --set relay.gatewayAPI.enabled=true)
  rc=$?
  set -e

  if [[ "$rc" -eq 0 ]]; then
    echo "  FAIL: public moq-relay.*.bcast.id SNI rendered for internal mTLS route"
    FAIL=$((FAIL + 1)); return
  fi
  if ! echo "$err" | grep -q 'must not use public browser relay SNI'; then
    echo "  FAIL: public SNI render failed with unexpected error"
    echo "$err" | sed 's/^/    /'
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: public browser relay SNI rejected for internal mTLS route"
  PASS=$((PASS + 1))
}

# --- Assertion 6: with RKS enabled, gateway.crt/key must be used only as the
# mTLS identity, not passed as a static external QUIC listener certificate.
# Browser-facing relay SNIs need RKS/LE certs; serving gateway.crt on the
# external listener caused Chrome WebTransport to fail TLS before pinning.
assert_rks_omits_gateway_external_tls_args() {
  if grep -q -- '--tls-cert=/var/opt/magma/certs/gateway.crt' <<<"$OUTPUT"; then
    echo "  FAIL: moq-relay renders gateway.crt as external --tls-cert while RKS is enabled"
    FAIL=$((FAIL + 1)); return
  fi
  if grep -q -- '--tls-key=/var/opt/magma/certs/gateway.key' <<<"$OUTPUT"; then
    echo "  FAIL: moq-relay renders gateway.key as external --tls-key while RKS is enabled"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: RKS render omits gateway cert/key external TLS args"
  PASS=$((PASS + 1))
}

# --- Assertion 7: a distinct external cert is still allowed as an RKS resolver
# seed. Only the gateway/RKS mTLS pair is suppressed.
assert_rks_allows_distinct_external_tls_seed() {
  local out
  out=$(run_helm \
    --set moqRelay.enabled=true \
    --set moqRelay.rks.enabled=true \
    --set moqRelay.tlsCert=/etc/moq/external.crt \
    --set moqRelay.tlsKey=/etc/moq/external.key)

  if ! grep -q -- '--tls-cert=/etc/moq/external.crt' <<<"$out"; then
    echo "  FAIL: distinct external --tls-cert not rendered with RKS enabled"
    FAIL=$((FAIL + 1)); return
  fi
  if ! grep -q -- '--tls-key=/etc/moq/external.key' <<<"$out"; then
    echo "  FAIL: distinct external --tls-key not rendered with RKS enabled"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: RKS render allows distinct external TLS seed"
  PASS=$((PASS + 1))
}

# --- Assertion 8 (internal issue): when rendering with values_staging.yaml, the
# moq-relay Deployment must leave RKS_URL unset. The :beta image entrypoint
# defaults BUILD_ENV=dev to https://rks-staging.blockcast.net; adding an
# explicit chart env risks reintroducing stale per-env drift.
#
# Extracts the value via awk that pins the moq-relay Deployment name
# exactly (anchored $), the env name exactly (anchored $), and surfaces a
# loud failure if the Deployment never renders — guarding against future
# template renames silently passing the env-match step.
_assert_moq_relay_rks_url() {
  local out="$1" want="$2" label="$3"
  local matched rks_url
  matched=$(echo "$out" | awk '/^  name: test-release-moq-relay$/ { print "yes" }' | head -1)
  if [[ "$matched" != "yes" ]]; then
    echo "  FAIL: ${label}: test-release-moq-relay Deployment not rendered"
    FAIL=$((FAIL + 1)); return
  fi
  rks_url=$(echo "$out" | awk '
    /^---/                               { in_dep=0; matched=0 }
    /^kind: Deployment/                  { in_dep=1 }
    in_dep && /^  name: test-release-moq-relay$/ { matched=1 }
    matched && /^        - name: RKS_URL$/ { take=1; next }
    take                                 { sub(/^.*value: /, ""); gsub(/"/, ""); print; take=0; matched=0 }
  ' | head -1)
  if [[ "$rks_url" != "$want" ]]; then
    echo "  FAIL: ${label}: moq-relay RKS_URL = ${rks_url:-<empty>} (want ${want})"
    FAIL=$((FAIL + 1)); return
  fi
  echo "  PASS: ${label}: RKS_URL = ${want}"
  PASS=$((PASS + 1))
}

assert_staging_moq_relay_rks_url() {
  _assert_moq_relay_rks_url \
    "$(run_helm -f "$CHART_DIR/values_staging.yaml")" \
    "" \
    "values_staging.yaml leaves RKS_URL to beta image default"
}

# --- Assertion 9 (internal issue regression guard, opposite direction): prod
# values must NOT carry the staging override. Catches a copy-paste of the
# staging block landing in values_prod.yaml — prod moq-relay would then
# query staging RKS, get back staging-tenant LE certs for prod FQDNs, and
# Chrome would reject on hostname mismatch. Same failure mode as the
# 2026-04-29 stale-RKS-entry incident, in the opposite direction.
assert_prod_moq_relay_rks_url() {
  _assert_moq_relay_rks_url \
    "$(run_helm -f "$CHART_DIR/values_prod.yaml")" \
    "https://rks.blockcast.net" \
    "values_prod.yaml keeps prod RKS"
}

echo "=== test-quic-routing.sh ==="
assert_quic_udproute_has_no_annotations
assert_quic_internal_keeps_sni_routing
assert_no_l4_quic_default_backend_env
assert_no_quic_internal_backend_annotation
assert_public_relay_sni_rejected_for_internal_route
assert_rks_omits_gateway_external_tls_args
assert_rks_allows_distinct_external_tls_seed
assert_staging_moq_relay_rks_url
assert_prod_moq_relay_rks_url
echo
echo "PASS=$PASS FAIL=$FAIL"
[[ $FAIL -eq 0 ]]
