#!/usr/bin/env bash
# internal issue Phase 1: Helm-template assertions for the new amtRelayLinux toggle.
#
# Guards:
#   * Default chart (amtRelayLinux.enabled=false) renders ZERO docs from any of
#     the three new templates. Production must not see surprise resources.
#   * With enabled=true + minimal overlay, the rendered Deployment matches the
#     spike-validated config: MROUTE_INPUT_IFACE=net1 (NOT the canary's broken
#     net2), USE_EBPF=true, eBPF FlowSource on, kmod init container present,
#     vpp-mcast NAD podAnnotation, expected nodeSelector labels.
#   * Service renders with the LB-IPAM annotations the operator overlay sets.
#   * The juniper amt-relay template (existing amtRelay.*) renders byte-identical
#     against values_prod.yaml whether or not the new toggle is in scope.
#
# Run from the chart root:
#   bash tests/test-amt-relay-linux.sh
#
# Requires: helm v3, grep, awk, diff.
set -euo pipefail

CHART_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RELEASE="test-release"
PASS=0
FAIL=0

pass() { echo "  PASS: $1"; PASS=$((PASS+1)); }
fail() { echo "  FAIL: $1"; FAIL=$((FAIL+1)); }

ok() { local label="$1"; shift; if "$@" >/dev/null 2>&1; then pass "$label"; else fail "$label"; fi; }

# ------- Test 1: defaults render nothing for the three new templates --------
echo "Test 1: defaults (amtRelayLinux.enabled=false) produce zero new docs"
for tpl in amt-relay-linux-deployment.yaml amt-relay-linux-service.yaml amt-astats-wal-linux-pvc.yaml; do
  out=$(helm template "$RELEASE" "$CHART_DIR" --show-only "templates/$tpl" 2>&1 || true)
  # helm prints "could not find template ..." when the file gate produces nothing.
  if echo "$out" | grep -q "could not find template" || ! echo "$out" | grep -q '^kind:'; then
    pass "default: $tpl renders no documents"
  else
    fail "default: $tpl unexpectedly produced output: $out"
  fi
done

# ------- Test 2: enabled=true produces the spike-validated deployment --------
echo
echo "Test 2: enabled=true with minimal overlay renders spike-validated deployment"
OUT=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.replicas=1 \
  --set amtRelayLinux.advertisedIP=69.25.95.128 \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set 'amtRelayLinux.nodeSelector.blockcast\.net/amt-relay-active=true' \
  --set 'amtRelayLinux.nodeSelector.blockcast\.net/amt-kmod-netlinkfix=6.8.0-117' \
  --set 'amtRelayLinux.podAnnotations.k8s\.v1\.cni\.cncf\.io/networks=vpp-mcast' \
  --set 'amtRelayLinux.podAnnotations.config\.cilium\.io/disable-source-ip-verification=true' \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)

ok "Deployment kind renders"            grep -q '^kind: Deployment'           <<<"$OUT"
ok "name is <release>-amt-relay-linux"  grep -q "name: ${RELEASE}-amt-relay-linux" <<<"$OUT"
ok "replicas: 1"                        grep -q '^  replicas: 1'              <<<"$OUT"
ok "component label = amt-relay-linux"  grep -q 'app.kubernetes.io/component: amt-relay-linux' <<<"$OUT"
ok "podAnnotation vpp-mcast first"      grep -q 'k8s.v1.cni.cncf.io/networks: vpp-mcast' <<<"$OUT"
# --set X=true yields an unquoted YAML boolean (`true`); operators using
# --set-string get `"true"`. Either is functionally equivalent for the Cilium
# annotation parser, so allow both.
ok "podAnnotation disable-src-ip"       grep -qE 'config.cilium.io/disable-source-ip-verification: "?true"?' <<<"$OUT"
ok "MROUTE_INPUT_IFACE=net1 (NOT net2)" grep -q 'value: "net1"'                <<<"$(awk '/- name: MROUTE_INPUT_IFACE/{f=1;next} f{print;f=0}' <<<"$OUT")"
ok "MROUTE_INPUT_IFACE6=net1"           grep -q 'value: "net1"'                <<<"$(awk '/- name: MROUTE_INPUT_IFACE6/{f=1;next} f{print;f=0}' <<<"$OUT")"
ok "USE_EBPF=true"                      grep -q 'value: "true"'                <<<"$(awk '/- name: USE_EBPF/{f=1;next} f{print;f=0}' <<<"$OUT")"
ok "ENABLE_EBPF_BILLING=true"           grep -q 'value: "true"'                <<<"$(awk '/- name: ENABLE_EBPF_BILLING/{f=1;next} f{print;f=0}' <<<"$OUT")"
ok "AMT_ASTATS_PRIMARY_SOURCE=ebpf"     grep -q 'value: "ebpf"'                <<<"$(awk '/- name: AMT_ASTATS_PRIMARY_SOURCE/{f=1;next} f{print;f=0}' <<<"$OUT")"
ok "AMT_RELAY_TYPE=linux"               grep -q 'value: "linux"'               <<<"$(awk '/- name: AMT_RELAY_TYPE/{f=1;next} f{print;f=0}' <<<"$OUT")"
ok "AMT_RELAY_ADVERTISED_IP=.128"       grep -q 'value: "69.25.95.128"'        <<<"$(awk '/- name: AMT_RELAY_ADVERTISED_IP/{f=1;next} f{print;f=0}' <<<"$OUT")"
ok "kmod init container present"        grep -q 'name: amt-kmod-installer'    <<<"$OUT"
ok "v6 mcast forwarding init present"   grep -q 'name: enable-v6-mcast-forwarding' <<<"$OUT"
ok "allowPrivilegeEscalation=true"      grep -q 'allowPrivilegeEscalation: true' <<<"$OUT"
ok "nodeSelector amt-relay-active"      grep -q 'blockcast.net/amt-relay-active: "\?true"\?' <<<"$OUT"
ok "nodeSelector amt-kmod-netlinkfix"   grep -q 'blockcast.net/amt-kmod-netlinkfix: "\?6.8.0-117"\?' <<<"$OUT"
# Negation assertions: `ok` runs its args as a command, and a leading `!` is
# parsed as the special shell pipeline operator there, not as a negation of
# grep's exit. Express the inverted check directly.
if ! grep -q 'GNMI_TARGET\|GNMI_USERNAME' <<<"$OUT"; then pass "NO juniper gnmi env"; else fail "NO juniper gnmi env"; fi
if ! grep -q 'SERVICE303_ENABLED'         <<<"$OUT"; then pass "NO juniper service303 env"; else fail "NO juniper service303 env"; fi

# ------- Test 3: Service renders with LB-IPAM annotations -------------------
echo
echo "Test 3: Service with LB-IPAM annotations"
SVC=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set 'amtRelayLinux.service.annotations.io\.cilium/lb-ipam-ips=69.25.95.128' \
  --set 'amtRelayLinux.service.annotations.lbipam\.cilium\.io/sharing-key=blockcastd-relay' \
  --show-only templates/amt-relay-linux-service.yaml 2>&1)

ok "Service type=LoadBalancer"          grep -q '^  type: LoadBalancer'                  <<<"$SVC"
ok "externalTrafficPolicy=Cluster"      grep -q '^  externalTrafficPolicy: Cluster'      <<<"$SVC"
ok "lb-ipam-ips annotation present"     grep -q 'io.cilium/lb-ipam-ips: 69.25.95.128'    <<<"$SVC"
ok "sharing-key=blockcastd-relay"       grep -q 'lbipam.cilium.io/sharing-key: blockcastd-relay' <<<"$SVC"
ok "selector targets amt-relay-linux"   grep -q 'app.kubernetes.io/name: amt-relay-linux' <<<"$SVC"

# ------- Test 4: PVC renders only when enabled=true + walPersistence.enabled --
echo
echo "Test 4: WAL PVC gating"
PVC_DEFAULT=$(helm template "$RELEASE" "$CHART_DIR" --show-only templates/amt-astats-wal-linux-pvc.yaml 2>&1 || true)
if echo "$PVC_DEFAULT" | grep -q '^kind: PersistentVolumeClaim'; then
  fail "PVC unexpectedly rendered with defaults (enabled=false)"
else
  pass "PVC absent at default (enabled=false)"
fi

PVC_ON=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --show-only templates/amt-astats-wal-linux-pvc.yaml 2>&1)
ok "PVC renders with enabled=true"      grep -q '^kind: PersistentVolumeClaim'           <<<"$PVC_ON"
ok "PVC name suffix is wal-linux"       grep -q 'name: .*-amt-astats-wal-linux'          <<<"$PVC_ON"
ok "PVC storage = 12Gi (default)"       grep -q 'storage: 12Gi'                          <<<"$PVC_ON"
ok "PVC storageClass = ceph-rbd"        grep -q 'storageClassName: ceph-rbd'             <<<"$PVC_ON"

# ------- Test 5: Required kernelVersion check ------------------------------
echo
echo "Test 5: kmod.kernelVersion required when amtRelayLinux.enabled=true"
ERR=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true 2>&1 || true)
ok "missing kernelVersion fails loud"   grep -q 'amtRelayLinux.kmod.kernelVersion is required' <<<"$ERR"

# ------- Test 6: juniper relay rendering unchanged --------------------------
echo
echo "Test 6: juniper amt-relay template is byte-identical with and without amtRelayLinux toggle"
JUNIPER_OFF=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --show-only templates/amt-relay-deployment.yaml 2>&1)
JUNIPER_ON=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --show-only templates/amt-relay-deployment.yaml 2>&1)
if diff <(echo "$JUNIPER_OFF") <(echo "$JUNIPER_ON") >/dev/null 2>&1; then
  pass "juniper render byte-identical with amtRelayLinux toggle on vs off"
else
  fail "juniper render differs between amtRelayLinux on vs off"
fi

# ------- Test 7: nodeSelector fallback chain (Ally review #1079) -----------
# Mirrors juniper amt-relay-deployment.yaml: amtRelayLinux > gateway > top-level.
# Without this, an operator setting `enabled: true` with no
# `amtRelayLinux.nodeSelector` (default `{}`) gets a privileged hostPath pod
# that can schedule on any node.
echo
echo "Test 7: nodeSelector fallback chain (amtRelayLinux > gateway > top-level)"

# Explicit amtRelayLinux.nodeSelector wins over gateway + top-level.
NS_LINUX=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set 'amtRelayLinux.nodeSelector.role=relay-linux-explicit' \
  --set 'gateway.nodeSelector.role=relay-gateway' \
  --set 'nodeSelector.role=relay-toplevel' \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
ok "primary: amtRelayLinux.nodeSelector wins"   grep -q 'role: relay-linux-explicit' <<<"$NS_LINUX"
if ! grep -q 'role: relay-gateway\|role: relay-toplevel' <<<"$NS_LINUX"; then
  pass "primary: gateway/toplevel selectors suppressed"
else
  fail "primary: stale fallback selector leaked into render"
fi

# gateway.nodeSelector wins when amtRelayLinux.nodeSelector is unset.
NS_GATEWAY=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set 'gateway.nodeSelector.role=relay-gateway' \
  --set 'nodeSelector.role=relay-toplevel' \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
ok "fallback: gateway.nodeSelector applied"     grep -q 'role: relay-gateway' <<<"$NS_GATEWAY"
if ! grep -q 'role: relay-toplevel' <<<"$NS_GATEWAY"; then
  pass "fallback: toplevel selector suppressed"
else
  fail "fallback: toplevel leaked when gateway was set"
fi

# Top-level .Values.nodeSelector is the last-resort fallback.
NS_TOP=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set 'nodeSelector.role=relay-toplevel' \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
ok "fallback: top-level nodeSelector applied"   grep -q 'role: relay-toplevel' <<<"$NS_TOP"

# ------- Test 8: useEbpf string footgun (Ally review #1079) ----------------
# `useEbpf` is a quoted string ("true"/"false"). The cap-gate must compare
# explicitly to "true" via toString so that "false" actually suppresses
# BPF/PERFMON caps instead of falling through as truthy-non-empty.
echo
echo "Test 8: useEbpf gate suppresses BPF/PERFMON when explicitly disabled"

# Default (no override) keeps BPF + PERFMON.
EBPF_DEFAULT=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
ok "default: BPF cap present"                   grep -q '^              - BPF$'     <<<"$EBPF_DEFAULT"
ok "default: PERFMON cap present"               grep -q '^              - PERFMON$' <<<"$EBPF_DEFAULT"

# useEbpf="false" (string) suppresses both caps AND sets USE_EBPF=false in env.
EBPF_OFF_STR=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set-string amtRelayLinux.useEbpf=false \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
if ! grep -q '^              - BPF$\|^              - PERFMON$' <<<"$EBPF_OFF_STR"; then
  pass "useEbpf=\"false\" (string): BPF/PERFMON caps suppressed"
else
  fail "useEbpf=\"false\" (string): caps leaked through string-truthy gate"
fi
ok "useEbpf=\"false\" (string): USE_EBPF=false in env" \
  grep -q 'value: "false"' <<<"$(awk '/- name: USE_EBPF/{f=1;next} f{print;f=0}' <<<"$EBPF_OFF_STR")"

# useEbpf=false (bool) suppresses both caps AND sets USE_EBPF=false in env.
# This is the bool case that Sprig's `default` would mis-handle.
EBPF_OFF_BOOL=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set amtRelayLinux.useEbpf=false \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
if ! grep -q '^              - BPF$\|^              - PERFMON$' <<<"$EBPF_OFF_BOOL"; then
  pass "useEbpf=false (bool): BPF/PERFMON caps suppressed"
else
  fail "useEbpf=false (bool): caps leaked through truthy gate"
fi
ok "useEbpf=false (bool): USE_EBPF=false in env" \
  grep -q 'value: "false"' <<<"$(awk '/- name: USE_EBPF/{f=1;next} f{print;f=0}' <<<"$EBPF_OFF_BOOL")"

# ------- Test 9: ipfix gate (internal issue PR3) ---------------------------------
# Default-on (clean-slate operator gets full billing path with no extra
# config), but turn-off-able for coexistence at a shared LB-IPAM VIP where
# `(IP, port, proto)` collides with an existing juniper-relay ipfix Service.
echo
echo "Test 9: ipfix gate (default-on, disable for VIP coexistence)"

# Default: both Service port AND Deployment containerPort + IPFIX_PORT env.
IPFIX_DEFAULT_SVC=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --show-only templates/amt-relay-linux-service.yaml 2>&1)
IPFIX_DEFAULT_DEP=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
ok "default: Service ipfix port present"        grep -q '^  - name: ipfix$'        <<<"$IPFIX_DEFAULT_SVC"
ok "default: Deployment ipfix containerPort"    grep -q '^        - name: ipfix$'  <<<"$IPFIX_DEFAULT_DEP"
ok "default: IPFIX_PORT env present"            grep -q 'name: IPFIX_PORT'         <<<"$IPFIX_DEFAULT_DEP"

# Disabled: all three artifacts absent.
IPFIX_OFF_SVC=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set amtRelayLinux.ipfix.enabled=false \
  --show-only templates/amt-relay-linux-service.yaml 2>&1)
IPFIX_OFF_DEP=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set amtRelayLinux.ipfix.enabled=false \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
if ! grep -q '^  - name: ipfix$'       <<<"$IPFIX_OFF_SVC"; then pass "disabled: Service ipfix port absent"; else fail "disabled: Service ipfix port leaked"; fi
if ! grep -q '^        - name: ipfix$' <<<"$IPFIX_OFF_DEP"; then pass "disabled: Deployment ipfix containerPort absent"; else fail "disabled: Deployment ipfix containerPort leaked"; fi
if ! grep -q 'name: IPFIX_PORT'        <<<"$IPFIX_OFF_DEP"; then pass "disabled: IPFIX_PORT env absent"; else fail "disabled: IPFIX_PORT env leaked"; fi

# Custom port via amtRelayLinux.ipfix.port (overlay knob).
IPFIX_CUSTOM_SVC=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set amtRelayLinux.ipfix.port=4740 \
  --show-only templates/amt-relay-linux-service.yaml 2>&1)
ok "custom: Service ipfix port=4740"           grep -qE '^    port: 4740$'         <<<"$IPFIX_CUSTOM_SVC"

# ------- Test 10: service303 gate (internal issue PR3) ---------------------------
# Default-on (mirrors juniper amtRelay.service303 chart-default-true). Both
# staging blockcastd-amt-relay and production blockcastd-amt-relay expose
# :9191/TCP today via that juniper chart default; the linux variant matches
# so the only Service-shape difference vs juniper is the ipfix gate. Same
# Sprig hasKey normalization as ipfix — `| default true` would invert an
# operator-set `service303.enabled: false`.
echo
echo "Test 10: service303 gate (default-on, mirrors juniper; disable-suppressible)"

# Default: emitted on both Service and Deployment at port 9191.
S303_DEFAULT_SVC=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --show-only templates/amt-relay-linux-service.yaml 2>&1)
S303_DEFAULT_DEP=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
ok "default: Service service303 port present"   grep -q '^  - name: service303$'       <<<"$S303_DEFAULT_SVC"
ok "default: Service service303 port=9191"      grep -qE '^    port: 9191$'             <<<"$S303_DEFAULT_SVC"
ok "default: Deployment service303 cport"       grep -q '^        - name: service303$' <<<"$S303_DEFAULT_DEP"

# Disabled (bool): absent from both Service and Deployment.
S303_OFF_SVC=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set amtRelayLinux.service303.enabled=false \
  --show-only templates/amt-relay-linux-service.yaml 2>&1)
S303_OFF_DEP=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set amtRelayLinux.service303.enabled=false \
  --show-only templates/amt-relay-linux-deployment.yaml 2>&1)
if ! grep -q '^  - name: service303$'       <<<"$S303_OFF_SVC"; then pass "disabled: Service service303 port absent"; else fail "disabled: Service service303 leaked"; fi
if ! grep -q '^        - name: service303$' <<<"$S303_OFF_DEP"; then pass "disabled: Deployment service303 containerPort absent"; else fail "disabled: Deployment service303 leaked"; fi

# Custom port via amtRelayLinux.service303.port (with default-on, no enable= needed).
S303_CUSTOM_SVC=$(helm template "$RELEASE" "$CHART_DIR" -f "$CHART_DIR/values_prod.yaml" \
  --set amtRelayLinux.enabled=true \
  --set amtRelayLinux.kmod.kernelVersion=6.8.0-117-generic \
  --set amtRelayLinux.service303.port=9292 \
  --show-only templates/amt-relay-linux-service.yaml 2>&1)
ok "custom: Service service303 port=9292"       grep -qE '^    port: 9292$'             <<<"$S303_CUSTOM_SVC"

# -------- Summary -----------------------------------------------------------
echo
echo "PASS=$PASS  FAIL=$FAIL"
[[ "$FAIL" -eq 0 ]] || exit 1
