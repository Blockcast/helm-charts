#!/usr/bin/env bash
#
# Smoke tests for the local K8s launcher DNS replacement. These avoid a live
# cluster and exercise the pure helpers that render the CoreDNS override.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../../../../.." && pwd)"
cd "${REPO_ROOT}"

python3 - <<'PY'
import pathlib
import sys
import unittest


REPO_ROOT = pathlib.Path.cwd()
sys.path.insert(0, str(REPO_ROOT))

from cdn.fab.k8s_ops import K8sOps  # noqa: E402


class TestLocalK8sLauncherDNS(unittest.TestCase):
    def test_controller_hostnames_cover_local_launcher_contract(self):
        hostnames = K8sOps.get_local_controller_hostnames(
            "controller.magma.test",
            "bootstrapper-controller.magma.test",
        )

        self.assertIn("controller.magma.test", hostnames)
        self.assertIn("api.magma.test", hostnames)
        self.assertIn("bootstrapper-controller.magma.test", hostnames)
        self.assertIn("dispatcher-controller.magma.test", hostnames)
        self.assertIn("state-controller.magma.test", hostnames)
        self.assertIn("traffic-ops", hostnames)
        self.assertEqual(len(hostnames), len(set(hostnames)))

    def test_coredns_block_keeps_sni_names_and_expands_bare_names(self):
        block = K8sOps._render_coredns_hosts_block(
            "203.0.113.22",
            ["controller.magma.test", "traffic-ops"],
            "magma",
        )

        self.assertIn(K8sOps.COREDNS_LOCAL_CONTROLLER_BEGIN, block)
        self.assertIn("203.0.113.22 controller.magma.test", block)
        self.assertIn("203.0.113.22 traffic-ops", block)
        self.assertIn("203.0.113.22 traffic-ops.magma.svc.cluster.local", block)
        self.assertIn("fallthrough", block)

    def test_upsert_coredns_hosts_block_is_idempotent(self):
        corefile = """.:53 {
    errors
    ready
    kubernetes cluster.local in-addr.arpa ip6.arpa {
        pods insecure
    }
    forward . /etc/resolv.conf
}
"""
        hostnames = ["controller.magma.test", "traffic-ops"]
        first = K8sOps._upsert_coredns_hosts_block(
            corefile, "203.0.113.22", hostnames, "magma",
        )
        second = K8sOps._upsert_coredns_hosts_block(
            first, "203.0.113.22", hostnames, "magma",
        )

        self.assertEqual(first, second)
        self.assertEqual(first.count(K8sOps.COREDNS_LOCAL_CONTROLLER_BEGIN), 1)
        self.assertLess(first.index("hosts {"), first.index("kubernetes cluster.local"))

    def test_upsert_merges_minikube_nodehosts_block(self):
        corefile = """.:53 {
    errors
    health {
        lameduck 5s
    }
    ready
    kubernetes cluster.local in-addr.arpa ip6.arpa {
        pods insecure
        fallthrough in-addr.arpa ip6.arpa
    }
    hosts /etc/coredns/NodeHosts {
        ttl 60
        reload 15s
        fallthrough
    }
    forward . /etc/resolv.conf
}
"""
        hostnames = ["controller.magma.test", "traffic-ops"]
        first = K8sOps._upsert_coredns_hosts_block(
            corefile, "203.0.113.22", hostnames, "magma",
        )
        second = K8sOps._upsert_coredns_hosts_block(
            first, "203.0.113.22", hostnames, "magma",
        )

        self.assertEqual(first, second)
        self.assertEqual(first.count("hosts /etc/coredns/NodeHosts {"), 1)
        self.assertNotIn("\n    hosts {\n", first)
        self.assertIn("203.0.113.22 controller.magma.test", first)
        self.assertIn("203.0.113.22 traffic-ops.magma.svc.cluster.local", first)
        self.assertLess(
            first.index("203.0.113.22 controller.magma.test"),
            first.index("        fallthrough\n    }\n    forward"),
        )

    def test_launcher_no_longer_sets_dead_host_aliases_values(self):
        source = (REPO_ROOT / "cdn/fab/k8s_ops.py").read_text()
        dead_key = "gateway." + "host" + "Aliases"

        self.assertNotIn(dead_key, source)


if __name__ == "__main__":
    unittest.main()
PY
