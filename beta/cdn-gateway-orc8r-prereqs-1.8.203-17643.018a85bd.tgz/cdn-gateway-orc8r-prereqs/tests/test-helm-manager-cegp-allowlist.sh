#!/usr/bin/env bash
# PEN-3947 regression guard.
#
# templates/helm-manager-rbac.yaml scopes the blockcastd-gateway SA's
# update/patch/delete on ciliumegressgatewaypolicies to an explicit
# `resourceNames` allowlist, replacing a cluster-wide grant. Same trade, and
# the same two-sided risk, as the clusterroles allowlist guarded by
# test-helm-manager-allowlist-covers-main-chart.sh: too BROAD leaves a
# cluster-wide destructive primitive, too NARROW 403s a live helm upgrade with
# `ciliumegressgatewaypolicies.cilium.io "<name>" is forbidden`.
#
# The allowlist lives in the PREREQS chart; the objects it names are rendered
# by the MAIN chart. Nothing else makes the two move together, so this asserts
# they do: every CiliumEgressGatewayPolicy the main chart can render must
# appear in the rendered prereqs allowlist.
#
# NOT covered: orphans recorded only in a prior release manifest in-cluster.
# Chart source cannot see those; they need a live enumeration and
# `extraHelmManagedCiliumEgressGatewayPolicyNames`.
#
# Note on herestrings: every assertion below reads a rendered manifest with
# `<<<`, never a pipe. A large render piped into a short-circuiting reader
# (`grep -q`, `awk ... {exit}`) gives the writer EPIPE, which `pipefail`
# promotes to the pipeline's status and INVERTS the verdict. See the repo
# CLAUDE.md entry on this.
set -euo pipefail

PREREQS="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN="$(cd "$PREREQS/../cdn-gateway-orc8r" && pwd)"

NS=staging-blockcastd-receiver
MAIN_RELEASE=blockcastd
PREREQS_RELEASE=blockcastd-prereqs

PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); echo "  PASS: $1"; }
bad() { FAIL=$((FAIL+1)); echo "  FAIL: $1" >&2; }

# Pulls the resourceNames of the cilium.io rule that carries `delete`.
# Tracks apiGroups per rule rather than keying on the verb list alone: the
# rendered ClusterRole has TWO `["update", "patch", "delete"]` rules (the
# rbac.authorization.k8s.io one from PEN-3933 and this one), so a verb-only
# matcher reads the wrong allowlist and passes while cilium.io is unscoped.
cegp_allowlist() {
  awk '
    /^  - apiGroups:/ { rule = $0; names = ""; verbs = ""; collecting = 0 }
    /^    verbs:/     { verbs = $0 }
    /^    resourceNames:/ { collecting = 1; next }
    collecting && /^      - / { sub(/^      - /, ""); gsub(/^"|"$/, ""); names = names $0 "\n"; next }
    collecting && /^  - / { collecting = 0 }
    /^---/ || /^  - apiGroups:/ {
      if (prev_rule ~ /cilium\.io/ && prev_verbs ~ /"delete"/) printf "%s", prev_names
      prev_rule = rule; prev_verbs = verbs; prev_names = names
    }
    END { if (prev_rule ~ /cilium\.io/ && prev_verbs ~ /"delete"/) printf "%s", prev_names }
  ' <<<"$1"
}

echo "== rendering the prereqs helm-manager ClusterRole =="
err=$(mktemp)
if ! HM_DOC=$(helm template "$PREREQS_RELEASE" "$PREREQS" \
      --namespace "$NS" --set releaseName="$MAIN_RELEASE" \
      --show-only templates/helm-manager-rbac.yaml 2>"$err"); then
  echo "FAIL: helm template of the prereqs chart failed" >&2
  sed 's/^/    /' "$err" >&2; rm -f "$err"; exit 1
fi
rm -f "$err"

ALLOWLIST=$(cegp_allowlist "$HM_DOC")
if [ -z "$ALLOWLIST" ]; then
  echo "FAIL: no cilium.io rule carrying \`delete\` has a resourceNames allowlist." >&2
  echo "      Either the rule was re-widened to cluster-wide, or the rule split was removed." >&2
  exit 1
fi
echo "  allowlist: $(tr '\n' ' ' <<<"$ALLOWLIST")"

# --- no cluster-wide destructive verb survives ------------------------------
# The whole point of PEN-3947: a cilium.io rule granting `delete` must also
# carry resourceNames. Judged per rule, at the point the NEXT rule starts.
UNSCOPED=$(awk '
  function flush() {
    if (rule ~ /cilium\.io/ && verbs ~ /"delete"/ && names == 0) print "unscoped"
  }
  /^  - apiGroups:/       { flush(); rule = $0; verbs = ""; names = 0; next }
  /^    verbs:/           { verbs = $0; next }
  /^    resourceNames:/   { names = 1; next }
  /^---/                  { flush(); rule = ""; verbs = ""; names = 0; next }
  END { flush() }
' <<<"$HM_DOC")
if [ -n "$UNSCOPED" ]; then
  bad "a cilium.io rule grants \`delete\` with no resourceNames (cluster-wide destructive grant is back)"
else
  ok "every cilium.io rule granting \`delete\` carries resourceNames"
fi

# --- every CEGP the main chart can render is in the allowlist ---------------
# Both templates are gated off in committed values, so the gates are forced on
# here. That is the point: the allowlist must cover what the chart CAN render,
# not only what today's values happen to enable.
echo "== rendering the main chart with both CEGP gates forced on =="
err=$(mktemp)
if ! MAIN_DOC=$(helm template "$MAIN_RELEASE" "$MAIN" --namespace "$NS" \
      --set relay.egress.provider=cilium \
      --set relay.egress.sourceIPv4=203.0.113.12 \
      --set relay.egress.enabled=true \
      --set relay.service.loadBalancerIP=203.0.113.10 \
      --set multicast.egressBgpAnchor.enabled=true \
      --set multicast.egressBgpAnchor.vip=203.0.113.11 \
      --set multicast.egressBgpAnchor.pool=staging \
      --set 'multicast.egressBgpAnchor.nodeSelector.egress-gateway=true' 2>"$err"); then
  echo "FAIL: helm template of the main chart failed" >&2
  sed 's/^/    /' "$err" >&2; rm -f "$err"; exit 1
fi
rm -f "$err"

RENDERED=$(awk '
  /^kind: CiliumEgressGatewayPolicy/ { want = 1; next }
  want && /^  name:/ { print $2; want = 0 }
' <<<"$MAIN_DOC")

# Non-vacuous: if the main chart renders no CEGP at all, this guard proves
# nothing and must fail rather than report a green pass.
RENDERED_COUNT=$(grep -c . <<<"$RENDERED" || true)
if [ -z "$RENDERED" ] || [ "$RENDERED_COUNT" -lt 2 ]; then
  echo "FAIL: expected the main chart to render both CEGPs with the gates on; got ${RENDERED_COUNT}." >&2
  echo "      Either a template moved or its gate changed -- this guard is vacuous until that is fixed." >&2
  exit 1
fi
echo "  main chart renders: $(tr '\n' ' ' <<<"$RENDERED")"

while read -r name; do
  [ -n "$name" ] || continue
  if grep -qxF "$name" <<<"$ALLOWLIST"; then
    ok "main-chart CEGP '$name' is in the prereqs allowlist"
  else
    bad "main-chart CEGP '$name' is NOT in the prereqs allowlist -- helm upgrade will 403 on it"
  fi
done <<<"$RENDERED"

# --- the escape hatch appends ----------------------------------------------
err=$(mktemp)
if ! EXTRA_DOC=$(helm template "$PREREQS_RELEASE" "$PREREQS" \
      --namespace "$NS" --set releaseName="$MAIN_RELEASE" \
      --set 'extraHelmManagedCiliumEgressGatewayPolicyNames[0]=some-orphan-cegp' \
      --show-only templates/helm-manager-rbac.yaml 2>"$err"); then
  echo "FAIL: helm template with extraHelmManagedCiliumEgressGatewayPolicyNames failed" >&2
  sed 's/^/    /' "$err" >&2; rm -f "$err"; exit 1
fi
rm -f "$err"
if grep -qxF "some-orphan-cegp" <<<"$(cegp_allowlist "$EXTRA_DOC")"; then
  ok "extraHelmManagedCiliumEgressGatewayPolicyNames appends to the allowlist"
else
  bad "extraHelmManagedCiliumEgressGatewayPolicyNames did not reach the rendered allowlist"
fi

echo
echo "passed: $PASS, failed: $FAIL"
[ "$FAIL" -eq 0 ]
