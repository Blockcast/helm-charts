#!/bin/bash
# luks-init.sh — LUKS cache storage initialization with RKS key management
#
# Fetches LUKS encryption key from RKS (Remote Key Server) via mTLS.
# The operator never sees the key. Key is held on tmpfs and shredded after use.
#
# Supports:
#   - Single loopback virtual disk (default, backward compat)
#   - Multiple physical devices (from CacheStorageState / ConfigMap)
#   - Multiple virtual disks
#
# Security:
#   - Key delivered via mTLS (gateway cert)
#   - Key written to tmpfs (/dev/shm/luks-XXXXXX), never to persistent storage
#   - Key shredded immediately after cryptsetup
#   - No env var fallback, no K8s Secret fallback
#
# Usage: luks-init.sh
# Required env: RKS_URL, GW_CERT, GW_KEY, ROOT_CA
# GATEWAY_ID derived from cert associatedName (logical gateway ID)
# Optional env: CACHE_SIZE_GB, CACHE_PATH, DEVICES_CONFIG (JSON)

set -euo pipefail

log() { echo "[$(date -u +%H:%M:%S)] cache-init: $*" >&2; }
die() { log "FATAL: $*"; exit 1; }

# --- Kernel feature detection ---
# Detect if kernel supports dm-crypt volume key linking to keyring (6.1+)
# and dm-integrity for tamper detection.
detect_kernel_features() {
    KERNEL_VER=$(uname -r | cut -d. -f1-2)
    KERNEL_MAJOR=$(echo "$KERNEL_VER" | cut -d. -f1)
    KERNEL_MINOR=$(echo "$KERNEL_VER" | cut -d. -f2)

    # Capture cryptsetup help once (--help exits non-zero, so ignore exit code).
    # Must capture before grep to avoid pipefail triggering on the non-zero exit.
    local cs_help
    cs_help=$(cryptsetup --help 2>&1 || true)

    # Kernel keyring linking for dm-crypt: requires 6.1+
    # --link-vk-to-keyring binds the volume key to a specific keyring session,
    # making it inaccessible to processes outside that session.
    KEYRING_SUPPORTED=false
    if [ "$KERNEL_MAJOR" -gt 6 ] || { [ "$KERNEL_MAJOR" -eq 6 ] && [ "$KERNEL_MINOR" -ge 1 ]; }; then
        if echo "$cs_help" | grep -q "link-vk-to-keyring"; then
            KEYRING_SUPPORTED=true
        fi
    fi

    # dm-integrity: kernel module check
    # In containers, modinfo fails (no /lib/modules). Check /proc/modules and
    # /sys/module first, then try nsenter to load on host if hostPID=true.
    INTEGRITY_SUPPORTED=false
    if modinfo dm-integrity &>/dev/null \
       || [ -d /sys/module/dm_integrity ] \
       || grep -q dm_integrity /proc/modules 2>/dev/null \
       || nsenter --target 1 --mount -- modprobe dm-integrity &>/dev/null; then
        if echo "$cs_help" | grep -q "\-\-integrity"; then
            INTEGRITY_SUPPORTED=true
        fi
    fi

    log "Kernel: $KERNEL_VER, keyring=$KEYRING_SUPPORTED, integrity=$INTEGRITY_SUPPORTED"
}

# --- Configuration ---
# Source baked-in defaults (BUILD_ENV-specific). Env vars from Helm override these.
[ -f /etc/default/cache-init ] && . /etc/default/cache-init

GW_CERT="${GW_CERT:-/var/opt/magma/certs/gateway.crt}"
GW_KEY="${GW_KEY:-/var/opt/magma/certs/gateway.key}"
ROOT_CA="${ROOT_CA:-/var/opt/magma/certs/certifier.pem}"
RKS_URL="${RKS_URL:?RKS_URL is required}"

# Derive GATEWAY_ID from the cert's associatedName field (logical gateway ID).
# RKS keys are named luks-{gatewayId}.
GATEWAY_ID=$(openssl x509 -in "$GW_CERT" -noout -subject -nameopt utf8,sep_comma_plus 2>/dev/null \
    | grep -oP 'associatedName=\K[^,]+' || true)
if [ -z "$GATEWAY_ID" ]; then
    die "Cannot extract GATEWAY_ID from $GW_CERT — no associatedName in subject"
fi

CACHE_SIZE_GB="${CACHE_SIZE_GB:-100}"
CACHE_PATH="${CACHE_PATH:-/var/trafficserver/relaycache}"
NODE_NAME="${MY_NODE_NAME:-${HOSTNAME:-node}}"
NODE_NAME=$(echo "$NODE_NAME" | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9-' | cut -c1-20)

# --- Fetch LUKS key from RKS ---
fetch_luks_key() {
    local key_file
    key_file=$(mktemp /dev/shm/luks-XXXXXX)
    chmod 600 "$key_file"

    log "Fetching LUKS key from RKS for gateway $GATEWAY_ID..."

    local attempt max_attempts=3 wait=5
    for attempt in $(seq 1 $max_attempts); do
        local raw_json="" curl_exit=0
        raw_json=$(curl -sf \
            --cert "$GW_CERT" --key "$GW_KEY" \
            --connect-timeout 10 --max-time 30 \
            "${RKS_URL}/rks/v1/secret/luks-${GATEWAY_ID}" 2>/dev/null) || curl_exit=$?

        if [ "$curl_exit" -ne 0 ]; then
            log "WARNING: RKS fetch failed (curl exit=$curl_exit). Attempt $attempt/$max_attempts"
        elif [ -z "$raw_json" ]; then
            log "WARNING: RKS returned empty response. Attempt $attempt/$max_attempts"
        elif echo "$raw_json" | jq -e '.error' &>/dev/null; then
            local rks_err
            rks_err=$(echo "$raw_json" | jq -r '.error // .message // "unknown"')
            log "WARNING: RKS error: $rks_err. Attempt $attempt/$max_attempts"
            # Don't try to extract key from error response
            raw_json=""
        fi

        if [ -n "$raw_json" ] && [ "$curl_exit" -eq 0 ]; then
            # Extract key_material from RKS response.
            # Response format: {"data": {"secret_type": "luks_key", "key_material": "base64..."}}
            local encoded_key
            encoded_key=$(echo "$raw_json" | jq -r '.data.key_material // .key_material // empty' 2>/dev/null)

            if [ -n "$encoded_key" ] && echo "$encoded_key" | base64 -d > "$key_file" 2>/dev/null; then
                local key_size
                key_size=$(wc -c < "$key_file")
                if [ "$key_size" -eq 32 ]; then
                    log "LUKS key fetched successfully (256-bit)"
                    echo "$key_file"
                    return 0
                fi
                log "WARNING: Key is $key_size bytes, expected 32. Attempt $attempt/$max_attempts"
            else
                log "WARNING: Could not extract key from RKS response. Attempt $attempt/$max_attempts"
            fi
        else
            log "WARNING: RKS fetch failed. Attempt $attempt/$max_attempts"
        fi

        if [ "$attempt" -lt "$max_attempts" ]; then
            sleep $wait
            wait=$((wait * 2))
        fi
    done

    # Dev-only fallback: use baked-in static key when RKS is unreachable.
    # The key file only exists in BUILD_ENV=dev images. Prod/staging images
    # do not have this file and will die() here as intended.
    local dev_key_file="/etc/default/cache-init-dev-key"
    if [ -f "$dev_key_file" ]; then
        log "WARNING: RKS unreachable — using LOCAL DEV key (BUILD_ENV=dev only)"
        base64 -d "$dev_key_file" > "$key_file" 2>/dev/null
        echo "$key_file"
        return 0
    fi

    rm -f "$key_file"
    die "Failed to fetch LUKS key from RKS after $max_attempts attempts"
}

# --- Setup a single LUKS volume ---
# Args: $1=backing_device_or_file, $2=mapper_name, $3=key_file
setup_luks_volume() {
    local backing="$1" mapper_name="$2" key_file="$3"
    local mapper_dev="/dev/mapper/$mapper_name"

    # Already open?
    if [ -b "$mapper_dev" ]; then
        log "LUKS device $mapper_name already open"
        return 0
    fi

    # Format if not already LUKS
    if ! cryptsetup isLuks "$backing" 2>/dev/null; then
        local format_args=(luksFormat --type luks2 --pbkdf pbkdf2 --key-file "$key_file" --batch-mode)

        # dm-integrity: adds HMAC-SHA256 tamper detection tag per sector.
        # Even if operator reads the raw mapper device, writes are detected.
        # ~3-5% space overhead, negligible CPU on modern hardware.
        # Only used on fresh format (can't add integrity to existing LUKS).
        if [ "$INTEGRITY_SUPPORTED" = true ]; then
            format_args+=(--integrity hmac-sha256)
            log "Formatting $backing with LUKS2 + integrity (hmac-sha256)..."
        else
            log "Formatting $backing with LUKS2 (no integrity, kernel too old)..."
        fi

        cryptsetup "${format_args[@]}" "$backing" || die "cryptsetup luksFormat failed on $backing"
    fi

    # Open with volume key linked to session keyring (if supported).
    # --link-vk-to-keyring @s : binds the dm-crypt volume key to this process's
    # session keyring. Other processes (including host root shells) cannot access
    # the keyring entry, so they can't derive the volume key from /proc or keyctl.
    # The dm-crypt device still exists in /dev/mapper/ but the key is isolated.
    local open_args=(open --key-file "$key_file")
    if [ "$KEYRING_SUPPORTED" = true ]; then
        # Format: <keyring_desc>::<key_desc>  (double colon separator)
        # @s = session keyring, user: = key type, rest = key description
        open_args+=(--link-vk-to-keyring "@s::user:dm-crypt-$mapper_name")
        log "Opening LUKS $mapper_name with keyring isolation..."
    else
        log "Opening LUKS $mapper_name (no keyring, kernel too old)..."
    fi

    cryptsetup "${open_args[@]}" "$backing" "$mapper_name" || die "cryptsetup open failed for $mapper_name"

    log "LUKS device ready: $mapper_dev (keyring=$KEYRING_SUPPORTED, integrity=$INTEGRITY_SUPPORTED)"
}

# --- Create ext4 filesystem and mount ---
# Args: $1=mapper_dev, $2=mount_path, $3=label
setup_ext4_mount() {
    local dev="$1" mount_path="$2" label="${3:-cache}"

    mkdir -p "$mount_path"

    # Format only if no filesystem
    if ! blkid "$dev" 2>/dev/null | grep -q 'TYPE='; then
        log "Formatting $dev with ext4 (label=$label)..."
        mkfs.ext4 -F -L "$label" "$dev"
    fi

    # Mount if not already
    if ! mountpoint -q "$mount_path" 2>/dev/null; then
        log "Mounting $dev at $mount_path..."
        mount "$dev" "$mount_path"
        chown 1000:1000 "$mount_path"  # ATS user
    fi

    log "ext4 mounted: $dev -> $mount_path"
}

# --- Setup loopback virtual disk ---
# Args: $1=file_path, $2=size_gb
# Returns: loop device path on stdout
setup_loopback() {
    local file_path="$1" size_gb="$2"

    # Create sparse file if needed
    local expected_size=$((size_gb * 1024 * 1024 * 1024))
    local current_size=0
    if [ -f "$file_path" ]; then
        current_size=$(stat -c%s "$file_path" 2>/dev/null || echo 0)
    fi
    if [ "$current_size" -lt "$expected_size" ]; then
        log "Creating ${size_gb}GB sparse file at $file_path..."
        rm -f "$file_path"
        truncate -s "${size_gb}G" "$file_path"
    fi

    # Check for existing loop association
    local loop_dev
    loop_dev=$(losetup -j "$file_path" 2>/dev/null | cut -d: -f1 | head -1)
    if [ -n "$loop_dev" ]; then
        echo "$loop_dev"
        return 0
    fi

    # Attach new loop device
    loop_dev=$(losetup -f)
    losetup "$loop_dev" "$file_path" || die "losetup failed for $file_path"
    echo "$loop_dev"
}

# --- Write status file for blockcastd to read ---
# blockcastd doesn't have /dev access, so it reads this JSON instead
# of running lsblk/losetup/cryptsetup directly.
write_status_file() {
    local status_file="${CACHE_PATH}/cache-status.json"
    local devs_json="[]"
    IFS=',' read -ra devs <<< "$1"
    local items=""
    for dev in "${devs[@]}"; do
        local size_bytes=0 mount_path=""
        size_bytes=$(lsblk -b -n -o SIZE "$dev" 2>/dev/null | head -1 | tr -d ' ')
        mount_path=$(lsblk -n -o MOUNTPOINT "$dev" 2>/dev/null | head -1 | tr -d ' ')
        local backing=""
        backing=$(cryptsetup status "$(basename "$dev")" 2>/dev/null | grep "device:" | awk '{print $2}')
        [ -n "$items" ] && items="$items,"
        items="$items{\"device\":\"$dev\",\"size_bytes\":${size_bytes:-0},\"mount_path\":\"${mount_path}\",\"backing_dev\":\"${backing}\",\"encrypted\":true}"
    done
    # Atomic write: write to tmp then rename to avoid partial reads
    local tmp_file="${status_file}.tmp"
    cat > "$tmp_file" <<-EOJSON
{"active_devices":[$items],"ram_total_bytes":$(grep MemTotal /proc/meminfo 2>/dev/null | awk '{print $2 * 1024}' || echo 0),"ram_available_bytes":$(grep MemAvailable /proc/meminfo 2>/dev/null | awk '{print $2 * 1024}' || echo 0),"node":"$NODE_NAME","updated":"$(date -u +%FT%TZ)"}
EOJSON
    mv "$tmp_file" "$status_file"
}

# --- Health check loop ---
# Args: $1=comma-separated list of mapper devices to watch
health_loop() {
    local devices="$1"
    log "Entering health check loop for: $devices"

    # Write initial status
    write_status_file "$devices"

    while true; do
        IFS=',' read -ra devs <<< "$devices"
        for dev in "${devs[@]}"; do
            if [ ! -b "$dev" ]; then
                log "Device $dev disappeared, exiting to trigger restart"
                exit 1
            fi
        done

        # Re-mount dropped ext4 mounts
        local mount_path="${CACHE_PATH}/cache"
        if [ -d "$mount_path" ] && ! mountpoint -q "$mount_path" 2>/dev/null; then
            log "WARNING: mount dropped at $mount_path, attempting re-mount"
            if ! mount "${devs[0]}" "$mount_path" 2>&1; then
                log "ERROR: re-mount FAILED for $mount_path — cache is offline"
            fi
        fi

        # Update status file
        write_status_file "$devices"

        sleep 60
    done
}

# === MAIN ===

log "=== LUKS Cache Init (RKS) ==="
log "Gateway: $GATEWAY_ID, Node: $NODE_NAME"

detect_kernel_features
mkdir -p "$CACHE_PATH"

# Close orphaned LUKS devices from previous pod runs (eviction, OOM kill, reschedule).
# The kernel mapper device persists on the host even after the container exits.
# Without cleanup, cryptsetup open fails with "Device already exists".
# Safe to close all at startup — the sidecar is the sole LUKS owner, and we'll
# re-open what we need after fetching a fresh key.
for dev in /dev/mapper/cache*; do
    [ -b "$dev" ] || continue
    orphan_name=$(basename "$dev")
    log "Closing orphaned LUKS device: $orphan_name"
    cryptsetup close "$orphan_name" 2>/dev/null || log "Warning: could not close $orphan_name (may be in use)"
done

# Detach orphaned loop devices pointing at our cache path
for lf in "$CACHE_PATH"/*_store; do
    [ -f "$lf" ] || continue
    orphan_loop=$(losetup -j "$lf" 2>/dev/null | cut -d: -f1 | head -1)
    if [ -n "$orphan_loop" ]; then
        log "Detaching orphaned loop device: $orphan_loop -> $lf"
        losetup -d "$orphan_loop" 2>/dev/null || true
    fi
done

# Fetch key from RKS (on tmpfs, never on disk)
KEY_FILE=$(fetch_luks_key)

# Trap to ensure key is shredded on any exit
trap 'shred -u "$KEY_FILE" 2>/dev/null || rm -f "$KEY_FILE" 2>/dev/null' EXIT

# Check for multi-device config from ConfigMap
ACTIVE_DEVICES=""
if [ -n "${DEVICES_CONFIG:-}" ] && [ -f "$DEVICES_CONFIG" ]; then
    log "Multi-device config found: $DEVICES_CONFIG"
    # Parse JSON config: {"devices": ["/dev/sda1"], "virtual_disks": [{"location":"/home/fsab","size_gb":100}]}

    # Physical devices
    for dev_path in $(jq -r '.devices[]? // empty' "$DEVICES_CONFIG" 2>/dev/null); do
        dev_name=$(basename "$dev_path" | tr -cd 'a-z0-9')
        mapper_name="cache-${dev_name}"
        setup_luks_volume "$dev_path" "$mapper_name" "$KEY_FILE"
        setup_ext4_mount "/dev/mapper/$mapper_name" "${CACHE_PATH}/${dev_name}" "$mapper_name"
        ACTIVE_DEVICES="${ACTIVE_DEVICES:+$ACTIVE_DEVICES,}/dev/mapper/$mapper_name"
    done

    # Virtual disks
    for row in $(jq -c '.virtual_disks[]? // empty' "$DEVICES_CONFIG" 2>/dev/null); do
        vd_location=$(echo "$row" | jq -r '.location')
        vd_size=$(echo "$row" | jq -r '.size_gb')
        vd_file="${vd_location}/cache_store"
        mkdir -p "$vd_location"
        loop_dev=$(setup_loopback "$vd_file" "$vd_size")
        vd_name=$(echo "$vd_location" | tr '/' '-' | tr -cd 'a-z0-9-' | cut -c1-20)
        mapper_name="cache-vd-${vd_name}"
        setup_luks_volume "$loop_dev" "$mapper_name" "$KEY_FILE"
        setup_ext4_mount "/dev/mapper/$mapper_name" "${CACHE_PATH}/${vd_name}" "$mapper_name"
        ACTIVE_DEVICES="${ACTIVE_DEVICES:+$ACTIVE_DEVICES,}/dev/mapper/$mapper_name"
    done
else
    # Default: single loopback virtual disk (backward compatible)
    log "Single-device mode (default)"
    CACHE_FILE="${CACHE_PATH}/${NODE_NAME}_store"
    DEVICE_NAME="cache0-${NODE_NAME}"

    loop_dev=$(setup_loopback "$CACHE_FILE" "$CACHE_SIZE_GB")
    setup_luks_volume "$loop_dev" "$DEVICE_NAME" "$KEY_FILE"
    setup_ext4_mount "/dev/mapper/$DEVICE_NAME" "${CACHE_PATH}/cache" "$DEVICE_NAME"

    # Symlink for ATS compatibility
    if [ ! -e "/dev/mapper/cache0" ] && [ -b "/dev/mapper/$DEVICE_NAME" ]; then
        ln -sf "/dev/mapper/$DEVICE_NAME" "/dev/mapper/cache0" 2>/dev/null || true
    fi

    ACTIVE_DEVICES="/dev/mapper/$DEVICE_NAME"
fi

# Shred key immediately — no longer needed after all volumes are open
shred -u "$KEY_FILE" 2>/dev/null || rm -f "$KEY_FILE" 2>/dev/null
trap - EXIT
log "LUKS key shredded from tmpfs"

# Register graceful shutdown handler.
# On SIGTERM (pod termination): unmount ext4, close LUKS (clears dm-crypt key
# from kernel memory), detach loop devices, wipe keyring entries.
graceful_shutdown() {
    log "=== Graceful shutdown ==="

    # Unmount all ext4 mounts under cache path
    for mp in $(findmnt -n -o TARGET -l 2>/dev/null | grep "$CACHE_PATH"); do
        log "Unmounting $mp..."
        if ! umount "$mp" 2>&1; then
            log "WARNING: umount $mp failed, trying lazy umount"
            umount -l "$mp" 2>&1 || log "ERROR: lazy umount $mp also failed"
        fi
    done

    # Close all cache LUKS devices (clears volume key from kernel dm-crypt)
    for dev in /dev/mapper/cache*; do
        if [ -b "$dev" ]; then
            local name=$(basename "$dev")
            log "Closing LUKS: $name..."
            if ! cryptsetup close "$name" 2>&1; then
                log "ERROR: cryptsetup close $name FAILED — volume key may remain in kernel"
            fi
        fi
    done

    # Wipe LUKS volume keys from session keyring (if keyring was used)
    if [ "$KEYRING_SUPPORTED" = true ] && command -v keyctl &>/dev/null; then
        log "Wiping LUKS keys from session keyring..."
        keyctl clear @s 2>/dev/null || true
    fi

    # Detach loop devices
    for lf in "$CACHE_PATH"/*_store; do
        if [ -f "$lf" ]; then
            local loop_dev=$(losetup -j "$lf" 2>/dev/null | cut -d: -f1)
            if [ -n "$loop_dev" ]; then
                log "Detaching $loop_dev..."
                losetup -d "$loop_dev" 2>/dev/null || true
            fi
        fi
    done

    log "Shutdown complete. All keys cleared from kernel."
    exit 0
}

trap graceful_shutdown SIGTERM SIGINT

log "All cache volumes ready. Active: $ACTIVE_DEVICES"
health_loop "$ACTIVE_DEVICES"
