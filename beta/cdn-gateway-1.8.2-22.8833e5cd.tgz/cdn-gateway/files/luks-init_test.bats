#!/usr/bin/env bats
# luks-init_test.bats — tests for LUKS cache init script
#
# Run: bats luks-init_test.bats
# Requires: bats-core, jq

# Source the script functions without executing main
setup() {
    export GATEWAY_ID="test-gw-001"
    export RKS_URL="https://rks.test.blockcast.net"
    export GW_CERT="/tmp/test-cert.pem"
    export GW_KEY="/tmp/test-key.pem"
    export ROOT_CA="/tmp/test-ca.pem"
    export CACHE_SIZE_GB="1"
    export CACHE_PATH="/tmp/bats-cache-$$"
    export MY_NODE_NAME="test-node"
    mkdir -p "$CACHE_PATH"
}

teardown() {
    rm -rf "$CACHE_PATH"
}

@test "script exists and is executable" {
    [ -f "luks-init.sh" ]
    [ -x "luks-init.sh" ] || chmod +x luks-init.sh
}

@test "script fails without GATEWAY_ID" {
    unset GATEWAY_ID
    run bash -c 'source luks-init.sh 2>&1' || true
    # Should fail with "GATEWAY_ID is required"
    [[ "$output" == *"GATEWAY_ID"* ]] || [[ "$status" -ne 0 ]]
}

@test "script fails without RKS_URL" {
    unset RKS_URL
    run bash -c 'source luks-init.sh 2>&1' || true
    [[ "$output" == *"RKS_URL"* ]] || [[ "$status" -ne 0 ]]
}

@test "node name sanitization removes special characters" {
    export MY_NODE_NAME="Test.Node_123!@#"
    # The script sanitizes: tr lower, tr -cd alnum-dash, cut 20
    result=$(echo "$MY_NODE_NAME" | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9-' | cut -c1-20)
    [ "$result" = "testnode123" ]
}

@test "node name truncated to 20 chars" {
    export MY_NODE_NAME="this-is-a-very-long-node-name-that-exceeds-twenty"
    result=$(echo "$MY_NODE_NAME" | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9-' | cut -c1-20)
    [ ${#result} -le 20 ]
}

@test "sparse file creation with truncate" {
    local test_file="$CACHE_PATH/test_store"
    truncate -s "1G" "$test_file"
    [ -f "$test_file" ]
    local size=$(stat -c%s "$test_file")
    [ "$size" -eq 1073741824 ]
    rm -f "$test_file"
}

@test "key file path is on tmpfs (/dev/shm)" {
    # Verify mktemp template produces /dev/shm path
    local key_file=$(mktemp /dev/shm/luks-XXXXXX)
    [[ "$key_file" == /dev/shm/luks-* ]]
    rm -f "$key_file"
}

@test "key shred removes file" {
    local key_file=$(mktemp /dev/shm/luks-test-XXXXXX)
    echo "test-key-data" > "$key_file"
    [ -f "$key_file" ]
    shred -u "$key_file" 2>/dev/null || rm -f "$key_file"
    [ ! -f "$key_file" ]
}

@test "multi-device config JSON parsing" {
    local config_file="$CACHE_PATH/devices.json"
    cat > "$config_file" <<'JSONEOF'
{
    "devices": ["/dev/sda1", "/dev/sdb1"],
    "virtual_disks": [{"location": "/home/cache", "size_gb": 50}]
}
JSONEOF

    # Parse devices
    local dev_count=$(jq -r '.devices | length' "$config_file")
    [ "$dev_count" -eq 2 ]

    local first_dev=$(jq -r '.devices[0]' "$config_file")
    [ "$first_dev" = "/dev/sda1" ]

    # Parse virtual disks
    local vd_location=$(jq -r '.virtual_disks[0].location' "$config_file")
    [ "$vd_location" = "/home/cache" ]

    local vd_size=$(jq -r '.virtual_disks[0].size_gb' "$config_file")
    [ "$vd_size" -eq 50 ]
}

@test "device name derivation from path" {
    # /dev/sda1 -> sda1 -> cache-sda1
    local dev_path="/dev/sda1"
    local dev_name=$(basename "$dev_path" | tr -cd 'a-z0-9')
    local mapper_name="cache-${dev_name}"
    [ "$mapper_name" = "cache-sda1" ]
}

@test "virtual disk name derivation from path" {
    local vd_location="/home/fsab"
    local vd_name=$(echo "$vd_location" | tr '/' '-' | tr -cd 'a-z0-9-' | cut -c1-20)
    local mapper_name="cache-vd-${vd_name}"
    [ "$mapper_name" = "cache-vd--home-fsab" ]
}

@test "kernel version parsing for feature detection" {
    # 6.1+ should enable keyring
    KERNEL_VER="6.1"
    MAJOR=$(echo "$KERNEL_VER" | cut -d. -f1)
    MINOR=$(echo "$KERNEL_VER" | cut -d. -f2)
    [ "$MAJOR" -gt 6 ] || { [ "$MAJOR" -eq 6 ] && [ "$MINOR" -ge 1 ]; }
    # Should pass (6.1 >= 6.1)

    # 5.15 should NOT enable keyring
    KERNEL_VER="5.15"
    MAJOR=$(echo "$KERNEL_VER" | cut -d. -f1)
    MINOR=$(echo "$KERNEL_VER" | cut -d. -f2)
    ! { [ "$MAJOR" -gt 6 ] || { [ "$MAJOR" -eq 6 ] && [ "$MINOR" -ge 1 ]; }; }
    # Should pass (5.15 < 6.1)
}

@test "kernel 6.8+ enables both keyring and integrity" {
    KERNEL_VER="6.8"
    MAJOR=$(echo "$KERNEL_VER" | cut -d. -f1)
    MINOR=$(echo "$KERNEL_VER" | cut -d. -f2)
    [ "$MAJOR" -gt 6 ] || { [ "$MAJOR" -eq 6 ] && [ "$MINOR" -ge 1 ]; }
    # 6.8 >= 6.1 → keyring supported
}

@test "empty devices config falls back to single device mode" {
    local config_file="$CACHE_PATH/devices.json"
    echo '{"devices":[],"virtual_disks":[]}' > "$config_file"

    local dev_count=$(jq -r '.devices | length' "$config_file")
    [ "$dev_count" -eq 0 ]
    # Script should fall through to single-device mode when DEVICES_CONFIG
    # points to a file with empty arrays
}
