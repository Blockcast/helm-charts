# `amtRelayLinux.*` — Software AMT relay (coexistence with hardware-offload)

Opt-in second AMT relay Deployment that renders **alongside** the
existing relay (`amtRelay.*`) so a single chart release can run both
forms of the CAST-side AMT relay.

## Two first-class variants

| Variant | Where it runs | When you'd choose it |
|---------|---------------|---------------------|
| **`amtRelay`** (hardware-offload) | External AMT-capable router (e.g., Juniper MX with PIM/IGMP/AMT in silicon) | Sites with dedicated multicast hardware. AMT decap/encap runs at line rate in ASIC, host CPU is free. Anycast is announced from the edge router itself. |
| **`amtRelayLinux`** (software, this toggle) | Anywhere Linux + Docker runs: k8s pods, bare-metal nodes, commodity SBCs (RPi, NUC, mini-PC class), VMs | Sites without dedicated multicast hardware, lab and test setups, L2 segments behind plain Ethernet + IGMP. Also enables hardware-diversity comparisons and load-testing against the offload variant. |

Both deliver the same AMT relay semantics. The choice depends on the
deployment context — neither replaces the other. A single deployment can
run one, the other, or both side-by-side (e.g., offload at large POPs +
software at edge sites; or both at one site for parallel load testing).

The chart toggle defaults to **off**. Turning it on adds a sibling
Deployment, Service, and WAL PVC; the existing `amtRelay.*` block is
untouched.

## Topology when both are enabled

```text
release-namespace
├── <release>-amt-relay              ← hardware-offload variant (amtRelay.*)
│   • external router does AMT decap/encap in silicon
│   • anycast IP announced via BGP from the network gear itself
│   • hostNetwork on a node that bridges to the relay's edge router
└── <release>-amt-relay-linux        ← software variant (amtRelayLinux.*)
    • pod runs the AMT relay in Linux kernel mroute + userspace
    • LB-IPAM VIP (operator-chosen)
    • Multus NAD attachment for the multicast-receive interface
    • amt kernel module installed by an init container (uname -r-matched)
    • optional eBPF tunnel tracker for accurate per-gateway stats
```

The two Deployments do not share VIPs, WAL volumes, or label selectors.

## Defaults

The full `amtRelayLinux:` block lives in `values.yaml` with per-key comments.
Key defaults:

| Key                                       | Default  | Purpose                                                        |
|-------------------------------------------|----------|----------------------------------------------------------------|
| `amtRelayLinux.enabled`                   | `false`  | Master switch. Off → renders zero new objects.                 |
| `amtRelayLinux.replicas`                  | `0`      | Dormant even if enabled. Set to 1+ via a values overlay.       |
| `amtRelayLinux.kmod.enabled`              | `true`   | Install the AMT kernel module from an `amt-kmod` init image. **Retired fallback — set `false`; see below.** |
| `amtRelayLinux.kmod.kernelVersion`        | required | Must match `uname -r` on the target node. Fails render loud.   |
| `amtRelayLinux.useEbpf`                   | `"true"` | Enable eBPF tunnel-tracker stats. See gotcha below.            |
| `amtRelayLinux.enableEbpfBilling`         | `"true"` | Per-(gateway × source-group) FlowEvents for byte-level billing.|
| `amtRelayLinux.amtAstats.primarySource`   | `"ebpf"` | Shaper PrimarySource filter; required to accept eBPF events.   |
| `amtRelayLinux.walPersistence.enabled`    | `true`   | Persistent WAL volume on the operator's storage class.         |

### `kmod.enabled` is a retired fallback — `false` is the expected setting

Kmod delivery moved from *this initContainer installs the module* to *the Talos
system extension loads it at boot* (`linux-amt` → `ghcr.io/blockcast/amt-kmod:<talos>`).
Nobody retired the initContainer when the mechanism changed, and its supply chain —
hand-copied per-kernel harbor tags — stopped at `6.18.34` on a `6.18.48` fleet. There
is no newer tag to point it at, so the fallback cannot be repaired by bumping
`kernelVersion`; it would have to be rebuilt as a signed per-kernel OOT pipeline to
keep alive a path the system extension already covers. See BLO-34375 / BLO-34381.

**Disabling it does not affect multicast forwarding.** `kmod.enabled: false` drops
`amt-kmod-installer` and its two hostPath volumes and nothing else —
`enable-v6-mcast-forwarding` and `configure-igmp-max-msf` still run, which the v6 AMT
path (BLO-12308) depends on. That boundary is pinned in both directions by
`tests/test-amt-relay-kmod-gate.sh`; it was **not** true before that test existed, when
a single gate wrapped all three initContainers.

## Key behaviors

### nodeSelector fallback chain

Mirrors the `amtRelay.*` template precedence:
`amtRelayLinux.nodeSelector` → `gateway.nodeSelector` → `.Values.nodeSelector`.

This matters because the linux relay pod is **privileged**: it hostPath-mounts
`/lib/modules` + `/sys` and installs a `uname -r`-matched kernel module
via the `amt-kmod-installer` init container. Without a nodeSelector, an
enabled pod could schedule on any node and either crashloop (vermagic
mismatch) or work-by-accident in a way that's hard to debug later.

The kmod-installer's fail-loud crashloop on vermagic mismatch is a
backstop, but a `nodeSelector` is the right primary defense.

Operator overlays should always pin `amtRelayLinux.nodeSelector` to
the subset of nodes whose kernel matches the kmod image's vermagic.

### `useEbpf` is a string, not a bool

`amtRelayLinux.useEbpf` is a quoted string (`"true"` / `"false"`) to match
the shape of the `USE_EBPF` env var. The template guards two footguns
that would otherwise cause the env value and the cap-gate decision to
drift:

1. **`if .Values.amtRelayLinux.useEbpf`** would treat any non-empty
   string as truthy — `useEbpf: "false"` would still add `BPF`/`PERFMON`
   caps even though `USE_EBPF=false` ends up in env.
2. **`default "true"`** (Sprig) treats bool `false` as the empty value
   and substitutes `"true"`, inverting an operator who happened to write
   `useEbpf: false` (no quotes).

The template normalizes once via `hasKey + toString` at the top so both
the env var and the cap gate read the same value:

```gotemplate
{{- $useEbpfStr := "true" -}}
{{- if and (.Values.amtRelayLinux) (hasKey .Values.amtRelayLinux "useEbpf") -}}
{{- $useEbpfStr = .Values.amtRelayLinux.useEbpf | toString -}}
{{- end -}}
```

Works for both `"true"`/`"false"` strings and `true`/`false` bools.

### `MROUTE_INPUT_IFACE` matters

The relay's Linux kernel multicast routing engine listens on a specific
interface inside the pod's network namespace. The chart default points
at the first Multus NAD attachment, but operators MUST set this to
whichever interface in the pod's netns actually receives upstream
multicast — typically the NAD bound to the VLAN/subnet carrying multicast
from the upstream router. Picking the wrong interface (for example, a
macvlan attachment with no IPAM that doesn't actually receive multicast)
results in a silently dead receive path even though the pod is "running".

`MROUTE_INPUT_IFACE6` plays the same role for IPv6 multicast.

### Why `replicas` is always rendered and `managed: "true"` is on the pod label

The template renders `replicas: {{ … | default 0 }}` unconditionally and
the pod template carries `managed: "true"`. This is consistent with all
sibling component templates in this chart (`ingress-cache`, `multicast`,
`cast`, `pob`, `traffic-router`, etc.).

If an operator deploys an external controller that manages replica
counts via the `managed` label, verify there's no conflict with helm's
always-rendered `replicas` before enabling this toggle with
`replicas > 0`.

## Tests

`tests/test-amt-relay-linux.sh` covers 46 assertions across 8 sections:

| #  | Coverage                                                                                       |
|----|------------------------------------------------------------------------------------------------|
| 1  | Defaults render zero new docs (off-by-default invariant).                                      |
| 2  | Enabled with a values overlay renders the expected config (env, NAD annotations, kmod init).   |
| 3  | Service with LB-IPAM annotations.                                                              |
| 4  | WAL PVC compound gating (`enabled` AND `walPersistence.enabled`).                              |
| 5  | `kmod.kernelVersion` is required when enabled (fails render loud).                             |
| 6  | The hardware-offload `amt-relay` render is **byte-identical** with this toggle on vs off.      |
| 7  | nodeSelector fallback chain (5 precedence assertions).                                         |
| 8  | useEbpf gate suppresses caps for both string and bool `false`; env+cap consistent.             |

`tests/test-amt-relay-kmod-gate.sh` covers 17 further assertions pinning the
`kmod.enabled` gate BOUNDARY described above — that disabling the fallback removes
`amt-kmod-installer` and its volumes, and removes *nothing else*. Both directions are
asserted, so a gate that has quietly stopped gating fails by name.

Local run:

```bash
cd cdn/gateway/helm/cdn-gateway-orc8r
bash tests/test-amt-relay-linux.sh
# PASS=46  FAIL=0
```

## Rollout pattern

1. Render the chart with `amtRelayLinux.enabled=false` (default) — no behavior change.
2. Add an overlay that sets `amtRelayLinux.enabled=true` with `replicas=0`,
   an explicit `nodeSelector`, `kmod.kernelVersion`, image tag, and
   service annotations.
3. Validate the render off-cluster (`helm template --show-only`) and on a
   soak environment.
4. Flip `replicas=1` in the same overlay (or a follow-up overlay).
5. Validate end-to-end multicast receive against a known source before
   promoting.

## Related repos

- [`linux-amt`](https://github.com/Blockcast/linux-amt) — the `blockcast/amtr` image's source. See `docs/architecture/BLOCKCAST.md` for variant comparison + per-key operational notes.
- [`trafficcontrol`](https://github.com/Blockcast/trafficcontrol) — `docs/architecture/likec4` includes both `amtRelay` (hardware-offload) and `amtRelayLinux` (software) as sibling services in the gatewayDataPlane view.

## Adjacent chart docs

- [`ARCHITECTURE.md`](./ARCHITECTURE.md) — chart-wide egress patterns.
- [`SECURITY.md`](./SECURITY.md) — Pod Security Standards / capability model.
