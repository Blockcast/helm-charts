#!/usr/bin/env bash
set -euo pipefail

# BLO-34775 regression guard, second half.
#
# Its sibling (test-no-namespaced-resources-in-clusterroles.sh) asserts that
# every resource in a ClusterRole here is genuinely cluster-scoped. That is a
# different property and it CANNOT catch this one: `clusterroles` and
# `clusterrolebindings` ARE cluster-scoped, so they pass that guard while
# granting unbounded CRUD over the cluster's entire authorization graph.
#
# What this asserts: no ClusterRole in this chart grants a MUTATING verb
# without resourceNames. Every ClusterRole here is bound to the per-namespace
# <release>-gateway SA by a ClusterRoleBinding, so an unbounded `delete` on
# clusterroles/clusterrolebindings means each gateway SA can delete any RBAC
# object in the cluster -- including the ones that bind other namespaces'
# workloads. RBAC escalation-prevention does not help: it constrains what you
# may WRITE (you cannot grant a rule set you do not hold, absent
# bind/escalate), and places no constraint at all on what you may DELETE.
#
# Read verbs are deliberately out of scope. They are disclosure, not
# destruction, and `list`/`watch` cannot take resourceNames at all.
#
# Asserts on the RENDERED manifests, not the template source: a source grep
# passes while a conditional or an indentation slip puts the unbounded rule
# back into what Helm actually applies.
#
# Every guard below was mutation-tested, one revert at a time: restoring the
# unbounded RBAC rule, dropping resourceNames from the gatewayclasses/status
# rule, breaking the parser's kind match (parser self-test fires; with the
# self-test removed, the survivor check fires), breaking it
# with the survivor check removed (shape check fires), breaking the
# resourceNames match (positive control fires), starting rules only on
# `- apiGroups:` again (parser self-test fires), setting `named` on the
# resourceNames key alone (parser self-test fires), counting an empty `""`
# entry as a name (parser self-test fires), counting a trailing
# `# comment` as a name, on the key line or on an item (parser self-test fires
# for each), keying the exemption lists by bare resource name again (a
# same-named resource in another API group inherits the exemption -- the
# chart mutation fires), and reading apiGroups with val() instead of gval()
# so the core group's empty entry is dropped (parser self-test fires). All
# eleven turn this script red.
# Re-run them if you change the parser -- a guard with no failing mutation is
# a comment.

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

mutating_verbs="update patch delete deletecollection create"

# Resources allowed to carry an unbounded mutating grant, each with a reason.
# Empty this list rather than growing it.
#
# Keyed <apiGroup>/<resource>, not by bare resource name. A bare name let a
# future resource of the same name in a DIFFERENT API group inherit an
# exemption written for this one (Ally, BLO-34775) -- the same shape as the two
# parser defects above: an exception broader than its own comment claims. The
# core group is spelled `core`, since it is "" on the wire.
#
# cilium.io/ciliumegressgatewaypolicies: cluster-scoped, templated by the main
# chart (cast-multicast-egress-cegp.yaml, relay/egress-gateway.yaml), and
# unlike the RBAC grant it is directly exercisable -- escalation-prevention
# does not reach it. Narrowing it is tracked on BLO-9606, not here. Listed so
# the exposure is visible in this guard's output instead of silently absent
# from it.
#
# gateway.networking.k8s.io/referencegrants: genuinely cannot be name-scoped.
# DSSync creates ReferenceGrants in the TARGET namespace of a cross-namespace
# origin, and those namespaces are not known when this chart renders. The
# reason is stated in dssync-rbac.yaml; this entry exists so the guard's output
# keeps naming the exposure rather than hiding it.
unbounded_ok="
cilium.io/ciliumegressgatewaypolicies
gateway.networking.k8s.io/referencegrants
"

# `create` is unbounded by construction: the API server rejects resourceNames
# on it (there is no name to match before admission). So a resource that is
# only ever created, never updated or deleted, has nothing to scope.
create_only_ok="
rbac.authorization.k8s.io/clusterroles
rbac.authorization.k8s.io/clusterrolebindings
"

rendered="$(helm template blockcastd-prereqs "$root" \
  --namespace staging-blockcastd-receiver \
  --set releaseName=blockcastd)"

# One line per rule inside a ClusterRole document:
#   <apiGroups>|<resources, space separated>|<verbs>|named|unnamed
#
# Handles the flow style this chart uses (resources: ["a", "b"]). A block-style
# rule would come out with an empty apiGroups, resources or verbs field, which
# the survivor check below turns into a loud failure rather than a silent pass.
#
# apiGroups is carried so the exemption lists can be keyed <group>/<resource>.
# The core group is "" on the wire and is emitted as `core`, so an empty field
# always means "parsed nothing" and stays distinguishable from "parsed the core
# group" -- the same present-vs-empty distinction the `named` flag needs.
#
# A rule starts on ANY list item at the depth of the first item under
# `rules:`, whatever key it leads with. It used to start only on
# `- apiGroups:`, so a rule written `- resources: [...]` was absorbed into the
# rule above it and inherited that rule's `named` flag: an unbounded delete on
# every ClusterRole reported as name-scoped (Ally, BLO-34775). Deeper list
# items -- block-style resourceNames entries -- stay inside their rule.
#
# `named` means a NON-EMPTY name is present, not that the resourceNames key
# is. Kubernetes reads an empty resourceNames as "everything is allowed", and
# a rule whose names all come from a `{{- range }}` over an empty list renders
# `resourceNames:` with nothing under it. The flag used to be set by the key
# alone, so that rule -- and `resourceNames: []` -- reported an unbounded
# delete as name-scoped (Ally, BLO-34775). A name counts only as the key's
# inline value or as a list item nested under that key, and `""` (or a bare
# `- ` from an empty template value) is not a name: RBAC matches it against
# the empty request name of create/list/deletecollection. Neither is a
# trailing `# comment` on the key line or on an item.
rules_of_clusterroles() {
  awk '
    function val(line,   s) { s=line; sub(/^[^:]*:[[:space:]]*/, "", s);
                              sub(/[[:space:]]*#.*$/, "", s);
                              gsub(/[][",]/, " ", s); gsub(/[[:space:]]+/, " ", s);
                              gsub(/^ | $/, "", s); return s }
    # apiGroups needs its own reader: the core group is the EMPTY string, which
    # val() would drop, silently shrinking the group set a rule is checked
    # against. Split on commas so every entry survives, empty ones included.
    function gval(line,   s, n, i, a, out) {
      s=line; sub(/^[^:]*:[[:space:]]*/, "", s); sub(/[[:space:]]*#.*$/, "", s)
      gsub(/[][]/, "", s)
      n=split(s, a, ",")
      for (i=1; i<=n; i++) {
        gsub(/["[:space:]]/, "", a[i])
        if (a[i] == "") a[i]="core"
        out = (out=="" ? a[i] : out " " a[i])
      }
      return out
    }
    function flush() {
      if (inrule) printf "%s|%s|%s|%s\n", grps, res, verbs, (names ? "named" : "unnamed")
      inrule=0; grps=""; res=""; verbs=""; names=0; key=""
    }
    /^---$/                     { flush(); kind=""; inrules=0; next }
    /^kind:[[:space:]]/         { flush(); kind=$2; inrules=0; next }
    kind != "ClusterRole"       { next }
    /^rules:/                   { flush(); inrules=1; depth=-1; next }
    /^[^[:space:]#-]/           { flush(); inrules=0; next }
    !inrules                    { next }
    /^[[:space:]]*-[[:space:]]/ {
      d = index($0, "-") - 1
      if (depth < 0) depth = d
      # Strip the item dash so the key on this line is parsed below.
      if (d == depth) { flush(); inrule=1; sub(/-/, " ") }
      else if (inrule && key == "resourceNames") {
        n=$0; sub(/^[[:space:]]*-/, "", n); sub(/[[:space:]]*#.*$/, "", n)
        gsub(/["[:space:]]/, "", n)
        if (n != "") names=1
      }
    }
    !inrule                     { next }
    /^[[:space:]]*[A-Za-z]+:/      { key=$1; sub(/:.*/, "", key) }
    /^[[:space:]]*apiGroups:/      { grps=gval($0);  next }
    /^[[:space:]]*resources:/      { res=val($0);   next }
    /^[[:space:]]*verbs:/          { verbs=val($0); next }
    /^[[:space:]]*resourceNames:/  { if (val($0) != "") names=1; next }
    END                         { flush() }
  '
}

# Parser self-test on fixed input, so the parser's correctness does not depend
# on what the chart happens to render today. Covers rules led by keys other
# than apiGroups, items at zero indent, and block-style resourceNames entries
# nested under a rule. The old `- apiGroups:`-only parser reads the first
# document as a single `secrets|delete|named` rule.
#
# The empty-resourceNames rules must come out `unnamed`: a key with nothing
# under it (what an all-`{{- range }}` list renders to when the range is
# empty), flow `[]`, `[]` on the item line, a lone `""` entry, and a key and
# item carrying only comments. A parser that sets `named` on the key alone
# reports all five as name-scoped.
#
# The last rule pins the apiGroups reader: `["", "extensions"]` must come out
# `core extensions`, both entries kept. Reading it with val() instead drops the
# empty core entry, which would shrink the group set a rule is checked against
# and hand it a silent exemption.
fixture='kind: ClusterRole
rules:
  - apiGroups: ["rbac.authorization.k8s.io"]
    resources: ["clusterroles"]
    resourceNames:
      - some-name
    verbs: ["update", "patch", "delete"]
  - resources: ["clusterroles"]
    apiGroups: ["rbac.authorization.k8s.io"]
    verbs: ["delete"]
  - verbs: ["get"]
    resources: ["secrets"]
    apiGroups: [""]
  - apiGroups: ["rbac.authorization.k8s.io"]
    resources: ["clusterroles"]
    resourceNames:
    verbs: ["delete"]
  - apiGroups: ["rbac.authorization.k8s.io"]
    resources: ["clusterrolebindings"]
    resourceNames: []
    verbs: ["delete"]
  - apiGroups: ["rbac.authorization.k8s.io"]
    resources: ["clusterroles"]
    resourceNames:
      - ""
    verbs: ["patch"]
  - apiGroups: ["rbac.authorization.k8s.io"]
    resources: ["clusterrolebindings"]
    resourceNames: # names below
      - # none yet
    verbs: ["update"]
---
kind: ClusterRole
rules:
- resourceNames:
  - other-name
  resources: ["clusterrolebindings"]
  apiGroups: ["rbac.authorization.k8s.io"]
  verbs: ["delete"]
- apiGroups: [""]
  resources: ["nodes"]
  verbs: ["patch"]
- resourceNames: []
  resources: ["clusterroles"]
  apiGroups: ["rbac.authorization.k8s.io"]
  verbs: ["delete"]
- apiGroups: ["", "extensions"]
  resources: ["ingresses"]
  verbs: ["delete"]
'
want='rbac.authorization.k8s.io|clusterroles|update patch delete|named
rbac.authorization.k8s.io|clusterroles|delete|unnamed
core|secrets|get|unnamed
rbac.authorization.k8s.io|clusterroles|delete|unnamed
rbac.authorization.k8s.io|clusterrolebindings|delete|unnamed
rbac.authorization.k8s.io|clusterroles|patch|unnamed
rbac.authorization.k8s.io|clusterrolebindings|update|unnamed
rbac.authorization.k8s.io|clusterrolebindings|delete|named
core|nodes|patch|unnamed
rbac.authorization.k8s.io|clusterroles|delete|unnamed
core extensions|ingresses|delete|unnamed'
got="$(rules_of_clusterroles <<<"$fixture")"
if [ "$got" != "$want" ]; then
  echo "FAIL: parser self-test. Expected:" >&2
  echo "$want" >&2
  echo "got:" >&2
  echo "$got" >&2
  exit 1
fi

rules="$(rules_of_clusterroles <<<"$rendered")"

# Survivor check. Every assertion below is of the form "no rule looks like X",
# so an empty or malformed extraction passes vacuously -- which is exactly the
# shape of the bug this file exists to catch. Refuse to report a clean run over
# nothing.
count="$(grep -c . <<<"$rules" || true)"
if [ "${count:-0}" -lt 3 ]; then
  echo "FAIL: extracted only ${count:-0} ClusterRole rules -- the parser or the" >&2
  echo "      chart changed shape. Refusing to pass on an empty read." >&2
  exit 1
fi
while IFS='|' read -r grps res verbs _; do
  [ -n "$grps" ] && [ -n "$res" ] && [ -n "$verbs" ] && continue
  echo "FAIL: parsed a ClusterRole rule with no apiGroups, no resources or no" >&2
  echo "      verbs (apiGroups='$grps' resources='$res' verbs='$verbs')." >&2
  echo "      Block-style rules are not handled; convert to flow style or" >&2
  echo "      extend the parser." >&2
  exit 1
done <<<"$rules"

# Positive control: the guard must be able to SEE a name-scoped rule. Without
# this, a parser that never sets the `named` flag would report success for the
# wrong reason -- and so would one that never sees the helm-manager document.
grep -q '|named$' <<<"$rules" || {
  echo "FAIL: no resourceNames-scoped ClusterRole rule found at all." >&2
  echo "$rules" >&2
  exit 1
}

rc=0
allowed=""
while IFS='|' read -r grps res verbs named; do
  [ -n "$res" ] || continue
  [ "$named" = "unnamed" ] || continue

  for verb in $verbs; do
    grep -qwF "$verb" <<<"$mutating_verbs" || continue

    # A rule's apiGroups x resources is a cross product in RBAC, so every pair
    # has to clear the exemption lists independently -- one exempt pair does
    # not cover the rest.
    for g in $grps; do
      for r in $res; do
        if grep -qxF "$g/$r" <<<"$unbounded_ok"; then
          allowed="$allowed $g/$r:$verb"
          continue
        fi
        if [ "$verb" = "create" ] && grep -qxF "$g/$r" <<<"$create_only_ok"; then
          continue
        fi
        echo "FAIL: ClusterRole rule grants '$verb' on '$g/$r' with no resourceNames." >&2
        echo "      Every ClusterRole in this chart is bound cluster-wide to the" >&2
        echo "      per-namespace <release>-gateway SA, so this is '$verb' on every" >&2
        echo "      $r in the cluster. Name-scope it (see helm-manager-rbac.yaml)." >&2
        rc=1
      done
    done
  done
done <<<"$rules"

[ "$rc" -eq 0 ] || exit 1

if [ -n "$allowed" ]; then
  echo "ok: ${count} ClusterRole rules checked; mutations name-scoped except" \
       "documented unbounded grant(s):${allowed}"
else
  echo "ok: ${count} ClusterRole rules checked, all mutations name-scoped"
fi
