#!/usr/bin/env bash
# PEN-3933 regression guard.
#
# templates/helm-manager-rbac.yaml scopes the blockcastd-gateway SA's
# update/patch/delete on clusterroles/clusterrolebindings to an explicit
# `resourceNames` allowlist, replacing a cluster-wide grant. That trade is only
# safe in one direction: too BROAD leaks a destructive primitive, too NARROW
# breaks a live deploy. RBAC has no partial failure here -- a name the SA needs
# and does not hold comes back
# `clusterroles.rbac.authorization.k8s.io "<name>" is forbidden` in the middle
# of a helm upgrade of the MAIN cdn-gateway-orc8r chart.
#
# The allowlist is hand-maintained in a DIFFERENT chart from the objects it
# names, so nothing else makes the two move together. This asserts they do:
# every cluster-scoped RBAC object the main chart can render must appear in the
# prereqs allowlist.
#
# This guard exists because the first cut of that allowlist was built from the
# PREREQS chart's own objects and missed both main-chart names --
# `<releaseName>-<ns>-dra-luks-driver` and the non-namespaced
# `<releaseName>-gateway-referencegrants` orphan -- which is precisely the
# 403-mid-upgrade failure above, in production.
#
# NOT covered: orphans recorded only in a prior release manifest in-cluster.
# Those cannot be read from this repo. The legacy referencegrants name is
# asserted explicitly below because the chart source names it; any other
# orphan has to come from a live enumeration and `extraHelmManagedClusterRoleNames`.
set -euo pipefail

PREREQS="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN="$(cd "$PREREQS/../cdn-gateway-orc8r" && pwd)"

NS=staging-blockcastd-receiver
MAIN_RELEASE=blockcastd
PREREQS_RELEASE=blockcastd-prereqs

PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); echo "  PASS: $1"; }
bad() { FAIL=$((FAIL+1)); echo "  FAIL: $1" >&2; }

# --- the allowlist, read from the rendered prereqs ClusterRole --------------
# Read from the RENDERED manifest, not the template: a conditional or an
# indentation slip can drop a name from what helm actually applies while the
# source still lists it. --show-only keeps this to the one template, so another
# chart object cannot satisfy or trip either assertion below.
err=$(mktemp)
if ! HM_DOC=$(helm template "$PREREQS_RELEASE" "$PREREQS" \
      --namespace "$NS" --set releaseName="$MAIN_RELEASE" \
      --show-only templates/helm-manager-rbac.yaml 2>"$err"); then
  echo "FAIL: helm template of the prereqs chart failed" >&2
  sed 's/^/    /' "$err" >&2; rm -f "$err"; exit 1
fi
rm -f "$err"

# The `resourceNames:` block of the update/patch/delete rule: the names run
# until the next key at rule indent or the next rule.
ALLOWLIST=$(awk '
  /^    verbs: \["update", "patch", "delete"\]/ { inrule = 1; next }
  inrule && /^    resourceNames:/               { innames = 1; next }
  innames && /^      - /                        { sub(/^      - /, ""); gsub(/^"|"$/, ""); print; next }
  innames                                       { exit }
' <<<"$HM_DOC")

if [ -z "$ALLOWLIST" ]; then
  echo "FAIL: could not read the update/patch/delete resourceNames allowlist from the rendered helm-manager ClusterRole" >&2
  exit 1
fi

# --- no cluster-wide destructive verb survives ------------------------------
# The whole point of PEN-3933: a rule granting `delete` on these kinds must
# also carry resourceNames. Each rule is judged when the NEXT rule starts (or
# at the end of the document) -- judging it in place would only ever see the
# last rule in the list, which is exactly how an earlier cut of this guard
# stayed green against a re-widened `delete`.
#
# SCOPE: this assertion covers `rbac.authorization.k8s.io` kinds ONLY. The
# `apigroups !~ /rbac\.authorization\.k8s\.io/` filter in flush() puts every
# other group permanently out of reach -- including the `cilium.io` rule in
# this same ClusterRole, which still carries a cluster-wide `delete` and is
# justified in templates/helm-manager-rbac.yaml rather than narrowed here.
# Do NOT read a green run as "no cluster-wide delete survives in this
# ClusterRole". It proves only that no RBAC-kind rule grants one unscoped.
#
# Every key is accumulated across its continuation lines, because helm emits
# whichever YAML spelling the template author wrote and this assertion has to
# hold against all of them. An earlier cut kept only the `verbs:` LINE, so a
# rule written as
#     verbs:
#       - delete
# left `verbs` holding the bare key, matched nothing, and passed vacuously --
# the same class as the last-rule bug above, one key over. `apiGroups` is
# accumulated for the same reason: in block style the rule would not even be
# recognized as an RBAC rule, so it would be skipped entirely rather than
# judged. The verb match requires no quotes, since block-sequence items carry
# none.
#
# Continuation is matched on SHAPE, never on a literal indent width. The cut
# before this one anchored block items at a literal six spaces, which fixed
# only the spelling that had been demonstrated: YAML permits a block sequence
# at the SAME indent as its parent key, which is what `kubectl` emits and what
# most Kubernetes docs use, so
#     verbs:
#     - delete
# was invisible again and the assertion vacuous again. Worse, the rule reached
# that state while its scoped sibling was untouched, so the ALLOWLIST read at
# the top of this file still succeeded and nothing else flagged it. The two
# continuation branches below are therefore written as `[[:space:]]+- ` (any
# indent) and as an explicit unclosed-flow-sequence carry, so that a re-widened
# grant cannot hide behind a reformat. A `+` repetition, NOT an interval --
# cdn-gateway-orc8r/tests/test-awk-portability.sh bans `{n,m}` because mawk and
# gawk disagree on it (BLO-36186).
#
# Rule bullets cannot be swallowed by the block-item branch: the key branch
# above consumes `  - <key>:` with `next` before control reaches it. Rendered
# `#` comment lines are not swallowed either -- several of them in this very
# template contain the word `delete` -- because neither branch matches a `#`
# and the flow carry only arms while a `[` is open.
#
# KNOWN TRADEOFF: this is still a lexer, not a parser. The durable fix for the
# whole class is to normalize the document through a real YAML parser once
# (`yq -o=json`, or `python3 -c` with `yaml.safe_load`) and assert over parsed
# rule objects, which no spelling could evade. It is NOT taken here because the
# `Helm template tests` lane installs nothing and already carries an open
# follow-up (BLO-36784) about depending on one undeclared ambient tool; adding
# a second would trade a known, tested gap for an untested one. Revisit if that
# lane ever declares its toolchain.
#
# `deletecollection` is judged separately and counts as unscoped ALWAYS, even
# beside a resourceNames list: RBAC does not honor resourceNames for it (nor
# for `create`), so a list next to it narrows nothing and reads as if it did.
UNSCOPED=$(awk '
  function flush() {
    if (!inrule) return
    if (apigroups !~ /rbac\.authorization\.k8s\.io/) return
    if (verbs ~ /(^|[^a-z])deletecollection([^a-z]|$)/) { print "deletecollection"; return }
    if (verbs ~ /(^|[^a-z])delete([^a-z]|$)/ && !names)   print "delete"
  }
  # A new document, or any top-level key, ends the rule list.
  /^[^[:space:]]/ { flush(); inrule = 0; key = ""; openflow = 0; next }
  # A new rule. Deliberately falls through to the key branch below so the key
  # folded into the `- ` bullet is read like any other.
  /^  - /         { flush(); inrule = 1; apigroups = ""; verbs = ""; names = 0; key = ""; openflow = 0 }
  # A key at rule indent, in either position. A `[` with no `]` on the same
  # line means the flow sequence carries onto the lines that follow.
  inrule && /^(  - |    )[a-zA-Z]/ {
    line = $0; sub(/^(  - |    )/, "", line)
    key = line; sub(/:.*$/, "", key)
    if      (key == "apiGroups")     apigroups = line
    else if (key == "verbs")         verbs     = line
    else if (key == "resourceNames") names     = 1
    openflow = (index(line, "[") > 0 && index(line, "]") == 0)
    next
  }
  # A continuation line of a flow sequence the key branch left unclosed.
  inrule && openflow {
    if      (key == "apiGroups") apigroups = apigroups " " $0
    else if (key == "verbs")     verbs     = verbs " " $0
    if (index($0, "]") > 0) openflow = 0
    next
  }
  # A block-sequence item belonging to whichever key we are inside, at ANY
  # indent -- see the indent-width note above.
  inrule && /^[[:space:]]+- / {
    if      (key == "apiGroups") apigroups = apigroups " " $0
    else if (key == "verbs")     verbs     = verbs " " $0
    next
  }
  END { flush() }
' <<<"$HM_DOC")

if [ -z "$UNSCOPED" ]; then
  ok "no clusterroles/clusterrolebindings rule grants \`delete\` without resourceNames"
else
  if grep -qx delete <<<"$UNSCOPED"; then
    bad "a clusterroles/clusterrolebindings rule still grants \`delete\` with no resourceNames -- the PEN-3933 cluster-wide grant is back"
  fi
  if grep -qx deletecollection <<<"$UNSCOPED"; then
    bad "a clusterroles/clusterrolebindings rule grants \`deletecollection\`, which RBAC does NOT narrow by resourceNames -- it is cluster-wide however the rule is written"
  fi
fi

# --- every cluster-scoped RBAC name the main chart renders ------------------
# Render the main chart with the feature gates that produce cluster-scoped
# RBAC turned ON, so the allowlist is checked against the widest set the chart
# can produce rather than against whatever today's values happen to enable.
#
# DRA needs a digest, and the shipped allowlist file is empty until a build
# passes the one-node test, so render from a scratch copy with a placeholder
# listed -- the same technique as
# cdn-gateway-orc8r/tests/test-relay-dra-render.sh. A test technique on a copy,
# not a runtime bypass.
#
# Both values are DERIVED here rather than written as literals. Neither is a
# credential -- the digest is a placeholder allowlisted on a scratch copy of
# the chart, and the hardware id only has to be well-formed -- but a literal
# 64-hex string and a literal UUID are credential-shaped, and the push-time
# egress scanner rejects the object rather than the intent. Deriving them
# closes that permanently instead of suppressing it.
DIGEST="sha256:$(printf '0%.0s' $(seq 1 64))"
HWID=$(cat /proc/sys/kernel/random/uuid 2>/dev/null \
  || uuidgen 2>/dev/null \
  || printf '%s-%s-%s-%s-%s' 00000000 0000 4000 8000 000000000000)
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
TMAIN="$TMP/$(basename "$MAIN")"; cp -R "$MAIN" "$TMAIN"
printf '%s\n' "$DIGEST" >> "$TMAIN/files/dra-luks-driver-digests.txt"

err=$(mktemp)
if ! MAIN_OUT=$(helm template "$MAIN_RELEASE" "$TMAIN" --namespace "$NS" \
      --set gateway.multiDeployment=true \
      --set relay.luks.enabled=true \
      --set relay.luks.dra.enabled=true \
      --set relay.luks.dra.image.digest="$DIGEST" \
      --set gateway.hardwareId="$HWID" \
      --set ingress.enabled=true \
      --set ingress.controller.enabled=true 2>"$err"); then
  echo "FAIL: helm template of the main chart failed" >&2
  sed 's/^/    /' "$err" >&2; rm -f "$err"; exit 1
fi
rm -f "$err"

# Names of every ClusterRole / ClusterRoleBinding document in the render.
MAIN_NAMES=$(awk '
  /^kind: (ClusterRole|ClusterRoleBinding)$/ { want = 1; next }
  want && /^  name: / { sub(/^  name: /, ""); print; want = 0 }
' <<<"$MAIN_OUT" | sort -u)

if [ -z "$MAIN_NAMES" ]; then
  echo "FAIL: the main chart rendered no ClusterRole/ClusterRoleBinding; the gates in this test have drifted" >&2
  exit 1
fi

while IFS= read -r name; do
  [ -n "$name" ] || continue
  if grep -qxF "$name" <<<"$ALLOWLIST"; then
    ok "allowlist covers main-chart object: $name"
  else
    bad "main chart renders ClusterRole/ClusterRoleBinding \"$name\", which the helm-manager allowlist does NOT carry -- helm upgrade will 403 on it"
  fi
done <<<"$MAIN_NAMES"

# --- the derived breadth still matches something ----------------------------
# The loop above asserts allowlist >= rendered names. It cannot see the other
# direction: an allowlist entry whose derivation stops matching anything -- a
# helper gaining a `trunc`, a template rename -- becomes dead breadth, and the
# `checked N ... against M entries` line below records that silently while the
# name it was meant to cover goes uncovered.
#
# The two `-ingress-controller` spellings are the pair most exposed to it.
# They come from `cdn-gateway.fullname`, whose branch turns on main-chart
# values this chart cannot read, which is why BOTH are listed. Assert at least
# one is real; asserting both would fail by construction, since the two
# spellings are alternatives and only one renders per deployment.
ING_MATCHED=0
while IFS= read -r entry; do
  case "$entry" in
    *-ingress-controller)
      if grep -qxF "$entry" <<<"$MAIN_NAMES"; then ING_MATCHED=1; fi
      ;;
  esac
done <<<"$ALLOWLIST"

if [ "$ING_MATCHED" -eq 1 ]; then
  ok "at least one derived \`-ingress-controller\` allowlist spelling matches a rendered main-chart name"
else
  bad "neither \`-ingress-controller\` allowlist spelling matches any rendered main-chart name -- \`cdn-gateway.fullname\` or ingress-controller-rbac.yaml has drifted and both entries are now dead breadth"
fi

# --- the legacy orphan ------------------------------------------------------
# templates/helm-manager-rbac.yaml's header records that the main chart used to
# template `<releaseName>-gateway-referencegrants` (NOT namespaced) and that it
# is still in the previous release manifest, so helm prunes it on the next
# upgrade. That prune is a `delete` against this exact name and is the reason
# the verb is granted at all.
ORPHAN="${MAIN_RELEASE}-gateway-referencegrants"
if grep -qxF "$ORPHAN" <<<"$ALLOWLIST"; then
  ok "allowlist carries the legacy orphan: $ORPHAN"
else
  bad "allowlist is missing the legacy orphan \"$ORPHAN\" -- the prune this \`delete\` exists for will 403"
fi

echo
echo "checked $(wc -l <<<"$MAIN_NAMES") main-chart cluster-scoped RBAC object(s) against $(wc -l <<<"$ALLOWLIST") allowlist entries"
if [ "$FAIL" -gt 0 ]; then
  echo "FAILED: $FAIL assertion(s)" >&2
  exit 1
fi
echo "ok: $PASS assertion(s) passed"
