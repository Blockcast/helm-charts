server {
  listen 443;
  ssl on;
  ssl_certificate /etc/nginx/conf.d/tls.crt;
  ssl_certificate_key /etc/nginx/conf.d/tls.key;
  location / {
     proxy_pass http://ocs:8080;
     proxy_set_header Host $http_host;
     proxy_set_header X-Forwarded-Proto $scheme;
  }
}
