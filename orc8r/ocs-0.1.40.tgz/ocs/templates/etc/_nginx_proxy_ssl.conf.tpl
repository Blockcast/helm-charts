user root;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
  worker_connections 1024;
}

http {
  # Custom JSON-formatted log
  log_format json_custom escape=json
    '{'
      '"nginx.time_local": "$time_local",'
      '"nginx.remote_addr": "$remote_addr",'
      '"nginx.request": "$request",'
      '"nginx.request_method": "$request_method",'
      '"nginx.request_uri": "$request_uri",'
      '"nginx.status": $status,'
      '"nginx.body_bytes_sent": $body_bytes_sent,'
      '"nginx.request_length": $request_length,'
      '"nginx.request_time": $request_time,'
      '"nginx.server_name": "$server_name",'
      '"nginx.client_serial": "$ssl_client_serial",'
    '}';

    upstream backend {
      # The keepalive parameter sets the maximum number of idle keepalive connections
      # to upstream servers that are preserved in the cache of each worker process. When
      # this number is exceeded, the least recently used connections are closed.
      keepalive 100;

      server ocs:8080;
    }

    server {
      listen 443;
      ssl on;
      ssl_certificate /etc/nginx/conf.d/tls.crt;
      ssl_certificate_key /etc/nginx/conf.d/tls.key;
      location / {
         proxy_pass http://backend;
         proxy_set_header Host $http_host;
         proxy_set_header X-Forwarded-Proto $scheme;
         proxy_read_timeout     300;
         proxy_connect_timeout  300;

         # Default is HTTP/1, keepalive is only enabled in HTTP/1.1
         proxy_http_version 1.1;

         # Remove the Connection header if the client sends it,
         # it could be "close" to close a keepalive connection
        proxy_set_header Connection "";
      }
    }
  # Open port 80 for k8s liveness check. Just returns a 200.
  server {
    listen 80;
    server_name _;

    location / {
      return 200;
    }
  }
}
stream {
    upstream diameter_acct {
        server ocs:3868 fail_timeout=30s;
    }
    upstream diameter_auth {
        server ocs:3869 fail_timeout=30s;
    }
    upstream radius_acct {
        server ocs:1812 fail_timeout=30s;
    }
    upstream radius_auth {
        server ocs:1813 fail_timeout=30s;
    }
    upstream radius_dynauth {
        server ocs:1813 fail_timeout=30s;
    }
    server {
        listen 3868;
        proxy_pass diameter_acct;
    }
    server {
        listen 3869;
        proxy_pass diameter_auth;
    }
    server {
        listen 1812 udp;
        proxy_pass radius_acct;
    }
    server {
        listen 1813 udp;
        proxy_pass radius_auth;
    }
    server {
        listen 3799 udp;
        proxy_pass radius_dynauth;
    }
}