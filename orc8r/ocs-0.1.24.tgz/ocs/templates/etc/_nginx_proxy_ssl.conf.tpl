http {
    upstream backend {
      # The keepalive parameter sets the maximum number of idle keepalive connections
      # to upstream servers that are preserved in the cache of each worker process. When
      # this number is exceeded, the least recently used connections are closed.
      keepalive 100;

      server ocs:8080;
    }

    server {
      listen 443;
      ssl on;
      ssl_certificate /etc/nginx/conf.d/tls.crt;
      ssl_certificate_key /etc/nginx/conf.d/tls.key;
      location / {
         proxy_pass http://backend;
         proxy_set_header Host $http_host;
         proxy_set_header X-Forwarded-Proto $scheme;
         proxy_read_timeout     300;
         proxy_connect_timeout  300;

         # Default is HTTP/1, keepalive is only enabled in HTTP/1.1
         proxy_http_version 1.1;

         # Remove the Connection header if the client sends it,
         # it could be "close" to close a keepalive connection
         proxy_set_header Connection "";
      }
    }
}
stream {
    upstream diameter {
        server ocs:3868 fail_timeout=30s;
    }
    upstream radius {
        server ocs:1812 fail_timeout=30s;
    }
    upstream radius_acct {
        server ocs:1813 fail_timeout=30s;
    }
    server {
        listen 3868;
        proxy_pass diameter;
    }
    server {
        listen 1812 udp;
        proxy_pass radius;
    }
    server {
        listen 1813 udp;
        proxy_pass radius_acct;
    }
}