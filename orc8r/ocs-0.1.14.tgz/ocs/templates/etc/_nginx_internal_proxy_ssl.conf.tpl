stream {
    upstream diameter {
        server ocs:3868;
    }
    upstream radius {
        server ocs:1812;
    }
    upstream radius_acct {
        server ocs:1813;
    }
    server {
        listen 3868;
        proxy_pass diameter;
    }
    server {
        listen 1812 udp;
        proxy_pass radius;
    }
    server {
        listen 1813 udp;
        proxy_pass radius_acct;
    }
}