{{/*
Caddy Server Container Spec
Used when relay.backend=caddy
*/}}
{{- define "relay.caddy.container" -}}
image: "{{ .Values.relay.caddy.image.repository | default "blockcast/relay-caddy" }}:{{ .Values.relay.caddy.image.tag | default "latest" }}"
imagePullPolicy: {{ .Values.relay.caddy.image.pullPolicy | default "Always" }}
env:
  - name: RELAY_BACKEND
    value: "caddy"
  - name: BUILD_ENV
    value: {{ .Values.relay.buildEnv | default "prod" | quote }}
  # Certificate paths
  - name: GATEWAY_CERT
    value: "/var/opt/magma/certs/gateway.crt"
  - name: GATEWAY_KEY
    value: "/var/opt/magma/certs/gateway.key"
  - name: ROOTCA_CERT
    value: "/etc/magma/certs/rootCA.pem"
  # Caddy configuration
  - name: HTTP_PORT
    value: {{ .Values.relay.caddy.httpPort | default 80 | quote }}
  - name: HTTPS_PORT
    value: {{ .Values.relay.caddy.httpsPort | default 443 | quote }}
  - name: CADDY_CONFIG
    value: "/opt/relay/etc/Caddyfile"
  # Control-proxy
  - name: CONTROL_PROXY_PORT
    value: {{ .Values.relay.controlProxy.port | default 8443 | quote }}
  - name: CONTROL_PROXY_CLOUD_ADDRESS
    value: {{ .Values.relay.controlProxy.cloudAddress | default .Values.gateway.cloud_hostname | default "controller.orc8r.blockcast.net" | quote }}
  - name: CONTROL_PROXY_CLOUD_PORT
    value: {{ .Values.relay.controlProxy.cloudPort | default 443 | quote }}
  # CDNi logging
  - name: CDNILOG_ENDPOINT
    value: {{ .Values.relay.cdnilog.endpoint | default "localhost:50052" | quote }}
  - name: CDNILOG_BATCH_SIZE
    value: {{ .Values.relay.cdnilog.batchSize | default 100 | quote }}
  - name: CDNILOG_FLUSH_INTERVAL_MS
    value: {{ .Values.relay.cdnilog.flushIntervalMs | default 5000 | quote }}
  # service303
  - name: SERVICE303_ADDRESS
    value: ":{{ .Values.relay.service303.port | default 50053 }}"
  # Health
  - name: HEALTH_PATH
    value: {{ .Values.relay.health.path | default "/_health" | quote }}
  # Drain timeout
  - name: CADDY_DRAIN_TIMEOUT
    value: {{ .Values.relay.caddy.drainTimeout | default 30 | quote }}
  # Traffic Ops (for config adapter)
  - name: TO_URL
    value: {{ .Values.relay.caddy.toURL | default .Values.relay.ats.toURL | default "https://to.infra.blockcast.net" | quote }}
  # Additional env
  {{- range .Values.relay.caddy.env }}
  - name: {{ .name }}
    value: {{ .value | quote }}
  {{- end }}
ports:
  - name: http
    containerPort: {{ .Values.relay.caddy.httpPort | default 80 }}
    protocol: TCP
  - name: https
    containerPort: {{ .Values.relay.caddy.httpsPort | default 443 }}
    protocol: TCP
  - name: control-proxy
    containerPort: {{ .Values.relay.controlProxy.port | default 8443 }}
    protocol: TCP
  - name: service303
    containerPort: {{ .Values.relay.service303.port | default 50053 }}
    protocol: TCP
livenessProbe:
  httpGet:
    path: {{ .Values.relay.health.path | default "/_health" }}
    port: http
  initialDelaySeconds: 15
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3
readinessProbe:
  httpGet:
    path: {{ .Values.relay.health.path | default "/_health" }}
    port: http
  initialDelaySeconds: 5
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 3
{{- if .Values.relay.caddy.resources }}
resources:
  {{- toYaml .Values.relay.caddy.resources | nindent 2 }}
{{- else if .Values.relay.resources }}
resources:
  {{- toYaml .Values.relay.resources | nindent 2 }}
{{- end }}
securityContext:
  capabilities:
    add:
      - NET_BIND_SERVICE
{{- end }}
