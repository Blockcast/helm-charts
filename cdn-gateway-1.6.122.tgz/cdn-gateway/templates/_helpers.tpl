{{/*
Expand the name of the chart.
*/}}
{{- define "cdn-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cdn-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cdn-gateway.labels" -}}
helm.sh/chart: {{ include "cdn-gateway.chart" . }}
{{ include "cdn-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cdn-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cdn-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cdn-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Gateway certificate path - all services use /var/opt/magma/certs
Contains gateway.crt and gateway.key from bootstrapper
*/}}
{{- define "cdn-gateway.certPath" -}}
/var/opt/magma/certs
{{- end }}

{{/*
Gateway certificate volume mounts for edge services (traffic-monitor, traffic-router, trafficserver)
Single mount point at /var/opt/magma/certs
*/}}
{{- define "cdn-gateway.certVolumeMounts" -}}
- name: certs
  mountPath: /var/opt/magma/certs
  readOnly: true
{{- end }}

{{/*
Gateway certificate volume definition
*/}}
{{- define "cdn-gateway.certVolume" -}}
- name: certs
  {{- if eq .Values.gateway.certsVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.certsVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.certsVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.certsVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.certsVolume.claimName | default "gateway-certs-pvc" }}
  {{- else if eq .Values.gateway.certsVolume.type "secret" }}
  secret:
    secretName: {{ .Values.gateway.certsVolume.secretName | default "gateway-certs" }}
  {{- else }}
  secret:
    secretName: {{ .Release.Name }}-certs
  {{- end }}
{{- end }}

{{/*
Common volume mounts for gateway services
*/}}
{{- define "cdn-gateway.volumeMounts" -}}
- name: certs
  mountPath: /var/opt/magma/certs
- name: snowflake
  mountPath: /etc/snowflake
{{- if .Values.gateway.rootCAPath }}
- name: rootca
  mountPath: /etc/magma/certs
  readOnly: true
{{- end }}
{{- if .Values.gateway.configsPath }}
- name: configs-cdn
  mountPath: /var/opt/magma/configs
{{- end }}
{{- if .Values.gateway.bandwidthConfigsPath }}
- name: configs-bandwidth
  mountPath: /var/opt/magma/configs/bandwidth
{{- end }}
{{- if .Values.gateway.helmAutoupdatePath }}
- name: helm-autoupdate
  mountPath: /var/opt/magma/helm
  readOnly: true
{{- end }}
{{- if or .Values.gateway.cloud_hostname .Values.gateway.bootstrap_hostname }}
- name: control-proxy-config
  mountPath: /etc/magma/configs/control_proxy.yml
  subPath: control_proxy.yml
  readOnly: true
{{- end }}
{{- end }}

{{/*
Common volumes for gateway services
*/}}
{{- define "cdn-gateway.volumes" -}}
- name: certs
  {{- if eq .Values.gateway.certsVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.certsVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.certsVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.certsVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.certsVolume.claimName | default "gateway-certs-pvc" }}
  {{- else if eq .Values.gateway.certsVolume.type "secret" }}
  secret:
    secretName: {{ .Values.gateway.certsVolume.secretName | default "gateway-certs" }}
  {{- end }}
- name: snowflake
  {{- if eq .Values.gateway.snowflakeVolume.type "hostPath" }}
  hostPath:
    path: {{ .Values.gateway.snowflakeVolume.hostPath }}
    type: DirectoryOrCreate
  {{- else if eq .Values.gateway.snowflakeVolume.type "emptyDir" }}
  emptyDir: {}
  {{- else if eq .Values.gateway.snowflakeVolume.type "persistentVolumeClaim" }}
  persistentVolumeClaim:
    claimName: {{ .Values.gateway.snowflakeVolume.claimName | default "gateway-snowflake-pvc" }}
  {{- end }}
{{- if .Values.gateway.rootCAPath }}
- name: rootca
  hostPath:
    path: {{ .Values.gateway.rootCAPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.configsPath }}
- name: configs-cdn
  hostPath:
    path: {{ .Values.gateway.configsPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.bandwidthConfigsPath }}
- name: configs-bandwidth
  hostPath:
    path: {{ .Values.gateway.bandwidthConfigsPath }}
    type: DirectoryOrCreate
{{- end }}
{{- if .Values.gateway.helmAutoupdatePath }}
- name: helm-autoupdate
  hostPath:
    path: {{ .Values.gateway.helmAutoupdatePath }}
    type: DirectoryOrCreate
{{- end }}
{{- if or .Values.gateway.cloud_hostname .Values.gateway.bootstrap_hostname }}
- name: control-proxy-config
  configMap:
    name: {{ .Release.Name }}-control-proxy-config
{{- end }}
{{- end }}

{{/*
Check if PostgreSQL should be enabled.
Auto-enable when ATS ingress or Caddy/multicast dynamic services are enabled.
*/}}
{{- define "cdn-gateway.postgresqlEnabled" -}}
{{- if .Values.postgresql.enabled -}}
true
{{- else if and .Values.gateway.trafficserver.enabled .Values.ingress.enabled -}}
true
{{- else if .Values.multicast.enabled -}}
true
{{- else if .Values.caddy.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Gateway nodeSelector - ensures all CDN pods run on nodes with shared cert volume access
Used for: hostPath volumes or ReadWriteOnce PVCs that require single-node deployment
*/}}
{{- define "cdn-gateway.nodeSelector" -}}
{{- if .Values.gateway.nodeSelector }}
nodeSelector:
  {{- toYaml .Values.gateway.nodeSelector | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Common pod spec for gateway services
*/}}
{{- define "cdn-gateway.podSpec" -}}
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if .Values.gateway.hostAliases }}
hostAliases:
  {{- toYaml .Values.gateway.hostAliases | nindent 2 }}
{{- end }}
{{- if or .nodeSelector .Values.gateway.nodeSelector .Values.nodeSelector }}
nodeSelector:
  {{- if .nodeSelector }}
  {{- toYaml .nodeSelector | nindent 2 }}
  {{- else if .Values.gateway.nodeSelector }}
  {{- toYaml .Values.gateway.nodeSelector | nindent 2 }}
  {{- else }}
  {{- toYaml .Values.nodeSelector | nindent 2 }}
  {{- end }}
{{- end }}
containers:
- name: {{ .serviceName }}
  image: "{{ .Values.gateway.image.repository }}:{{ .Values.gateway.image.tag }}"
  imagePullPolicy: {{ .Values.gateway.image.pullPolicy }}
  {{- if .command }}
  command:
    {{- toYaml .command | nindent 4 }}
  {{- end }}
  {{- if .args }}
  args:
    {{- toYaml .args | nindent 4 }}
  {{- end }}
  {{- if .ports }}
  ports:
    {{- toYaml .ports | nindent 4 }}
  {{- end }}
  {{- if .env }}
  env:
    {{- toYaml .env | nindent 4 }}
  {{- end }}
  {{- if .resources }}
  resources:
    {{- toYaml .resources | nindent 4 }}
  {{- end }}
  {{- if .Values.gateway.netAdmin }}
  securityContext:
    capabilities:
      add:
        - NET_ADMIN
  {{- end }}
  volumeMounts:
    {{- include "cdn-gateway.volumeMounts" . | nindent 4 }}
    {{- if .extraVolumeMounts }}
    {{- toYaml .extraVolumeMounts | nindent 4 }}
    {{- end }}
{{- if .securityContext }}
securityContext:
  {{- toYaml .securityContext | nindent 2 }}
{{- end }}
volumes:
  {{- include "cdn-gateway.volumes" . | nindent 2 }}
  {{- if .extraVolumes }}
  {{- toYaml .extraVolumes | nindent 2 }}
  {{- end }}
{{- end }}

