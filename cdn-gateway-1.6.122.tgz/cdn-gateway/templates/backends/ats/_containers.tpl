{{/*
ATS (Apache Traffic Server) Container Spec
Used when relay.backend=ats
*/}}
{{- define "relay.ats.container" -}}
image: "{{ .Values.relay.ats.image.repository | default "blockcast/relay-ats" }}:{{ .Values.relay.ats.image.tag | default "latest" }}"
imagePullPolicy: {{ .Values.relay.ats.image.pullPolicy | default "Always" }}
env:
  - name: RELAY_BACKEND
    value: "ats"
  - name: BUILD_ENV
    value: {{ .Values.relay.buildEnv | default "prod" | quote }}
  # Traffic Ops configuration
  - name: TO_URL
    value: {{ .Values.relay.ats.toURL | default "https://to.infra.blockcast.net" | quote }}
  - name: TO_API_VERSION
    value: {{ .Values.relay.ats.toAPIVersion | default "5.0" | quote }}
  # Certificate paths
  - name: GATEWAY_CERT
    value: "/var/opt/magma/certs/gateway.crt"
  - name: GATEWAY_KEY
    value: "/var/opt/magma/certs/gateway.key"
  - name: ROOTCA_CERT
    value: "/etc/magma/certs/rootCA.pem"
  # Cache configuration
  - name: CACHE_ENABLED
    value: {{ .Values.relay.cache.enabled | default true | quote }}
  - name: CACHE_STORAGE_SIZE
    value: {{ .Values.relay.cache.storage | default "100g" | quote }}
  - name: ROUTES_FILE
    value: "/opt/relay/var/routes/routes.json"
  # Control-proxy
  - name: CONTROL_PROXY_PORT
    value: {{ .Values.relay.controlProxy.port | default 8443 | quote }}
  - name: CONTROL_PROXY_CLOUD_ADDRESS
    value: {{ .Values.relay.controlProxy.cloudAddress | default .Values.gateway.cloud_hostname | default "controller.orc8r.blockcast.net" | quote }}
  - name: CONTROL_PROXY_CLOUD_PORT
    value: {{ .Values.relay.controlProxy.cloudPort | default 443 | quote }}
  # ATS drain timeout
  - name: ATS_DRAIN_TIMEOUT
    value: {{ .Values.relay.ats.drainTimeout | default 300 | quote }}
  # CDN environment
  {{- range .Values.relay.ats.env }}
  - name: {{ .name }}
    value: {{ .value | quote }}
  {{- end }}
ports:
  - name: http
    containerPort: 80
    protocol: TCP
  - name: https
    containerPort: 443
    protocol: TCP
  - name: ats-stats
    containerPort: 8080
    protocol: TCP
  - name: control-proxy
    containerPort: {{ .Values.relay.controlProxy.port | default 8443 }}
    protocol: TCP
  - name: service303
    containerPort: {{ .Values.relay.service303.port | default 50053 }}
    protocol: TCP
livenessProbe:
  tcpSocket:
    port: ats-stats
  initialDelaySeconds: 60
  periodSeconds: 30
  timeoutSeconds: 10
  failureThreshold: 3
readinessProbe:
  tcpSocket:
    port: ats-stats
  initialDelaySeconds: 30
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3
{{- if .Values.relay.ats.resources }}
resources:
  {{- toYaml .Values.relay.ats.resources | nindent 2 }}
{{- else if .Values.relay.resources }}
resources:
  {{- toYaml .Values.relay.resources | nindent 2 }}
{{- end }}
securityContext:
  {{- if .Values.relay.ats.privileged }}
  privileged: true
  {{- end }}
  capabilities:
    add:
      - NET_BIND_SERVICE
      {{- if .Values.relay.ats.luks }}
      - SYS_ADMIN
      {{- end }}
{{- end }}
