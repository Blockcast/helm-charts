{{/*
Varnish Cache Container Spec
Used when relay.backend=varnish
*/}}
{{- define "relay.varnish.container" -}}
image: "{{ .Values.relay.varnish.image.repository | default "blockcast/relay-varnish" }}:{{ .Values.relay.varnish.image.tag | default "7.6" }}"
imagePullPolicy: {{ .Values.relay.varnish.image.pullPolicy | default "Always" }}
env:
  - name: RELAY_BACKEND
    value: "varnish"
  - name: BUILD_ENV
    value: {{ .Values.relay.buildEnv | default "prod" | quote }}
  # Certificate paths
  - name: GATEWAY_CERT
    value: "/var/opt/magma/certs/gateway.crt"
  - name: GATEWAY_KEY
    value: "/var/opt/magma/certs/gateway.key"
  - name: ROOTCA_CERT
    value: "/etc/magma/certs/rootCA.pem"
  # Varnish configuration
  - name: VARNISH_HTTP_PORT
    value: {{ .Values.relay.varnish.httpPort | default 80 | quote }}
  - name: VARNISH_ADMIN_PORT
    value: {{ .Values.relay.varnish.adminPort | default 6082 | quote }}
  - name: VARNISH_STORAGE
    value: {{ .Values.relay.varnish.storage | default "malloc,256m" | quote }}
  - name: HITCH_PORT
    value: {{ .Values.relay.varnish.httpsPort | default 443 | quote }}
  # Control-proxy
  - name: CONTROL_PROXY_PORT
    value: {{ .Values.relay.controlProxy.port | default 8443 | quote }}
  - name: CONTROL_PROXY_CLOUD_ADDRESS
    value: {{ .Values.relay.controlProxy.cloudAddress | default .Values.gateway.cloud_hostname | default "controller.orc8r.blockcast.net" | quote }}
  - name: CONTROL_PROXY_CLOUD_PORT
    value: {{ .Values.relay.controlProxy.cloudPort | default 443 | quote }}
  # Drain timeout
  - name: VARNISH_DRAIN_TIMEOUT
    value: {{ .Values.relay.varnish.drainTimeout | default 60 | quote }}
  # Additional env
  {{- range .Values.relay.varnish.env }}
  - name: {{ .name }}
    value: {{ .value | quote }}
  {{- end }}
ports:
  - name: http
    containerPort: {{ .Values.relay.varnish.httpPort | default 80 }}
    protocol: TCP
  - name: https
    containerPort: {{ .Values.relay.varnish.httpsPort | default 443 }}
    protocol: TCP
  - name: varnish-admin
    containerPort: {{ .Values.relay.varnish.adminPort | default 6082 }}
    protocol: TCP
  - name: control-proxy
    containerPort: {{ .Values.relay.controlProxy.port | default 8443 }}
    protocol: TCP
  - name: service303
    containerPort: {{ .Values.relay.service303.port | default 50053 }}
    protocol: TCP
livenessProbe:
  exec:
    command:
      - varnishadm
      - status
  initialDelaySeconds: 30
  periodSeconds: 15
  timeoutSeconds: 5
  failureThreshold: 3
readinessProbe:
  httpGet:
    path: {{ .Values.relay.health.path | default "/_health" }}
    port: http
  initialDelaySeconds: 10
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3
{{- if .Values.relay.varnish.resources }}
resources:
  {{- toYaml .Values.relay.varnish.resources | nindent 2 }}
{{- else if .Values.relay.resources }}
resources:
  {{- toYaml .Values.relay.resources | nindent 2 }}
{{- end }}
securityContext:
  capabilities:
    add:
      - NET_BIND_SERVICE
{{- end }}
