{{/*
Common service template for gateway services
Usage: include "cdn-gateway.service" (dict "serviceName" "blockcastd" "ports" (list ...) "context" $)
*/}}
{{- define "cdn-gateway.service" -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ .serviceName }}
  labels:
    app.kubernetes.io/name: {{ .serviceName }}
    app.kubernetes.io/instance: {{ .context.Release.Name }}
spec:
  type: {{ .context.Values.service.type }}
  ports:
  {{- range .ports }}
  - name: {{ .name }}
    port: {{ .port }}
    targetPort: {{ .targetPort | default .port }}
    protocol: {{ .protocol | default "TCP" }}
  {{- end }}
  selector:
    app.kubernetes.io/name: {{ .serviceName }}
    app.kubernetes.io/instance: {{ .context.Release.Name }}
{{- end }}

